//
// This file contains an 'Intel Peripheral Driver' and is
// licensed for Intel CPUs and chipsets under the terms of your
// license agreement with Intel or your vendor.  This file may
// be modified by the user, subject to additional terms of the
// license agreement
//
/*++

  Copyright (c) 2004 - 2014, Intel Corporation. All rights reserved.<BR>
  This software and associated documentation (if any) is furnished
  under a license and may only be used or copied in accordance
  with the terms of the license. Except as permitted by such
  license, no part of this software or documentation may be
  reproduced, stored in a retrieval system, or transmitted in any
  form or by any means without the express written consent of
  Intel Corporation.

Module Name:

    LpcDriver.h
    
Abstract:

    EFI Lpc Driver for a Generic PC Platform

 

--*/

#ifndef _LPC_DRIVER_H
#define _LPC_DRIVER_H

 #include "LpcSio.h"
 #include "LpcIsaAcpi.h"

#include "protocol/IsaAcpi.h"
#include "protocol/PciIo.h"
#include "protocol/DriverBinding.h"
#include "Library/UefiBootServicesTableLib.h"
#include "IsaAcpiDxe/PcatIsaAcpi.h"
#include "IndustryStandard/Pci22.h"
#include "protocol/LpcWpce791Policy.h"

#include <Library/DebugLib.h>

#define ICH_LPC_BRIDGE_BUS_DEV_FUNC 0x1F0000

//
// LPC device private data structure
//
#define LPC_DEV_SIGNATURE 'W87X'
#define EFI_WPCE791_PS2_KEYBOARD_ENABLE       0x01
#define EFI_WPCE791_PS2_KEYBOARD_DISABLE      0x00

#define EFI_WPCE791_PS2_MOUSE_ENABLE       0x01
#define EFI_WPCE791_PS2_MOUSE_DISABLE      0x00



typedef struct {
  UINTN                 Signature;
  EFI_HANDLE            Handle;
  EFI_ISA_ACPI_PROTOCOL IsaAcpi;
  EFI_PCI_IO_PROTOCOL   *PciIo;

} LPC_DEV;

#define LPC_ISA_ACPI_FROM_THIS(a) BASE_CR (a, LPC_DEV, IsaAcpi)

//
// Driver entry point
//
EFI_STATUS
LpcDriverEntryPoint (
  IN EFI_HANDLE           ImageHandle,
  IN EFI_SYSTEM_TABLE     *SystemTable
  );

//
// Prototypes for Driver model protocol interface
//
EFI_STATUS
LpcDriverSupported (
  IN EFI_DRIVER_BINDING_PROTOCOL    *This,
  IN EFI_HANDLE                     Controller,
  IN EFI_DEVICE_PATH_PROTOCOL       *RemainingDevicePath
  );

EFI_STATUS
LpcDriverStart (
  IN EFI_DRIVER_BINDING_PROTOCOL    *This,
  IN EFI_HANDLE                     Controller,
  IN EFI_DEVICE_PATH_PROTOCOL       *RemainingDevicePath
  );

EFI_STATUS
LpcDriverStop (
  IN  EFI_DRIVER_BINDING_PROTOCOL    *This,
  IN  EFI_HANDLE                     Controller,
  IN  UINTN                          NumberOfChildren,
  IN  EFI_HANDLE                     *ChildHandleBuffer
  );

VOID
LpcIoRead8 (
  IN  UINT16  Port,
  OUT UINT8   *Data
  );

VOID
LpcIoWrite8 (
  IN  UINT16  Port,
  IN  UINT8   Data
  );

#endif
