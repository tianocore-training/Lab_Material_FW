//
// This file contains an 'Intel Peripheral Driver' and is
// licensed for Intel CPUs and chipsets under the terms of your
// license agreement with Intel or your vendor.  This file may
// be modified by the user, subject to additional terms of the
// license agreement
//
/*++

  Copyright (c) 2004 - 2014, Intel Corporation. All rights reserved.<BR>
  This software and associated documentation (if any) is furnished
  under a license and may only be used or copied in accordance
  with the terms of the license. Except as permitted by such
  license, no part of this software or documentation may be
  reproduced, stored in a retrieval system, or transmitted in any
  form or by any means without the express written consent of
  Intel Corporation.

Module Name:

  LegacyMetronome.h

Abstract:

  Driver implementing the EFI 2.0 metronome protocol using the legacy PORT 61 
  timer.

--*/

#ifndef _LEGACY_METRONOME_H
#define _LEGACY_METRONOME_H

//
// Statements that include other files
//
#include "protocol/Metronome.h"
#include "protocol/CpuIo.h"
#include "library/DebugLib.h"
#include "Library/UefiBootServicesTableLib.h"


//
// Private definitions
//
#define TICK_PERIOD         300
#define REFRESH_PORT        0x61
#define REFRESH_ON          0x10
#define REFRESH_OFF         0x00
#define TIMER1_CONTROL_PORT 0x43
#define TIMER1_COUNT_PORT   0x41
#define LOAD_COUNTER1_LSB   0x54
#define COUNTER1_COUNT      0x12

//
// Function Prototypes
//
EFI_STATUS
EFIAPI
WaitForTick (
  IN EFI_METRONOME_ARCH_PROTOCOL  *This,
  IN UINT32                       TickNumber
  )
/*++

Routine Description:

  Waits for the TickNumber of ticks from a known platform time source.

Arguments:

  This                Pointer to the protocol instance.
  TickNumber          Tick Number to be waited

Returns: 

  EFI_SUCCESS         If number of ticks occurred.
  EFI_NOT_FOUND       Could not locate CPU IO protocol

--*/
;

#endif
