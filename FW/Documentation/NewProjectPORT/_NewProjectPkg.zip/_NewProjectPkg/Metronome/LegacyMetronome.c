/*++
  This file contains an 'Intel Peripheral Driver' and is        
  licensed for Intel CPUs and chipsets under the terms of your  
  license agreement with Intel or your vendor.  This file may   
  be modified by the user, subject to additional terms of the   
  license agreement                                             
--*/
/** @file

  Copyright (c) 2004 - 2014, Intel Corporation. All rights reserved.<BR>
  This software and associated documentation (if any) is furnished
  under a license and may only be used or copied in accordance
  with the terms of the license. Except as permitted by such
  license, no part of this software or documentation may be
  reproduced, stored in a retrieval system, or transmitted in any
  form or by any means without the express written consent of
  Intel Corporation.

Module Name:


  LegacyMetronome.c

Abstract:

  This contains the installation function for the driver.

--*/

#include "LegacyMetronome.h"



//
// Handle for the Metronome Architectural Protocol instance produced by this driver
//
EFI_HANDLE                  mMetronomeHandle = NULL;

//
// The Metronome Architectural Protocol instance produced by this driver
//
EFI_METRONOME_ARCH_PROTOCOL mMetronome = {
  WaitForTick,
  TICK_PERIOD
};

//
// The CPU I/O Protocol used to access system hardware
//
EFI_CPU_IO_PROTOCOL         *mCpuIo = NULL;

//
// Worker Functions
//
VOID
ScriptWriteIo8 (
  UINT16  Port,
  UINT8   Data
  )
/*++

Routine Description:

  Write an 8 bit value to an I/O port and save it to the S3 script

Arguments:

  Port - IO Port
  Data - Data in IO Port

Returns: 

  None.

--*/
{
  mCpuIo->Io.Write (
              mCpuIo,
              EfiCpuIoWidthUint8,
              Port,
              1,
              &Data
              );
              
 

}

UINT8
ReadRefresh (
  VOID
  )
/*++

Routine Description:

  Read the refresh bit from the REFRESH_PORT

Arguments:

  None.

Returns: 

  Refresh bit.

--*/
{
  UINT8 Data;

  mCpuIo->Io.Read (
              mCpuIo,
              EfiCpuIoWidthUint8,
              REFRESH_PORT,
              1,
              &Data
              );
  return (UINT8) (Data & REFRESH_ON);
}

EFI_STATUS
EFIAPI
WaitForTick (
  IN EFI_METRONOME_ARCH_PROTOCOL  *This,
  IN UINT32                       TickNumber
  )
/*++

Routine Description:

  Waits for the TickNumber of ticks from a known platform time source.

Arguments:

  This                Pointer to the protocol instance.
  TickNumber          Tick Number to be waited

Returns: 

  EFI_SUCCESS         If number of ticks occurred.
  EFI_NOT_FOUND       Could not locate CPU IO protocol

--*/
{
  //
  // Wait for TickNumber toggles of the Refresh bit
  //
  for (; TickNumber != 0x00; TickNumber--) {
    while (ReadRefresh () == REFRESH_ON)
      ;
    while (ReadRefresh () == REFRESH_OFF)
      ;
  }

  return EFI_SUCCESS;
}
//
// Driver Entry Point
//
//EFI_DRIVER_ENTRY_POINT (InstallLegacyMetronome)

EFI_STATUS
EFIAPI
InstallLegacyMetronome (
  IN EFI_HANDLE        ImageHandle,
  IN EFI_SYSTEM_TABLE  *SystemTable
  )
/*++

Routine Description:
  
  Install the LegacyMetronome driver.  Loads a Metronome Arch Protocol based
  on the Port 61 timer.

Arguments:

  ImageHandle     - Handle for the image of this driver
  SystemTable     - Pointer to the EFI System Table

Returns:

  EFI_SUCCESS - Metronome Architectural Protocol Installed

--*/
{
  EFI_STATUS  Status;

  //
  // Make sure the Metronome Architectural Protocol is not already installed in the system
  //
  ASSERT_PROTOCOL_ALREADY_INSTALLED (NULL, &gEfiMetronomeArchProtocolGuid);

  //
  // Get the CPU I/O Protocol that this driver requires
  // If the CPU I/O Protocol is not found, then ASSERT because the dependency expression
  // should guarantee that it is present in the handle database.
  //
  Status = gBS->LocateProtocol (&gEfiCpuIoProtocolGuid, NULL, &mCpuIo);
  ASSERT_EFI_ERROR (Status);

  //
  // Program port 61 timer 1 as refresh timer. We could use ACPI timer in the
  // future.
  //
  ScriptWriteIo8 (TIMER1_CONTROL_PORT, LOAD_COUNTER1_LSB);
  ScriptWriteIo8 (TIMER1_COUNT_PORT, COUNTER1_COUNT);

  //
  // Install on a new handle
  //
  Status = gBS->InstallMultipleProtocolInterfaces (
                  &mMetronomeHandle,
                  &gEfiMetronomeArchProtocolGuid,
                  &mMetronome,
                  NULL
                  );
  ASSERT_EFI_ERROR (Status);

  return Status;
}
