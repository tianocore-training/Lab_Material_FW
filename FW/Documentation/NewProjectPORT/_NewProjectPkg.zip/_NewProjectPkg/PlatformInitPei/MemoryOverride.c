/*++
  This file contains an 'Intel Peripheral Driver' and is        
  licensed for Intel CPUs and chipsets under the terms of your  
  license agreement with Intel or your vendor.  This file may   
  be modified by the user, subject to additional terms of the   
  license agreement                                             
--*/
/** @file

  Copyright (c) 2004 - 2014, Intel Corporation. All rights reserved.<BR>
  This software and associated documentation (if any) is furnished
  under a license and may only be used or copied in accordance
  with the terms of the license. Except as permitted by such
  license, no part of this software or documentation may be
  reproduced, stored in a retrieval system, or transmitted in any
  form or by any means without the express written consent of
  Intel Corporation.

Module Name:


  Memory.c

Abstract:

  Tiano PEIM to provide the platform support functionality.
  This file implements the Memory Override Timings PPI

 
 
--*/

#include "PlatformEarlyInit.h"

#include EFI_PPI_DEPENDENCY (ValleyviewMemoryController)

EFI_STATUS
EFIAPI
GetMemoryOverrideTimings (
  IN EFI_PEI_SERVICES                             **PeiServices,
  IN struct _PEI_MEMORY_OVERRIDE_TIMINGS_PPI      *This,
  IN OUT  MRC_PARAMETER_FRAME                     *CurrentMrcData
  )
{
  EFI_STATUS                            Status;
  EFI_PEI_READ_ONLY_VARIABLE2_PPI       *Variable;
  SYSTEM_CONFIGURATION                  Buffer;
  UINTN                                 VariableSize;
  BOOLEAN                               BufferValid;

  Status = (*PeiServices)->LocatePpi (PeiServices,
                                      &gEfiPeiReadOnlyVariable2PpiGuid,
                                      0,
                                      NULL,
                                      &Variable
                                      );

  ASSERT_PEI_ERROR (PeiServices, Status);

  VariableSize = sizeof(SYSTEM_CONFIGURATION);

  Status = Variable->PeiGetVariable (Variable,
                                     gEfiNormalSetupName,
                                     &gEfiNormalSetupGuid,
                                     NULL,
                                     &VariableSize,
                                     &Buffer);
  BufferValid = (BOOLEAN)(!EFI_ERROR (Status));

  if (BufferValid) {

//    //
//    // Always disable Flex Mode if VTD enabled
//    // MRC will be updated based on VT-d enable/disable input option.
//    // VtdInputOption = 0 when VT-d is enabled by Bios.
//    // VtdInputOption = 1 when VT-d is disabled by Bios.
//    //
//    if (Buffer.VtdTechnology == 0) {
//      ((MRC_PARAMETER_FRAME *)CurrentMrcData)->VtdInputOption = 1;
//    } else {
//      ((MRC_PARAMETER_FRAME *)CurrentMrcData)->VtdInputOption = 0;
//    }

//    // Check setup option for ECC and adjust ECC support accordingly.
//    ((MRC_PARAMETER_FRAME *)CurrentMrcData)->Ecc &= Buffer.EccEnable;

    // User defined timings
    if (Buffer.MemoryMode==0x02) {
      switch(Buffer.MemoryTcl) { // compensating for VFR differences between 945 & 965, so we can share UQIs
      case 0:                      // on 945, tCL 5 -> value 0; on 965, tCL 5 -> value 2
        CurrentMrcData->Tcl = 5;
        break;
      case 1:                      // on 945, tCL 4 -> value 1; on 965, tCL 4 -> value 1
        CurrentMrcData->Tcl = 4;
        break;
      case 2:                      // on 945, tCL 3 -> value 2; on 965, tCL 3 -> value 0
        CurrentMrcData->Tcl = 3;
        break;
      default:                     // other values undefined on 945
        CurrentMrcData->Tcl = Buffer.MemoryTcl + 3;
      }

      CurrentMrcData->TimingData[MRC_DATA_TRAS]      = Buffer.MemoryTras + 9;
                                                                             //subtractions below are to compensate for VFR differences between 945 & 965
      CurrentMrcData->TimingData[MRC_DATA_TRCD]      = Buffer.MemoryTrcd + 2;  //1=0, 2=1, 3=2, etc.
      CurrentMrcData->TimingData[MRC_DATA_TRP]       = Buffer.MemoryTrp + 2;   //1=0, 2=1, 3=2, etc.
      CurrentMrcData->DdrFreq = (UINT8)Buffer.MemorySpeed - 3;
 
    }
  }

/*-
  // Read GPIO's for Voltage programming
  Data8 = IoRead8 (GPIO_BASE + 0x15);
  // Clear the GPIO's used to set the memory voltage
  Data8 &= ~(BIT5 + BIT6);

    // This code is to handle the "User-Defined" setting.
    switch (Buffer.MemoryVoltage) {
      case 0:
      Data8 |= (BIT5 + BIT6);
      break;
      case 1:
      Data8 |= (BIT5 + BIT6);
      break;
      case 2:
      Data8 |= BIT6;
      Data8 &= ~BIT5;
      break;
      case 3:
      Data8 &= ~BIT6;
      Data8 |= BIT5;
      break;
      case 4:
      Data8 &= ~BIT6;
      Data8 &= ~BIT5;
      break;
    }

  // Write GPIO's for Voltage programming
  IoWrite8 (GPIO_BASE + 0x15,  Data8);
-*/

  return EFI_SUCCESS;
}
