/*++
  This file contains an 'Intel Peripheral Driver' and is        
  licensed for Intel CPUs and chipsets under the terms of your  
  license agreement with Intel or your vendor.  This file may   
  be modified by the user, subject to additional terms of the   
  license agreement                                             
--*/
/** @file

  Copyright (c) 2004 - 2014, Intel Corporation. All rights reserved.<BR>
  This software and associated documentation (if any) is furnished
  under a license and may only be used or copied in accordance
  with the terms of the license. Except as permitted by such
  license, no part of this software or documentation may be
  reproduced, stored in a retrieval system, or transmitted in any
  form or by any means without the express written consent of
  Intel Corporation.



Module Name:

  FlashMap.c
   
Abstract:

  Build GUIDed HOBs for platform specific flash map.

--*/

/*++
 This file contains an 'Intel Peripheral Driver' and is        
 licensed for Intel CPUs and chipsets under the terms of your  
 license agreement with Intel or your vendor.  This file may   
 be modified by the user, subject to additional terms of the   
 license agreement                                             
--*/
#include "Efi.h"
#include "Pei.h"
#include "PeiLib.h"
#include "PeiLib.h"
#include "EfiFlashMap.h"
#include "BuildVariables.h"
#include EFI_PROTOCOL_CONSUMER (FirmwareVolumeBlock)
#include EFI_GUID_DEFINITION (FlashMapHob)
#include EFI_GUID_DEFINITION (SystemNvDataGuid)
#include EFI_GUID_DEFINITION (FirmwareFileSystem)

EFI_GUID                            mFvBlockGuid      = EFI_FIRMWARE_VOLUME_BLOCK_PROTOCOL_GUID;
EFI_GUID                            mFfsGuid          = EFI_FIRMWARE_FILE_SYSTEM_GUID;
EFI_GUID                            mSystemDataGuid   = EFI_SYSTEM_NV_DATA_HOB_GUID;

static EFI_FLASH_AREA_DATA          mFlashAreaData[]  = { 
  // Variable area
  { VARIABLE_BLOCK_BASE_ADDR,
    VARIABLE_BLOCK_SIZE,
    EFI_FLASH_AREA_SUBFV | EFI_FLASH_AREA_MEMMAPPED_FV,
    EFI_FLASH_AREA_EFI_VARIABLES },

  // Boot block backup, via A16 inversion
  { A16_INV_BLOCK_ADDR,
    BOOTBLOCK_SIZE, // A16 inversion implies 64k size (A16 can now be A17 or A18 inversion, size can be 64/128/256KB)
    EFI_FLASH_AREA_SUBFV | EFI_FLASH_AREA_MEMMAPPED_FV,
    EFI_FLASH_AREA_FTW_BACKUP },

  // Recovery FV
  { BOOTBLOCK_BASE_ADDR,
    BOOTBLOCK_SIZE,
    EFI_FLASH_AREA_FV | EFI_FLASH_AREA_MEMMAPPED_FV,
    EFI_FLASH_AREA_RECOVERY_BIOS },

  // Main FV
  { MAINBLOCK_BASE_ADDR,
    MAINBLOCK_SIZE,
    EFI_FLASH_AREA_FV | EFI_FLASH_AREA_MEMMAPPED_FV,
    EFI_FLASH_AREA_MAIN_BIOS }

};

#define NUM_FLASH_AREA_DATA (sizeof (mFlashAreaData) / sizeof (mFlashAreaData[0]))

EFI_STATUS
PeimInitializeFlashMap (
  IN EFI_FFS_FILE_HEADER       *FfsHeader,
  IN EFI_PEI_SERVICES          **PeiServices
  )
/*++

Routine Description:

  Build GUID HOBs for platform specific flash map.
  
Arguments:

  FfsHeader     Pointer this FFS file header.
  PeiServices   General purpose services available to every PEIM.
    
Returns:

  EFI_SUCCESS   Guid HOBs for platform flash map is built.
  Otherwise     Failed to build the Guid HOB data.

--*/
{
  UINTN                         Index;
  EFI_FLASH_AREA_HOB_DATA       FlashHobData;

  //
  // Build flash area entries as GUIDed HOBs.
  //
  for (Index = 0; Index < NUM_FLASH_AREA_DATA; Index++) {
    ZeroMem(&FlashHobData, sizeof (EFI_FLASH_AREA_HOB_DATA));

    FlashHobData.AreaType               = mFlashAreaData[Index].AreaType;
    FlashHobData.NumberOfEntries        = 1;
    FlashHobData.SubAreaData.Attributes = mFlashAreaData[Index].Attributes;
    FlashHobData.SubAreaData.Base       = (EFI_PHYSICAL_ADDRESS) (UINTN) mFlashAreaData[Index].Base;
    FlashHobData.SubAreaData.Length     = (EFI_PHYSICAL_ADDRESS) (UINTN) mFlashAreaData[Index].Length;

    switch (FlashHobData.AreaType) {
    case EFI_FLASH_AREA_RECOVERY_BIOS:
    case EFI_FLASH_AREA_MAIN_BIOS:
      CopyMem (
        &FlashHobData.AreaTypeGuid,
        &mFfsGuid,
        sizeof (EFI_GUID)
        );
      CopyMem (
        &FlashHobData.SubAreaData.FileSystem,
        &mFvBlockGuid,
        sizeof (EFI_GUID)
        );
      break;

    case EFI_FLASH_AREA_GUID_DEFINED:
      CopyMem (
        &FlashHobData.AreaTypeGuid,
        &mSystemDataGuid,
        sizeof (EFI_GUID)
        );
      CopyMem (
        &FlashHobData.SubAreaData.FileSystem,
        &mFvBlockGuid,
        sizeof (EFI_GUID)
        );
      break;

    default:
      break;
    }
              
    PeiBuildHobGuidData(PeiServices,
                        &gEfiFlashMapHobGuid,
                        &FlashHobData,
                        sizeof (EFI_FLASH_AREA_HOB_DATA)
                        );
  }
  return EFI_SUCCESS;
}

