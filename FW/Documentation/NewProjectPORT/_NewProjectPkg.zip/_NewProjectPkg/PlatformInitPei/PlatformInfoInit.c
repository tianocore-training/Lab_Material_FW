/*++
  This file contains an 'Intel Peripheral Driver' and is        
  licensed for Intel CPUs and chipsets under the terms of your  
  license agreement with Intel or your vendor.  This file may   
  be modified by the user, subject to additional terms of the   
  license agreement                                             
--*/
/** @file

  Copyright (c) 2004 - 2014, Intel Corporation. All rights reserved.<BR>
  This software and associated documentation (if any) is furnished
  under a license and may only be used or copied in accordance
  with the terms of the license. Except as permitted by such
  license, no part of this software or documentation may be
  reproduced, stored in a retrieval system, or transmitted in any
  form or by any means without the express written consent of
  Intel Corporation.

Module Name:

  PlatformInfoInit.c

Abstract:
  Platform Info Driver.

--*/

#include "PlatformEarlyInit.h"

#define LEN_64M       0x4000000
//
// Default PCI32 resource size
//
#define RES_MEM32_MIN_LEN   0x38000000

#define RES_IO_BASE   0x0D00
#define RES_IO_LIMIT  0xFFFF

#define MemoryCeilingVariable   L"MemCeil."

EFI_STATUS
CheckOsSelection (
  IN CONST EFI_PEI_SERVICES          **PeiServices,
  IN SYSTEM_CONFIGURATION            *SystemConfiguration
  )
{
  EFI_STATUS                   Status;
  EFI_PEI_READ_ONLY_VARIABLE2_PPI   *Variable;
  UINTN                        VariableSize;
  EFI_OS_SELECTION_HOB         *OsSelectionHob;
  UINT8                        OsSelection;
  UINT8                        *LpssDataHobPtr;
  UINT8                        *LpssDataVarPtr;
  UINTN                        i;

  Status = (*PeiServices)->LocatePpi (PeiServices,
                                      &gEfiPeiReadOnlyVariable2PpiGuid,
                                      0,
                                      NULL,
                                      &Variable
                                      );
  if (!EFI_ERROR(Status)) {
    VariableSize = sizeof (OsSelection);
    Status = Variable->GetVariable (Variable,
                         L"OsSelection",
                         &gOsSelectionVariableGuid,
                         NULL,
                         &VariableSize,
                         &OsSelection);

    if (!EFI_ERROR(Status) && (SystemConfiguration->OsSelection != OsSelection)) {
      //
      // Build HOB for OsSelection
      //
      OsSelectionHob = BuildGuidHob (&gOsSelectionVariableGuid, sizeof (EFI_OS_SELECTION_HOB));
      ASSERT (OsSelectionHob != NULL);

      OsSelectionHob->OsSelectionChanged = TRUE;
      OsSelectionHob->OsSelection        = OsSelection;
      SystemConfiguration->OsSelection   = OsSelectionHob->OsSelection;

      if (OsSelectionHob->OsSelection == ANDROID) {
        //
        // Load LPSS and SCC defalut configurations for Android
        //
        //OsSelectionHob->LpssData.LpssPciModeEnabled         = TRUE;
        OsSelectionHob->LpssData.LpsseMMCEnabled            = FALSE;
        OsSelectionHob->LpssData.LpssSdioEnabled            = TRUE;
        OsSelectionHob->LpssData.LpssSdcardEnabled          = TRUE;
        OsSelectionHob->LpssData.LpssSdCardSDR25Enabled     = FALSE;
        OsSelectionHob->LpssData.LpssSdCardDDR50Enabled     = TRUE;
        OsSelectionHob->LpssData.LpssMipiHsi                = FALSE;
        OsSelectionHob->LpssData.LpsseMMC45Enabled          = TRUE;
        OsSelectionHob->LpssData.LpsseMMC45DDR50Enabled     = TRUE;
        OsSelectionHob->LpssData.LpsseMMC45HS200Enabled     = FALSE;
        OsSelectionHob->LpssData.LpsseMMC45RetuneTimerValue = 8;
        OsSelectionHob->LpssData.eMMCBootMode               = 1;     // Auto Detect
        /*OsSelectionHob->LpssData.LpssDma1Enabled            = TRUE;
        OsSelectionHob->LpssData.LpssI2C0Enabled            = TRUE;
        OsSelectionHob->LpssData.LpssI2C1Enabled            = TRUE;
        OsSelectionHob->LpssData.LpssI2C2Enabled            = TRUE;
        OsSelectionHob->LpssData.LpssI2C3Enabled            = FALSE;
        OsSelectionHob->LpssData.LpssI2C4Enabled            = TRUE;
        OsSelectionHob->LpssData.LpssI2C5Enabled            = TRUE;
        OsSelectionHob->LpssData.LpssI2C6Enabled            = TRUE;
        OsSelectionHob->LpssData.LpssDma0Enabled            = TRUE;
        OsSelectionHob->LpssData.LpssPwm0Enabled            = FALSE;
        OsSelectionHob->LpssData.LpssPwm1Enabled            = FALSE;
        OsSelectionHob->LpssData.LpssHsuart0Enabled         = TRUE;
        OsSelectionHob->LpssData.LpssHsuart1Enabled         = TRUE;
        OsSelectionHob->LpssData.LpssSpiEnabled             = FALSE;
        OsSelectionHob->LpssData.I2CTouchAd                 = 0;     // Auto Detect
        */
        //
        // Load Audio defalut configuration for Android
        //
        //OsSelectionHob->Lpe                                 = FALSE;
        //OsSelectionHob->PchAzalia                           = TRUE;
      } else {
        //
        // Load LPSS and SCC defalut configurations for Windows
        //
        //OsSelectionHob->LpssData.LpssPciModeEnabled         = FALSE;
        OsSelectionHob->LpssData.LpsseMMCEnabled            = FALSE;
        OsSelectionHob->LpssData.LpssSdioEnabled            = TRUE;
        OsSelectionHob->LpssData.LpssSdcardEnabled          = TRUE;
        OsSelectionHob->LpssData.LpssSdCardSDR25Enabled     = FALSE;
        OsSelectionHob->LpssData.LpssSdCardDDR50Enabled     = TRUE;
        OsSelectionHob->LpssData.LpssMipiHsi                = FALSE;
        OsSelectionHob->LpssData.LpsseMMC45Enabled          = TRUE;
        OsSelectionHob->LpssData.LpsseMMC45DDR50Enabled     = TRUE;
        OsSelectionHob->LpssData.LpsseMMC45HS200Enabled     = FALSE;
        OsSelectionHob->LpssData.LpsseMMC45RetuneTimerValue = 8;
        OsSelectionHob->LpssData.eMMCBootMode               = 1;     // Auto Detect
        /*OsSelectionHob->LpssData.LpssDma1Enabled            = FALSE;
        OsSelectionHob->LpssData.LpssI2C0Enabled            = FALSE;
        OsSelectionHob->LpssData.LpssI2C1Enabled            = FALSE;
        OsSelectionHob->LpssData.LpssI2C2Enabled            = FALSE;
        OsSelectionHob->LpssData.LpssI2C3Enabled            = FALSE;
        OsSelectionHob->LpssData.LpssI2C4Enabled            = FALSE;
        OsSelectionHob->LpssData.LpssI2C5Enabled            = FALSE;
        OsSelectionHob->LpssData.LpssI2C6Enabled            = FALSE;
        OsSelectionHob->LpssData.LpssDma0Enabled            = FALSE;
        OsSelectionHob->LpssData.LpssPwm0Enabled            = FALSE;
        OsSelectionHob->LpssData.LpssPwm1Enabled            = FALSE;
        OsSelectionHob->LpssData.LpssHsuart0Enabled         = FALSE;
        OsSelectionHob->LpssData.LpssHsuart1Enabled         = FALSE;
        OsSelectionHob->LpssData.LpssSpiEnabled             = FALSE;
        OsSelectionHob->LpssData.I2CTouchAd                 = 0;     // Auto Detect
        */
        //
        // Load Audio defalut configuration for Windows
        //
        OsSelectionHob->Lpe                                 = FALSE;
        OsSelectionHob->PchAzalia                           = TRUE;
      }

      SystemConfiguration->Lpe       = OsSelectionHob->Lpe;
      SystemConfiguration->PchAzalia = SystemConfiguration->PchAzalia;
      LpssDataHobPtr = &OsSelectionHob->LpssData.LpssPciModeEnabled;
      LpssDataVarPtr = &SystemConfiguration->LpssPciModeEnabled;

      for (i = 0; i < sizeof(EFI_PLATFORM_LPSS_DATA); i++) {
        *LpssDataVarPtr = *LpssDataHobPtr;
        LpssDataVarPtr++;
        LpssDataHobPtr++;
      }
    }
  }

  return EFI_SUCCESS;
}




EFI_STATUS
PlatformInfoUpdate (
  IN CONST EFI_PEI_SERVICES          **PeiServices,
  IN OUT EFI_PLATFORM_INFO_HOB *PlatformInfoHob,
  IN SYSTEM_CONFIGURATION      *SystemConfiguration
  )
{
  EFI_STATUS                   Status;
  EFI_PEI_READ_ONLY_VARIABLE2_PPI   *Variable;
  UINTN                        VariableSize;
  UINT32                       MemoryCeiling;

  //
  // Checking PCI32 resource from previous boot to determine the memory ceiling
  //
  Status = (*PeiServices)->LocatePpi (PeiServices,
                                      &gEfiPeiReadOnlyVariable2PpiGuid,
                                      0,
                                      NULL,
                                      &Variable
                                      );
  if (!EFI_ERROR(Status)) {
    //
    // Get the memory ceiling
    //
    VariableSize = sizeof(MemoryCeiling);
    Status = Variable->GetVariable (Variable,
                                       MemoryCeilingVariable,
                                       &gEfiGlobalVariableGuid,
                                       NULL,
                                       &VariableSize,
                                       &MemoryCeiling);
    if(!EFI_ERROR(Status)) {
      //
      // Set the new PCI32 resource Base if the variable available
      //
      PlatformInfoHob->PciData.PciResourceMem32Base = MemoryCeiling;
      PlatformInfoHob->MemData.MemMaxTolm = MemoryCeiling;
      PlatformInfoHob->MemData.MemTolm = MemoryCeiling;
      //
      // Platform PCI MMIO Size in unit of 1MB
      //
      PlatformInfoHob->MemData.MmioSize = 0x1000 - (UINT16)(PlatformInfoHob->MemData.MemMaxTolm >> 20);
    }
  }

  //
  // Clear TPM Command CMOS area -need to check later -joosong
  //
  //IoWrite8(R_ICH_RTC_EXT_INDEX, TCG_CMOS_AREA_OFFSET);
  //IoWrite8(R_ICH_RTC_EXT_TARGET, 0);

  return EFI_SUCCESS;
}

EFI_STATUS
InitializePlatform (
  IN CONST EFI_PEI_SERVICES       **PeiServices,
  IN EFI_PLATFORM_INFO_HOB        *PlatformInfoHob,
  IN SYSTEM_CONFIGURATION         *SystemConfiguration
)
/*++
Routine Description:
  Initialize the platform related info hob according to the
  pre-determine value or setup option
Arguments:

Returns:
  EFI_SUCCESS  -  Memory initialization completed successfully.
  Others       -  All other error conditions encountered result in an ASSERT.
--*/
{
// -- cchew10 need to update here.

  return EFI_SUCCESS;
}

