/*++
  This file contains an 'Intel Peripheral Driver' and is        
  licensed for Intel CPUs and chipsets under the terms of your  
  license agreement with Intel or your vendor.  This file may   
  be modified by the user, subject to additional terms of the   
  license agreement                                             
--*/
/*++

Copyright (c)  2013 Intel Corporation. All rights reserved
This software and associated documentation (if any) is furnished
under a license and may only be used or copied in accordance
with the terms of the license. Except as permitted by such
license, no part of this software or documentation may be
reproduced, stored in a retrieval system, or transmitted in any
form or by any means without the express written consent of
Intel Corporation.


Module Name:
  
  IsctWakeReason.c
   
Abstract:
  
  Provide Wake Reason for ISCT.
  
--*/

#include "PlatformEarlyInit.h"
#include "PchAccess.h"
#include "Platform.h"
#include "PlatformBaseAddresses.h"
#include <Guid/SetupVariable.h>
#include <ppi/EndOfPeiPhase.h>
#include <ppi/ReadOnlyVariable2.h>
#include <pi/PiPeiCis.h>
//#include <PeiKscLib.h>
#include <Guid/SetupVariable.h>
#include <Library/PciCf8Lib.h>
#include <Guid/Vlv2Variable.h>
#include <Guid/IsctPersistentData.h>
#include "PchCommonDefinitions.h"


EFI_STATUS
IsctGetWakeReason (
  IN CONST EFI_PEI_SERVICES           **PeiServices
  );


UINT8
IsNetworkDevicePME (
  )
/*++

Routine Description:

  Checks for a PCIe Network Device attached to the root ports to see if it caused the PME

Arguments:

  None
  
Returns:

  UINT8 NetworkWakePME - 1 An attached PCIe Network device caused a PME.
                         0 No PME caused by network device

--*/
{
  UINT8                   NetworkWakePME;
  UINT8                   RpFunction;
  UINTN                   RpBase;
  UINTN                   EpBase;
  UINT8                   CapPtr;
  UINT8                   NxtPtr;
  UINT8                   CapID;
  UINT8                   PMCreg;
  UINT8                   PMCSR;

  NetworkWakePME = 0;

  //
  // Scan PCH PCI-EX slots (Root Port) : Device 28 Function 0~3
  //
  for (RpFunction = 0; RpFunction < PCH_PCIE_MAX_ROOT_PORTS; RpFunction ++) {
    RpBase = MmPciAddress (0, DEFAULT_PCI_BUS_NUMBER_PCH, PCI_DEVICE_NUMBER_PCH_PCIE_ROOT_PORTS, RpFunction, 0);
    DEBUG ((EFI_D_INFO, "IsctPei: PCI-EX Root Port: 0x%x ...\n", RpFunction));

    if ((MmioRead32 (RpBase + R_PCH_PCIE_SLCTL_SLSTS) & B_PCH_PCIE_SLCTL_SLSTS_PDS) != 0 && MmioRead16 (RpBase + R_PCH_PCIE_ID) == V_PCH_PCIE_VENDOR_ID) {
      //
      // Set WLAN PortBus = 1 to Read Endpoint.
      //
      MmioAndThenOr32(RpBase + R_PCH_PCIE_BNUM_SLT, 0xFF0000FF, 0x00010100);
      EpBase = MmPciAddress (0, 1, 0, 0, 0);

      //
      // A config write is required in order for the device to re-capture the Bus number,
      // according to PCI Express Base Specification, 2.2.6.2
      // Write to a read-only register VendorID to not cause any side effects.
      //
      MmioWrite16 (EpBase + R_PCH_PCIE_ID, 0);

      //
      // Check to see if the Device is a Network Device
      //
      if ((MmioRead16 (EpBase + PCI_CLASSCODE_OFFSET + 0x01) & 0xFF00) == (PCI_CLASS_NETWORK << 8)) { //PCI_CLASS_NETWORK_OTHER
        DEBUG ((EFI_D_INFO, "IsctPei: Found a network device on Root Port - 0x%x and device ID is - 0x%x\n", RpFunction, MmioRead16 (EpBase + R_PCH_PCIE_ID + 0x02)));

        //
        // Find out PMCSR register
        //
        CapPtr = MmioRead8 (EpBase + R_PCH_PCIE_CAPP);
        CapID = MmioRead8 (EpBase + CapPtr);
        NxtPtr = (UINT8) (MmioRead16 (EpBase + CapPtr) >> 8);
        PMCreg = CapPtr;

        while (CapID != 0x01) {
          CapID = MmioRead8 (EpBase + NxtPtr);
          if (CapID == 0x01) {
            PMCreg = NxtPtr;
            break;
          }
          NxtPtr = (UINT8) (MmioRead16 (EpBase + NxtPtr) >> 8);

          if (NxtPtr == 0){
            PMCreg = 0;
            break;
          }
        }

        if (PMCreg != 0) {
          PMCSR = PMCreg + 0x04;

          //
          // Check whether PME enabled. Set NetworkWakePME to 1 if device caused PME.
          //
          if (MmioRead16 (EpBase + PMCSR) & BIT15) {
            NetworkWakePME = 1;
            DEBUG ((EFI_D_INFO, "IsctPei: The network device 0x%x caused the PME\n", MmioRead16 (EpBase + R_PCH_PCIE_ID + 0x02)));
            //
            // Restore bus numbers on the WLAN bridge.
            //
            MmioAnd32(RpBase + R_PCH_PCIE_BNUM_SLT, 0xFF0000FF);
            break;
          }
        }
        //
        // Restore bus numbers on the WLAN bridge.
        //
        MmioAnd32(RpBase + R_PCH_PCIE_BNUM_SLT, 0xFF0000FF);
      }
    }
  }

  return NetworkWakePME;
}

EFI_STATUS
IsctGetWakeReason (
  IN CONST EFI_PEI_SERVICES     **PeiServices
  )
/*++

Routine Description:

  Get system Wake Reason and save into CMOS 72/73 for ACPI ASL to use. 

Arguments:

  PeiServices       General purpose services available to every PEIM.
  
Returns:

--*/
{
  EFI_STATUS                  Status;
  UINT16					  AcpiBase = 0;
  UINT16                      PM1STS;
  UINT16                      USB29VID;
  UINT16                      USB29STS;
  //UINT16                      USB26VID;
  //UINT16                      USB26STS;
  UINT32					  GPE0a_STS;
  UINT16                      xHCIVID;
  UINT16                      xHCISTS;
//  UINT16                      LanVID;
//  UINT16                      LanSTS;
  UINT8                       WakeReason;
//  UINT8                       WakeStatus = 0;
  UINTN                       Size;
  ISCT_PERSISTENT_DATA        IsctData;
  EFI_PEI_READ_ONLY_VARIABLE2_PPI  *ReadOnlyVariable;
  UINT8                       *IsctNvsPtr;

  //
  // Locate PEI Read Only Variable PPI.
  //
  Status = (*PeiServices)->LocatePpi (
                            PeiServices,
                            &gEfiPeiReadOnlyVariable2PpiGuid,
                            0,
                            NULL,
                            &ReadOnlyVariable
                            );
  ASSERT_EFI_ERROR (Status);

  Size = sizeof (ISCT_PERSISTENT_DATA);
  Status = ReadOnlyVariable->GetVariable (
                              ReadOnlyVariable,
                              ISCT_PERSISTENT_DATA_NAME,
                              &gIsctPersistentDataGuid,
                              NULL,
                              &Size,
                              &IsctData
                              );
  DEBUG ((EFI_D_INFO, "IsctPei: GetVariable for IsctData Status = %x \n", Status));                                
  ASSERT_EFI_ERROR (Status);

  DEBUG ((EFI_D_INFO, "IsctPei: IsctNvsPtr = %x \n", IsctData.IsctNvsPtr));

  //
  // Clear Isct Wake Reason
  //
  DEBUG ((EFI_D_INFO, "IsctPei: Previous Isct Wake Reason = %x \n", *(UINT8 *) IsctData.IsctNvsPtr));
  IsctNvsPtr  = (UINT8 *) IsctData.IsctNvsPtr;
  *IsctNvsPtr = 0;
  WakeReason = 0; 

  //
  // Initialize base address for Power Management 
  //
    AcpiBase = MmioRead16 (
                    PchPciDeviceMmBase (DEFAULT_PCI_BUS_NUMBER_PCH,
                    PCI_DEVICE_NUMBER_PCH_LPC,
                    PCI_FUNCTION_NUMBER_PCH_LPC) + R_PCH_LPC_ACPI_BASE
                    ) & B_PCH_LPC_ACPI_BASE_BAR;

  DEBUG ((EFI_D_INFO, "IsctGetWakeReason: AcpiBase = %x\n", AcpiBase));

  PM1STS  = IoRead16(AcpiBase + R_PCH_ACPI_PM1_STS);
  DEBUG ((EFI_D_INFO, "IsctPei: PM1_STS Value After read from ACPIBASE+00 = %x \n", PM1STS)); 
  GPE0a_STS = IoRead32(AcpiBase + R_PCH_ACPI_GPE0a_STS);
  DEBUG ((EFI_D_INFO, "IsctPei: GPE0a_STS Value After read from ACPIBASE+0x20 = %x \n", GPE0a_STS)); 

  PM1STS &= (B_PCH_ACPI_PM1_STS_PWRBTN | B_PCH_ACPI_PM1_STS_RTC | BIT14);

  //
  // Check PM1_STS
  //
  DEBUG ((EFI_D_INFO, "IsctPei: PM1_STS Value= %x \n", PM1STS));  
  DEBUG ((EFI_D_INFO, "  Bit set in PM1_STS: \n"));  
  switch (PM1STS){
    case B_PCH_ACPI_PM1_STS_PWRBTN:
      WakeReason |= 0x01; //User event
  DEBUG ((EFI_D_INFO, "    PowerButton\n"));  
      break;
    case B_PCH_ACPI_PM1_STS_RTC:
      WakeReason |= 0x04; //RTC Timer
  DEBUG ((EFI_D_INFO, "    RTC Timer\n")); 
      break;
    case BIT14:
      WakeReason |= 0x08; //Due to PME
  DEBUG ((EFI_D_INFO, "    PME\n")); 
      break;
    default:
      WakeReason = 0;
  DEBUG ((EFI_D_INFO, "    Unknown\n")); 
      break;
  }

  //
  // EHCI PME : Offset 0x54(15)
  //
  USB29VID = MmioRead16 (
             MmPciAddress (
               0,
               DEFAULT_PCI_BUS_NUMBER_PCH,
               PCI_DEVICE_NUMBER_PCH_USB,
               PCI_FUNCTION_NUMBER_PCH_EHCI,
               R_PCH_USB_VENDOR_ID
               ));

  USB29STS = MmioRead16 (
             MmPciAddress (
               0,
               DEFAULT_PCI_BUS_NUMBER_PCH,
               PCI_DEVICE_NUMBER_PCH_USB,
               PCI_FUNCTION_NUMBER_PCH_EHCI,
               R_PCH_EHCI_PWR_CNTL_STS
               )) & (B_PCH_EHCI_PWR_CNTL_STS_PME_STS | B_PCH_EHCI_PWR_CNTL_STS_PME_EN);

  if (USB29VID != 0xFFFF && USB29VID != 0){
    if (USB29STS == 0x8100){
      DEBUG ((EFI_D_INFO, "IsctPei: EHCI Wake\n"));  
      WakeReason |= 0x01; //User event
    }
  }

#if 0
  if (PchSeries == PchH) {
    USB26VID = MmioRead16 (
                 MmPciAddress (
                   0,
                   DEFAULT_PCI_BUS_NUMBER_PCH,
                   PCI_DEVICE_NUMBER_PCH_USB_EXT,
                   PCI_FUNCTION_NUMBER_PCH_EHCI,
                   R_PCH_USB_VENDOR_ID
                 ));

    USB26STS = MmioRead16 (
                 MmPciAddress (
                   0,
                   DEFAULT_PCI_BUS_NUMBER_PCH,
                   PCI_DEVICE_NUMBER_PCH_USB_EXT,
                   PCI_FUNCTION_NUMBER_PCH_EHCI,
                   R_PCH_EHCI_PWR_CNTL_STS
                 )) & (B_PCH_EHCI_PWR_CNTL_STS_PME_STS | B_PCH_EHCI_PWR_CNTL_STS_PME_EN);

    if (USB26VID != 0xFFFF && USB26VID != 0){
      if (USB26STS == 0x8100){
        DEBUG ((EFI_D_INFO, "IsctPei: EHCI Wake\n"));  
        WakeReason |= 0x01; //User Event
      }
    }
  }
#endif
  //
  // xHCI PME : Offset 0x74(15)
  //
  xHCIVID = MmioRead16 (
           MmPciAddress (
             0,
             DEFAULT_PCI_BUS_NUMBER_PCH,
             PCI_DEVICE_NUMBER_PCH_XHCI,
             PCI_FUNCTION_NUMBER_PCH_XHCI,
             R_PCH_USB_VENDOR_ID
             ));

  xHCISTS = MmioRead16 (
           MmPciAddress (
             0,
             DEFAULT_PCI_BUS_NUMBER_PCH,
             PCI_DEVICE_NUMBER_PCH_XHCI,
             PCI_FUNCTION_NUMBER_PCH_XHCI,
             R_PCH_XHCI_PWR_CNTL_STS
             )) & (B_PCH_XHCI_PWR_CNTL_STS_PME_STS | B_PCH_XHCI_PWR_CNTL_STS_PME_EN);

     
  if (xHCIVID != 0xFFFF && xHCIVID != 0){
     if (xHCISTS == 0x8100){
        DEBUG ((EFI_D_INFO, "IsctPei: xHCI Wake\n"));  
        WakeReason |= 0x01;		//User Event 0x08; //PME
     }
  }

#if 0  //EC is not supporting for this command, will be enabled after EC supports it
    SendKscCommand(KSC_C_GETWAKE_STATUS);
	if(!EFI_ERROR(Status)) {
		ReceiveKscData(&WakeStatus);
	}
//	SendKscCommand(KSC_C_CLEARWAKE_STATUS);

	DEBUG ((EFI_D_INFO, "IsctPei: EC Wake Status: %x\n", WakeStatus));
    switch (WakeStatus){
      case BIT0:  // Lid Wake
        WakeReason |= 0x01; //Bit0 is user event wake (PWR Button / LID )
        break;
      case BIT1: // EC Timer Wake / Periodic Wake
        WakeReason |= 0x02; //Bit1 is EC timer wake
        break;
      case BIT3: // PCIe Wake
        WakeReason |= 0x08; //Bit2 Wake due to PME
        break;
      default: // Unknown
        WakeReason |= 0x00;
        break;
    }
#endif

  //
  // Check for Network Device PME from PCIe if PME wake reason
  //
//  if((WakeReason & BIT3) == BIT3) //PME
//  {
    DEBUG ((EFI_D_INFO, "IsctPei: PME wake reason- check if from network device\n"));
    if(IsNetworkDevicePME())
    {
      WakeReason |= BIT3;	//BIT4;
      DEBUG ((EFI_D_INFO, "IsctPei: IsNetworkDevicePME() returned Yes\n"));
    }
 // }

  //
  // Set Isct Wake Reason
  //     
  DEBUG ((EFI_D_INFO, "IsctPei: Wake Reason reported to Agent= %x \n", WakeReason));                             
  *(UINT8 *)IsctData.IsctNvsPtr = WakeReason;

  return EFI_SUCCESS;
}


EFI_STATUS
EFIAPI
IsctPeiEntryPoint (
  IN CONST EFI_PEI_SERVICES     **PeiServices
  )
/*++

Routine Description:

  Set up 

Arguments:

  PeiServices       General purpose services available to every PEIM.
  
Returns:

--*/
{
  EFI_STATUS                      Status;

  UINT8                           IsctEnabled;
  EFI_PEI_READ_ONLY_VARIABLE2_PPI *PeiReadOnlyVarPpi = NULL;
  UINTN                           VarSize;
  SYSTEM_CONFIGURATION            SystemConfiguration;

  DEBUG ((EFI_D_INFO, "IsctPei Entry Point\n"));
  IsctEnabled = 0;

  //
  // Locate PEI Read Only Variable PPI.
  //
  Status = (**PeiServices).LocatePpi (
                             PeiServices,
                             &gEfiPeiReadOnlyVariable2PpiGuid,
                             0,
                             NULL,
                             &PeiReadOnlyVarPpi
                             );
  if (Status == EFI_SUCCESS) {
    VarSize = sizeof (SYSTEM_CONFIGURATION);
    Status = PeiReadOnlyVarPpi->GetVariable ( 
                                  PeiReadOnlyVarPpi, 
                                  PLATFORM_SETUP_VARIABLE_NAME, 
                                  &gEfiSetupVariableGuid,
                                  NULL,
                                  &VarSize,
                                  &SystemConfiguration
                                  );
    if (Status == EFI_SUCCESS) {
      if (SystemConfiguration.IsctConfiguration != 0) {
        IsctEnabled = 0x01;
      }
    }
  }

  if (IsctEnabled == 0) {
    DEBUG ((EFI_D_INFO, "Isct Disabled\n"));
    return EFI_SUCCESS;
  }
  else {
	Status = IsctGetWakeReason(PeiServices);
    ASSERT_EFI_ERROR (Status);
    DEBUG ((EFI_D_INFO, "IsctPei: IsctGetWakeReason Status = %x \n", Status));
  }
  
  return EFI_SUCCESS;
}
