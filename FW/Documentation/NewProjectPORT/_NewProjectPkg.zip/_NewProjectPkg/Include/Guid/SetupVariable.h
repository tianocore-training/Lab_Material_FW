//
// This file contains an 'Intel Peripheral Driver' and is
// licensed for Intel CPUs and chipsets under the terms of your
// license agreement with Intel or your vendor.  This file may
// be modified by the user, subject to additional terms of the
// license agreement
//
/*++

  Copyright (c) 2004 - 2014, Intel Corporation. All rights reserved.<BR>
  This software and associated documentation (if any) is furnished
  under a license and may only be used or copied in accordance
  with the terms of the license. Except as permitted by such
  license, no part of this software or documentation may be
  reproduced, stored in a retrieval system, or transmitted in any
  form or by any means without the express written consent of
  Intel Corporation.



Module Name:

    SetupVariable.h

Abstract:

    Driver configuration include file

 
--*/

#ifndef _SETUP_VARIABLE_H
#define _SETUP_VARIABLE_H

//
// ---------------------------------------------------------------------------
//
// Driver Configuration
//
// ---------------------------------------------------------------------------
//

//
// {EC87D643-EBA4-4bb5-A1E5-3F3E36B20DA9}
//
#define SYSTEM_CONFIGURATION_GUID\
  { \
    0xec87d643, 0xeba4, 0x4bb5, 0xa1, 0xe5, 0x3f, 0x3e, 0x36, 0xb2, 0xd, 0xa9 \
  }

#define ROOT_SECURITY_GUID\
  { \
    0xd387d688, 0xeba4, 0x45b5, 0xa1, 0xe5, 0x3f, 0x3e, 0x36, 0xb2, 0xd, 0x37 \
  }

//
// {6936B3BD-4350-46d9-8940-1FA20961AEB1}
//
#define SYSTEM_ROOT_MAIN_GUID\
  { \
     0x6936b3bd, 0x4350, 0x46d9, 0x89, 0x40, 0x1f, 0xa2, 0x9, 0x61, 0xae, 0xb1 \
  }

//  
// {21FEE8DB-0D29-477e-B5A9-96EB343BA99C}
//
#define ADDITIONAL_SYSTEM_INFO_GUID\
  { \
     0x21fee8db, 0xd29, 0x477e, 0xb5, 0xa9, 0x96, 0xeb, 0x34, 0x3b, 0xa9, 0x9c \
  }

#define SETUP_GUID { 0xEC87D643, 0xEBA4, 0x4BB5, 0xA1, 0xE5, 0x3F, 0x3E, 0x36, 0xB2, 0x0D, 0xA9 }

// {1B838190-4625-4ead-ABC9-CD5E6AF18FE0}
#define EFI_HII_EXPORT_DATABASE_GUID { 0x1b838190, 0x4625, 0x4ead, 0xab, 0xc9, 0xcd, 0x5e, 0x6a, 0xf1, 0x8f, 0xe0 }

#define PASSWORD_MAX_SIZE               20

#define MAX_CUSTOM_VID_TABLE_STATES 6
//
// Overclocking Source Defines
//
#define OVERCLOCK_SOURCE_BIOS       0
#define OVERCLOCK_SOURCE_OS         1

#define PCH_PCIE_MAX_ROOT_PORTS     4

#pragma pack(1)

// NOTE: When you add anything to this structure, 
//   you MUST add it to the very bottom!!!!
//   You must make sure the structure size is able to divide by 32!
typedef struct {

  //
  // Floppy
  //
  UINT8         Floppy;
  UINT8         FloppyLockHide;

  UINT8         FloppyWriteProtect;
  UINT8         FloppyWriteProtectLockHide;

  //
  // System ports
  //
  UINT8         Serial;
  UINT8         SerialLockHide;

  UINT8         Serial2;
  UINT8         Serial2LockHide;

  UINT8         Parallel;
  UINT8         ParallelLockHide;

  UINT8         ParallelMode;
  UINT8         ParallelModeLockHide;  

  UINT8         AllUsb;
  UINT8         UsbPortsLockHide;

  UINT8         Usb2;
  UINT8         Usb2LockHide;

  UINT8         UsbLegacy;
  UINT8         UsbLegacyLockHide;

  UINT8         Audio;
  UINT8         AudioLockHide;

  UINT8         Lan;
  UINT8         LanLockHide;

  //
  // Keyboard
  //
  UINT8         Numlock;
  UINT8         NumlockLockHide;

  //
  // ECIR
  //
  UINT8         ECIR;
  UINT8         ECIRLockHide;

  //
  // Power State
  //
  UINT8         PowerState;
  UINT8         PowerStateLockHide;

  //
  // Wake on RTC variables
  //
  UINT8         WakeOnRtcS5;
  UINT8         WakeOnRtcS5LockHide;
  UINT8         RTCWakeupDate;
  UINT8         RTCWakeupDateLockHide;
  UINT8         RTCWakeupTimeHour;
  UINT8         RTCWakeupHourLockHide;
  UINT8         RTCWakeupTimeMinute;
  UINT8         RTCWakeupMinuteLockHide;
  UINT8         RTCWakeupTimeSecond;
  UINT8         RTCWakeupSecondLockHide;

  //
  // Wake On Lan
  //
  UINT8         WakeOnLanS5;
  UINT8         WakeOnLanS5LockHide;

  //Spread spectrum
  UINT8         SpreadSpectrum;

  //
  // Boot Order
  //
  UINT8         BootOrder[8];
  UINT8         BootOrderLockHide;

  //
  // Hard Drive Boot Order
  //
  UINT8         HardDriveBootOrder[8];
  UINT8         HardDriveBootOrderLockHide;  

  //
  // CD Drive Boot Order
  //
  UINT8         CdDriveBootOrder[4];
  UINT8         CdDriveBootOrderLockHide;  

  //
  // FDD Drive Boot Order
  //
  UINT8         FddDriveBootOrder[4];
  UINT8         FddDriveBootOrderLockHide;  

  //
  // Drive Boot Order
  //
  UINT8         DriveBootOrder[16];
  UINT8         DriveBootOrderLockHide;  

  //
  // Boot Menu Type
  //
  UINT8         BootMenuType;
  UINT8         BootMenuTypeLockHide;  

  //
  // Boot from Removable Devices
  //
  UINT8         BootFloppy;
  UINT8         BootFloppyLockHide;

  //
  // Boot from Optical Devices
  //
  UINT8         BootCd;
  UINT8         BootCdLockHide;

  //
  // Boot from Network
  //
  UINT8         BootNetwork;
  UINT8         BootNetworkLockHide;

  //
  // Boot USB
  //
  UINT8         BootUsb;
  UINT8         BootUsbLockHide;

  //
  // USB Zip Emulation Type
  //
  UINT8         UsbZipEmulation;
  UINT8         UsbZipEmulationLockHide;

  //
  // USB Devices Boot First in Boot Order
  //
  UINT8         UsbDevicesBootFirst;
  UINT8         UsbDevicesBootFirstLockHide;

  //
  // USB Boot Device SETUP Emulation
  //
  UINT8         UsbSetupDeviceEmulation;
  UINT8         UsbSetupDeviceEmulationLockHide;

  //
  // BIOS INT13 Emulation for USB Mass Devices
  //
  UINT8         UsbBIOSINT13DeviceEmulation;
  UINT8         UsbBIOSINT13DeviceEmulationLockHide;

  //
  // BIOS INT13 Emulation Size for USB Mass Devices
  //
  UINT16        UsbBIOSINT13DeviceEmulationSize;
  UINT8         UsbBIOSINT13DeviceEmulationSizeLockHide;

  //
  // Dummy place holder to prevent VFR compiler problem.
  //
  UINT16        DummyDataForVfrBug;  // Don't change or use.

  //
  // Language Select
  //
  UINT8         LanguageSelect;

  //
  // SATA Type (Ide, Ahci, Raid)
  //
  UINT8         SataType;
  UINT8         SataTypeLockHide;
  UINT8         SataTestMode;

  //
  // Fixed Disk Boot Sector (Fdbs)
  //
  UINT8         Fdbs;
  UINT8         FdbsLockHide;

  //
  // DisplaySetupPrompt
  //
  UINT8         DisplaySetupPrompt;
  UINT8         DisplaySetupPromptLockHide;

  //
  // ASF
  //
  UINT8         Asf;
  UINT8         AsfLockHide;

  //
  // Event Logging
  //
  UINT8         EventLogging;
  UINT8         EventLoggingLockHide;

  //
  // Clear Event Log
  //
  UINT8         ClearEvents;
  UINT8         ClearEventsLockHide;

  //
  // Expansion Card Text
  //
  UINT8         ExpansionCardText;
  UINT8         ExpansionCardTextLockHide;

  //
  // Video Adaptor
  //
  UINT8         PrimaryVideoAdaptor;
  UINT8         PrimaryVideoAdaptorLockHide;

  //
  // Chassis intrusion
  //
  UINT8         IntruderDetection;
  UINT8         IntruderDetectionLockHide;

  //
  // User Access Level
  //
  UINT8         UserPasswordLevel;
  UINT8         UserPasswordLevelLockHide;

  //
  // Maximum FSB Automatic/Disable
  //
  UINT8         MaxFsb;
  UINT8         MaxFsbLockHide;

  //
  // Hard Disk Pre-delay
  //
  UINT8         HddPredelay;
  UINT8         HddPredelayLockHide;

  //
  // S.M.A.R.T. Mode
  //
  UINT8         SmartMode;
  UINT8         SmartModeLockHide;

  //
  // ACPI Suspend State
  //
  UINT8         AcpiSuspendState;
  UINT8         AcpiSuspendStateLockHide;  

  //
  // PCI Latency Timer
  //
  UINT8         PciLatency;
  UINT8         PciLatencyLockHide;  

  //
  // Fan Control
  //
  UINT8         FanControl;
  UINT8         FanControlLockHide;  

  //
  // CPU Fan Control
  //
  UINT8         CpuFanControl;
  UINT8         CpuFanControlLockHide;  

  //
  // Lowest Fan Speed
  //
  UINT8         LowestFanSpeed;
  UINT8         LowestFanSpeedLockHide;  

  //
  // Processor (CPU)
  //
  UINT8         CpuFlavor;

  UINT8         CpuidMaxValue;
  UINT8         CpuidMaxValueLockHide;
  
  UINT8         ExecuteDisableBit;
  UINT8         ExecuteDisableBitLockHide;  

  //
  // EIST or GV3 setup option
  //
  UINT8         ProcessorEistEnable;            
  UINT8         ProcessorEistEnableLockHide;

  //
  // C1E Enable
  //
  UINT8         ProcessorC1eEnable;
  UINT8         ProcessorC1eEnableLockHide;  

  //
  // Enabling CPU C-States of processor
  //
  UINT8         ProcessorCcxEnable;               
  UINT8         ProcessorCcxEnableLockHide;
  
  //
  // Package C-State Limit
  //
  UINT8         PackageCState;
  UINT8         PackageCStateLockHide;
  
  //
  // Enable/Disable NHM C3(ACPI C2) report to OS
  //
  UINT8         OSC2Report;
  UINT8         OSC2ReportLockHide;
  
  //
  // Enable/Disable NHM C6(ACPI C3) report to OS
  //
  UINT8         C6Enable;
  UINT8         C6EnableLockHide;
  
  //
  // Enable/Disable NHM C7(ACPI C3) report to OS
  //
  UINT8         C7Enable;
  UINT8         C7EnableLockHide;

  //
  // EIST/PSD Function select option
  //
  UINT8         ProcessorEistPsdFunc;
  UINT8         ProcessorEistPsdFuncLockHide;

  //
  // CPU Active Cores and SMT
  //
  UINT8         ActiveProcessorCores;
  UINT8         ActiveProcessorCoresLockHide;

  //
  // Hyper Threading
  //
  UINT8         ProcessorHyperThreadingDisable;
  UINT8         ProcessorHyperThreadingDisableLockHide;
  
  //
  // Enabling VMX
  //
  UINT8         ProcessorVmxEnable;
  UINT8         ProcessorVmxEnableLockHide;

  //
  // Enabling BIST
  //
  UINT8         ProcessorBistEnable;
  UINT8         ProcessorBistEnableLockHide;

  //
  // Disabling XTPR
  //
  UINT8         ProcessorxTPRDisable;
  UINT8         ProcessorxTPRDisableLockHide;

  //
  // Enabling XE
  //
  UINT8         ProcessorXEEnable;
  UINT8         ProcessorXEEnableLockHide;  

  //
  // Fast String
  //
  UINT8         FastStringEnable;
  UINT8         FastStringEnableLockHide;
  
  //
  // Monitor/Mwait
  //
  UINT8         MonitorMwaitEnable;
  UINT8         MonitorMwaitEnableLockHide;
  
  //
  // Machine Check
  //
  UINT8         MachineCheckEnable;
  UINT8         MachineCheckEnableLockHide;
  
  //
  // Turbo mode
  //
  UINT8         TurboModeEnable;
  UINT8         TurboModeEnableLockHide;  
  
  //
  // DCA setup option
  //
  UINT8         DcaEnable;
  UINT8         DcaEnableLockHide;
  
  //
  // DCA Prefetch Delay Value
  //
  UINT8         DcaPrefetchDelayValue;
  UINT8         DcaPrefetchDelayValueLockHide;
  
  //
  // Hardware Prefetch
  //
  UINT8         MlcStreamerPrefetcherEnable;
  UINT8         MlcStreamerPrefetcherEnableLockHide;
  
  //
  // Adjacent Cache Line Prefetch
  //
  UINT8         MlcSpatialPrefetcherEnable;
  UINT8         MlcSpatialPrefetcherEnableLockHide;

  //
  // DCU Streamer Prefetcher
  //
  UINT8         DCUStreamerPrefetcherEnable;
  UINT8         DCUStreamerPrefetcherEnableLockHide;

  //
  // DCU IP Prefetcher
  //
  UINT8         DCUIPPrefetcherEnable;
  UINT8         DCUIPPrefetcherEnableLockHide;

  //
  // Enable Processor XAPIC
  //
  UINT8         ProcessorXapic;
  UINT8         ProcessorXapicLockHide;
  
  //
  // Select BSP
  //
  UINT8         BspSelection;
  UINT8         BspSelectionLockHide;
  
  //
  // Non-Turbo Mode Processor Core Ratio Multiplier
  //
  UINT8         ProcessorFlexibleRatio;
  UINT8         ProcessorFlexibleRatioLockHide;
  
  //
  // Turbo-XE Mode Processor TDC Limit Override Enable
  //
  UINT8         ProcessorTDCLimitOverrideEnable;
  UINT8         ProcessorTDCLimitOverrideEnableLockHide;
  
  //
  // Turbo-XE Mode Processor TDC Limit
  //
  UINT16        ProcessorTDCLimit;
  UINT8         ProcessorTDCLimitLockHide;  
  
  //
  // Turbo-XE Mode Processor TDP Limit Override Enable
  //
  UINT8         ProcessorTDPLimitOverrideEnable;
  UINT8         ProcessorTDPLimitOverrideEnableLockHide;
  
  //
  // Turbo-XE Mode Processor TDP Limit
  //
  UINT16        ProcessorTDPLimit;
  UINT8         ProcessorTDPLimitLockHide;  
  
  //
  // For changing UC to WB
  //
  UINT8         MTRRDefTypeUncachable;
  UINT8         MTRRDefTypeUncachableLockHide;
  
  //
  // Virtual wire A or B
  //
  UINT8         ProcessorVirtualWireMode;
  UINT8         ProcessorVirtualWireModeLockHide;

  //
  // Ext Burn in
  // 
  UINT8         ExtBurnInEnable;
  UINT8         ExtBurnInEnableLockHide;

  //
  // CPU Burn-in Enable 0/1 No/Yes
  //
  UINT8         CpuBurnInEnable;
  UINT8         CpuBurnInEnableLockHide;
    
  //
  // CPU Power selection 0/1 Low/High
  //
  UINT8         CPUPow;
  UINT8         CPUPowLockHide;

  //
  // VID Value to use (0-63)
  //
  UINT8         VIDVal;
  UINT8         VIDValLockHide;

  //
  // BSEL Value to use (0-8)
  //
  UINT8         BSELVal;
  UINT8         BSELValLockHide;

  //
  // VCore Burn-in Mode 0/1/2/3 1.500V/1.550V/1.600V/1.625V
  //
  UINT8         VCoreBurnIn;
  UINT8         VCoreBurnInLockHide;

  //
  // VTT (Front Side Bus) Voltage Override
  //
  UINT8         VTtBurnIn;
  UINT8         VTtBurnInLockHide;

  //
  // PCI E Burn In
  //  
  UINT8         PCIeBurnIn;
  UINT8         PCIeBurnInLockHide;

  //
  // FSB Override Automatic/Manual
  //
  UINT8         FsbOverride;
  UINT8         FsbOverrideLockHide;

  //
  // FSB Frequency Override in MHz
  //
  UINT16        FsbFrequency;
  UINT8         FsbFrequencyLockHide;

  //
  // Mailbox variables to store default, CPU Multiplier and FSB Frequency.
  //
  UINT16        DefFsbFrequency;

  //
  // Used as a CPU Voltage Status.
  //
  UINT8         VIDValStatus;

  //
  // Ecc  0/1 Disable/Enable if supported
  //
  UINT8         EccEnable;
  UINT8         EccEnableLockHide;

  //
  // Memory
  //
  UINT8         MemoryMode;
  UINT8         MemoryModeLockHide;

  UINT16        MemorySpeed;
  UINT8         MemorySpeedLockHide;

  UINT8         UclkRatio;
  UINT8         UclkRatioLockHide;

  UINT8         MemoryRatio;
  UINT8         MemoryRatioLockHide;

  UINT8         MemoryTcl;
  UINT8         MemoryTclLockHide;

  UINT8         MemoryTrcd;
  UINT8         MemoryTrcdLockHide;

  UINT8         MemoryTrp;
  UINT8         MemoryTrpLockHide;

  UINT8         MemoryTras;
  UINT8         MemoryTrasLockHide;

  UINT16        MemoryTrfc; 
  UINT8         MemoryTrfcLockHide;

  UINT8         MemoryTrrd; 
  UINT8         MemoryTrrdLockHide;

  UINT8         MemoryTwr; 
  UINT8         MemoryTwrLockHide;

  UINT8         MemoryTwtr; 
  UINT8         MemoryTwtrLockHide;

  UINT8         MemoryTrtp; 
  UINT8         MemoryTrtpLockHide;

  UINT8         MemoryTrc; 
  UINT8         MemoryTrcLockHide;

  UINT8         MemoryTfaw; 
  UINT8         MemoryTfawLockHide;

  UINT8         MemoryTcwl; 
  UINT8         MemoryTcwlLockHide;

  UINT8         MemoryVoltage;
  UINT8         MemoryVoltageLockHide;

  //
  // Reference Voltage Override
  //
  UINT8         DimmDqRef;
  UINT8         DimmDqRefLockHide;
  UINT8         DimmCaRef;
  UINT8         DimmCaRefLockHide;

  //
  // Ratio Limit options for Turbo-Mode
  //
  UINT8         RatioLimit4C;
  UINT8         RatioLimit4CLockHide;
  UINT8         RatioLimit3C;
  UINT8         RatioLimit3CLockHide;
  UINT8         RatioLimit2C;
  UINT8         RatioLimit2CLockHide;
  UINT8         RatioLimit1C;
  UINT8         RatioLimit1CLockHide;


  //
  // Port 80 decode 0/1 - PCI/LPC
  UINT8         Port80Route;
  UINT8         Port80RouteLockHide;

  //
  // ECC Event Logging
  //
  UINT8         EccEventLogging;
  UINT8         EccEventLoggingLockHide;

  //
  // TPM Enable/Disable
  //
  UINT8         ETpm; 

  //
  // TPM question  0 = Disabled, 1 = Enabled
  //
  UINT8         ETpmClear;

  //
  // Secondary SATA Controller question  0 = Disabled, 1 = Enabled
  //
  UINT8         ExtSata;
  UINT8         ExtSataLockHide;

  //
  // Mode selection for Secondary SATA Controller (0=IDE, 1=RAID)
  //
  UINT8         ExtSataMode;
  UINT8         ExtSataModeLockHide;  

  //
  // LT Technology 0/1 -> Disable/Enable
  //
  UINT8         LtTechnology;
  UINT8         LtTechnologyLockHide;

  //
  // HPET Support 0/1 -> Disable/Enable
  //
  UINT8         Hpet;
  UINT8         HpetLockHide;

  //
  // ICH Function Level Reset enable/disable
  //
  UINT8         FlrCapability;
  UINT8         FlrCapabilityLockHide;

  // VT-d Option
  UINT8         VTdSupport;  
  UINT8         VTdSupportLockHide;  

  UINT8         InterruptRemap;
  UINT8         InterruptRemapLockHide;

  UINT8         Isoc;
  UINT8         IsocLockHide;

  UINT8         CoherencySupport;
  UINT8         CoherencySupportLockHide;

  UINT8         ATS;
  UINT8         ATSLockHide;

  UINT8         PassThroughDma;
  UINT8         PassThroughDmaLockHide;

  //
  // IGD option
  //
  UINT8         GraphicsDriverMemorySize;
  UINT8         GraphicsDriverMemorySizeLockHide;


  //
  // Discrete SATA Type (Ide, Raid, Ahci)
  //
  UINT8         ExtSataMode2;
  UINT8         ExtSataMode2LockHide;  

  UINT8         ProcessorHtMode;
  UINT8         ProcessorHtModeLockHide;  

  //
  // IGD Aperture Size question
  //
  UINT8         IgdApertureSize;
  UINT8         IgdApertureSizeLockHide;

  //
  // Boot Display Device
  //
  UINT8         BootDisplayDevice;
  UINT8         BootDisplayDeviceLockHide;


  //
  // System fan speed duty cycle
  //
  UINT8         SystemFanDuty;
  UINT8         SystemFanDutyLockHide;


  //
  // S3 state LED indicator
  //
  UINT8         S3StateIndicator;
  UINT8         S3StateIndicatorLockHide;

  //
  // S1 state LED indicator
  //
  UINT8         S1StateIndicator;
  UINT8         S1StateIndicatorLockHide;

  //
  // PS/2 Wake from S5
  //
  UINT8         WakeOnS5Keyboard;
  UINT8         WakeOnS5KeyboardLockHide;


  //
  // SATA Controller question  0 = Disabled, 1 = Enabled
  //
  UINT8         Sata;
  UINT8         SataLockHide;  
  
  //
  // PS2 port
  //
  UINT8         PS2;

  //
  // No VideoBeep
  //
  UINT8         NoVideoBeepEnable;

  //
  // Integrated Graphics Device
  //
  UINT8         Igd;

  //
  // Video Device select order
  //
  UINT8         VideoSelectOrder[8];

  // Flash update sleep delay
  UINT8         FlashSleepDelay;
  UINT8         FlashSleepDelayLockHide;

  //
  // Boot Display Device2
  //
  UINT8         BootDisplayDevice2;
  UINT8         BootDisplayDevice2LockHide;

  //
  // Flat Panel 
  //
  UINT8         EdpInterfaceType;
  UINT8         EdpInterfaceTypeLockHide;

  UINT8         LvdsInterfaceType;
  UINT8         LvdsInterfaceTypeLockHide;

  UINT8         ColorDepth;
  UINT8         ColorDepthLockHide;
  
  UINT8         EdidConfiguration;
  UINT8         EdidConfigurationLockHide;

  UINT8         MaxInverterPWM;
  UINT8         MaxInverterPWMLockHide;

  UINT8         PreDefinedEdidConfiguration;
  UINT8         PreDefinedEdidConfigurationLockHide;

  UINT16        ScreenBrightnessResponseTime;
  UINT8         ScreenBrightnessResponseTimeLockHide;

  UINT8         Serial3;
  UINT8         Serial3LockHide;
  
  UINT8         Serial4;
  UINT8         Serial4LockHide;

  UINT8         CurrentSetupProfile;
  UINT8         CurrentSetupProfileLockHide;

  //
  // FSC system Variable
  //
  UINT8         CPUFanUsage;
  UINT8         CPUFanUsageLockHide;
  UINT16        CPUUnderSpeedthreshold;
  UINT8         CPUUnderSpeedthresholdLockHide;
  UINT8         CPUFanControlMode;
  UINT8         CPUFanControlModeLockHide;
  UINT16        Voltage12UnderVolts;
  UINT8         Voltage12UnderVoltsLockHide;
  UINT16        Voltage12OverVolts;
  UINT8         Voltage12OverVoltsLockHide;
  UINT16        Voltage5UnderVolts;
  UINT8         Voltage5UnderVoltsLockHide;
  UINT16        Voltage5OverVolts;
  UINT8         Voltage5OverVoltsLockHide;
  UINT16        Voltage3p3UnderVolts;
  UINT8         Voltage3p3UnderVoltsLockHide;
  UINT16        Voltage3p3OverVolts;
  UINT8         Voltage3p3OverVoltsLockHide;
  UINT16        Voltage2p5UnderVolts;
  UINT8         Voltage2p5UnderVoltsLockHide;
  UINT16        Voltage2p5OverVolts;
  UINT8         Voltage2p5OverVoltsLockHide;
  UINT16        VoltageVccpUnderVolts;
  UINT8         VoltageVccpUnderVoltsLockHide;
  UINT16        VoltageVccpOverVolts;
  UINT8         VoltageVccpOverVoltsLockHide;
  UINT16        Voltage5BackupUnderVolts;
  UINT8         Voltage5BackupUnderVoltsLockHide;
  UINT16        Voltage5BackupOverVolts;
  UINT8         Voltage5BackupOverVoltsLockHide;
  UINT16        VS3p3StbyUnderVolt;
  UINT8         VS3p3StbyUnderVoltLockHide;
  UINT16        VS3p3StbyOverVolt;
  UINT8         VS3p3StbyOverVoltLockHide;
  UINT8         CPUFanMinDutyCycle;
  UINT8         CPUFanMinDutyCycleLockHide;
  UINT8         CPUFanMaxDutyCycle;
  UINT8         CPUFanMaxDutyCycleLockHide;
  UINT8         CPUFanOnDutyCycle;
  UINT8         CPUFanOnDutyCycleLockHide;
  UINT16        CpuOverTemp;
  UINT8         CpuOverTempLockHide;
  UINT16        CpuControlTemp;
  UINT8         CpuControlTempLockHide;
  UINT16        CpuAllOnTemp;
  UINT8         CpuAllOnTempLockHide;
  UINT8         CpuResponsiveness;
  UINT8         CpuResponsivenessLockHide;
  UINT8         CpuDamping;
  UINT8         CpuDampingLockHide;
  UINT16        PchOverTemp;
  UINT8         PchOverTempLockHide;
  UINT16        PchControlTemp;
  UINT8         PchControlTempLockHide;
  UINT16        PchAllOnTemp;
  UINT8         PchAllOnTempLockHide;
  UINT8         PchResponsiveness;
  UINT8         PchResponsivenessLockHide;
  UINT8         PchDamping;
  UINT8         PchDampingLockHide;
  UINT16        MemoryOverTemp;
  UINT8         MemoryOverTempLockHide;
  UINT16        MemoryControlTemp;
  UINT8         MemoryControlTempLockHide;
  UINT16        MemoryAllOnTemp;
  UINT8         MemoryAllOnTempLockHide;
  UINT8         MemoryResponsiveness;
  UINT8         MemoryResponsivenessLockHide;
  UINT8         MemoryDamping;
  UINT8         MemoryDampingLockHide;
  UINT16        VROverTemp;
  UINT8         VROverTempLockHide;
  UINT16        VRControlTemp;
  UINT8         VRControlTempLockHide;
  UINT16        VRAllOnTemp;
  UINT8         VRAllOnTempLockHide;
  UINT8         VRResponsiveness;
  UINT8         VRResponsivenessLockHide;
  UINT8         VRDamping;
  UINT8         VRDampingLockHide;

  UINT8         LvdsBrightnessSteps;
  UINT8         LvdsBrightnessStepsLockHide;
  UINT8         EdpDataRate;
  UINT8         EdpDataRateLockHide;
  UINT16        LvdsPowerOnToBacklightEnableDelayTime;
  UINT8         LvdsPowerOnToBacklightEnableDelayTimeLockHide;
  UINT16        LvdsPowerOnDelayTime;
  UINT8         LvdsPowerOnDelayTimeLockHide;
  UINT16        LvdsBacklightOffToPowerDownDelayTime;
  UINT8         LvdsBacklightOffToPowerDownDelayTimeLockHide;
  UINT16        LvdsPowerDownDelayTime;
  UINT8         LvdsPowerDownDelayTimeLockHide;
  UINT16        LvdsPowerCycleDelayTime;
  UINT8         LvdsPowerCycleDelayTimeLockHide;

  UINT8         IgdFlatPanel;
  UINT8         IgdFlatPanelLockHide;
  UINT8         Lan2;
  UINT8         Lan2LockHide;

  UINT8         SwapMode;
  UINT8         SwapModeLockHide;

  UINT8         Sata0HotPlugCap;
  UINT8         Sata0HotPlugCapLockHide;
  UINT8         Sata1HotPlugCap;
  UINT8         Sata1HotPlugCapLockHide;

  UINT8         UsbCharging;
  UINT8         UsbChargingLockHide;

  UINT8         Cstates;
  UINT8         EnableC4;
  UINT8         EnableC6;
  
  UINT8          FastBoot;
  UINT8          EfiNetworkSupport;
  UINT8          PxeRom;

  //Add for PpmPlatformPlicy
  UINT8          EnableGv;
  UINT8          EnableCx;
  UINT8          EnableCxe;
  UINT8          EnableTm;
  UINT8          EnableProcHot;
  UINT8          TStatesEnable;
  UINT8          HTD;
  UINT8          SingleCpu;
  UINT8          BootPState;
  UINT8          FlexRatio;
  UINT8          FlexVid;
  UINT8          QuietBoot;
 	UINT8           LegacyUSBBooting;

  UINT8         MinInverterPWM;
  //
  // Thermal Policy Values
  //
  UINT8           EnableDigitalThermalSensor;
  UINT8           PassiveThermalTripPoint;
  UINT8           PassiveTc1Value;
  UINT8           PassiveTc2Value;
  UINT8           PassiveTspValue;
  UINT8           DisableActiveTripPoints; 
  UINT8           CriticalThermalTripPoint;
  UINT8           IchPciExp[4];
  UINT8           DeepStandby;
  UINT8           AlsEnable;
  UINT8           IgdLcdIBia;
  UINT8           LogBootTime;


  UINT8           PcieRootPortIOApic[4];
  UINT8           IffsEnable;
  UINT8           IffsOnS3RtcWake;
  UINT8           IffsS3WakeTimerMin;
  UINT8           IffsOnS3CritBattWake;
  UINT8           IffsCritBattWakeThreshold;
  UINT8           ScramblerSupport;
  UINT8           SecureBoot;
  UINT8           SecureBootCustomMode;
  UINT8           SecureBootUserPhysicalPresent;
  UINT8           CoreFreMultipSelect;
  UINT8           MaxCState;
  UINT8           PanelScaling;
  UINT8           IgdLcdIGmchBlc;
  UINT8           GfxBoost;
  UINT8           IgdThermal;
  UINT8           SecEnable;
  UINT8           fTPM;
  UINT8           SecFlashUpdate;
  UINT8           SecFirmwareUpdate;
  UINT8           MeasuredBootEnable;
  UINT8           UseProductKey;
  //Image Signal Processor PCI Device Configuration
  //
  UINT8         ISPDevSel;
  UINT8         ISPEn;
  // Passwords
  UINT16          UserPassword[PASSWORD_MAX_SIZE];
  UINT16          AdminPassword[PASSWORD_MAX_SIZE];
  UINT8           Tdt;
  UINT8           Recovery;
  UINT8           Suspend;
  UINT8           TdtState;
  UINT8           TdtEnrolled;
  UINT8           PBAEnable;

  UINT8           HpetBootTime;
  UINT8           UsbDebug;
  UINT8           Lpe;
  //
  // LPSS Configuration
  //
  UINT8           LpssPciModeEnabled;  
  //Scc
  UINT8           LpsseMMCEnabled;
  UINT8           LpssSdioEnabled;
  UINT8           LpssSdcardEnabled;
  UINT8           LpssSdCardSDR25Enabled;
  UINT8           LpssSdCardDDR50Enabled;
  UINT8           LpssMipiHsi;
  UINT8           LpsseMMC45Enabled;
  UINT8           LpsseMMC45DDR50Enabled;
  UINT8           LpsseMMC45HS200Enabled;
  UINT8           LpsseMMC45RetuneTimerValue;
  UINT8           eMMCBootMode;
  
  //LPSS2
  UINT8           LpssDma1Enabled;
  UINT8           LpssI2C0Enabled;
  UINT8           LpssI2C1Enabled;
  UINT8           LpssI2C2Enabled;
  UINT8           LpssI2C3Enabled;
  UINT8           LpssI2C4Enabled;
  UINT8           LpssI2C5Enabled;
  UINT8           LpssI2C6Enabled;
  //LPSS1
  UINT8           LpssDma0Enabled;
  UINT8           LpssPwm0Enabled;
  UINT8           LpssPwm1Enabled;
  UINT8           LpssHsuart0Enabled;
  UINT8           LpssHsuart1Enabled;
  UINT8           LpssSpiEnabled;
  UINT8           I2CTouchAd;

  UINT8   GTTSize;
  //
  // DVMT5.0 Graphic memory setting
  //
  UINT8   IgdDvmt50PreAlloc;
  UINT8   IgdDvmt50TotalAlloc;
  UINT8   IgdTurboEnabled;
  
  //
  // Usb Config
  //
  UINT8   UsbAutoMode;       // PCH controller Auto mode
  UINT8   UsbXhciSupport;
  UINT8   Hsic0;
  UINT8   PchUsb30Mode;
  UINT8   PchUsb30Streams;
  UINT8   PchUsb20;
  UINT8   PchUsbPerPortCtl;
  UINT8   PchUsbPort[8];
  UINT8   PchUsbRmh;
  UINT8   PchUsbOtg;
  UINT8   PchUsbVbusOn;       //OTG VBUS control
  UINT8   PchFSAOn;       //FSA control  
  UINT8   EhciPllCfgEnable;


  //Gbe
  UINT8         PcieRootPortSpeed[PCH_PCIE_MAX_ROOT_PORTS];
  UINT8   SlpLanLowDc;

  //
  // ISCT Configuration
  //
  UINT8   IsctConfiguration;
  UINT8   IsctNotificationControl;
  UINT8   IsctWlanPowerControl;
  UINT8   IsctWwanPowerControl;
  UINT8	  IsctSleepDurationFormat;
  UINT8	  IsctRFKillSupport;
  UINT8	  WlanNGFFCardPresence;
  UINT8	  WlanUHPAMCardPresence;
  //
  // Azalia Configuration
  //
  UINT8   PchAzalia;
  UINT8   AzaliaVCiEnable;
  UINT8   AzaliaDs;
  UINT8   AzaliaPme;
  UINT8   HdmiCodec;

  UINT8   UartInterface;
  UINT8   PcuUart1;
  //UINT8   PcuUart2;//for A0
  UINT8   StateAfterG3;
  UINT8   EnableClockSpreadSpec;
  UINT8   EnableRenderStandby;
  UINT8   GOPEnable;
  UINT8   GOPBrightnessLevel;                     //Gop Brightness level
  UINT8   PavpMode;
  UINT8   SeCOpEnable;
  UINT8   SeCModeEnable;
  UINT8   SeCEOPEnable;
  UINT8   SeCEOPDone;
  
  UINT8   HdmiCodecPortB;
  UINT8   HdmiCodecPortC;
  UINT8   HdmiCodecPortD;
  UINT8   LidStatus;
  UINT8   SdpProfile;                              // DPTF:  an enumeration for Brand Strings.
  UINT8   EnableDptf;                              // Option to enable/disable DPTF
  UINT16  ProcCriticalTemp;                        // Processor critical temperature
  UINT16  ProcPassiveTemp;                         // Processor passive temperature
  UINT16  GenericCriticalTemp0;                    // Critical temperature value for generic sensor0 participant
  UINT16  GenericPassiveTemp0;                     // Passive temperature value for generic sensor0 participant
  UINT16  GenericCriticalTemp1;                    // Critical temperature value for generic sensor1 participant
  UINT16  GenericPassiveTemp1;                     // Passive temperature value for generic sensor1 participant
  UINT16  GenericCriticalTemp2;                    // Critical temperature value for generic sensor2 participant
  UINT16  GenericPassiveTemp2;                     // Passive temperature value for generic sensor2 participant
  UINT16  GenericCriticalTemp3;                    // Critical temperature value for generic sensor3 participant
  UINT16  GenericPassiveTemp3;                     // Passive temperature value for generic sensor3 participant
  UINT16  GenericCriticalTemp4;                    // Critical temperature value for generic sensor3 participant
  UINT16  GenericPassiveTemp4;                     // Passive temperature value for generic sensor3 participant  
  UINT8   Clpm;                                    // Current low power mode
  UINT8   SuperDebug;                              // DPTF Super debug option
  UINT32  LPOEnable;                               // DPTF: Instructs the policy to use Active Cores if they are available. If this option is set to 0, then policy does not use any active core controls ?even if they are available
  UINT32  LPOStartPState;                          // DPTF: Instructs the policy when to initiate Active Core control if enabled. Returns P state index.
  UINT32  LPOStepSize;                             // DPTF: Instructs the policy to take away logical processors in the specified percentage steps
  UINT32  LPOPowerControlSetting;                  // DPTF: Instructs the policy whether to use Core offliing or SMT offlining if Active core control is enabled to be used in P0 or when power control is applied. 1 ?SMT Off lining 2- Core Off lining
  UINT32  LPOPerformanceControlSetting;            // DPTF: Instructs the policy whether to use Core offliing or SMT offlining if Active core control is enabled to be used in P1 or when performance control is applied.1 ?SMT Off lining 2- Core Off lining 
  UINT8   EnableDppm;                              // DPTF: Controls DPPM Policies (enabled/disabled)
  UINT8   DptfProcessor;
  UINT8   DptfSysThermal0;
  UINT8   DptfSysThermal1;
  UINT8   DptfSysThermal2;
  UINT8   DptfSysThermal3;
  UINT8   DptfSysThermal4;    
  UINT8   DptfChargerDevice;
  UINT8   DptfDisplayDevice;
  UINT8   DptfSocDevice;
  UINT8   AmbientTripPointChange;             // DPTF: Controls whether _ATI changes other participant's trip point(enabled/disabled)
  UINT8   DptfAllowHigherPerformance;			  // DPTF: Allow higher performance on AC/USB - (Enable/Disable)  
  UINT8   PmicEnable;
  UINT8   S0ix;
  UINT8   TSEGSizeSel;
  UINT8   ACPIMemDbg;
  UINT8	  ExISupport;
  UINT8   BatteryChargingSolution;                 //0-non ULPMC 1-ULPMC
  UINT8   PnpSettings;
  UINT8   CfioPnpSettings;
  UINT8   PchEhciDebug;
  UINT8   CRIDSettings;
  UINT8   ULPMCFWLock;
  UINT8   SpiRwProtect;
  UINT8   PmWeights;
  UINT8   PDMConfig;
  UINT16  LmMemSize;
  UINT8   PunitBIOSConfig;
  UINT8   LpssSdioMode;
  UINT8   ENDBG2;
  UINT8   WittEnable;
  UINT8   UtsEnable;
  UINT8   TristateLpc;
  UINT8   DopCG;
  UINT8   UsbXhciLpmSupport;
  UINT8   EnableAESNI;
  UINT8   SecureErase;
  
  UINT8   MmioSize;


  UINT8   SAR1;

  UINT8   DisableCodec262;
  UINT8   OsSelection;
  UINT8   PcieDynamicGating;        // Need PMC enable it first from PMC 0x3_12 MCU 318.

  UINT8   MipiDsi;

  //Added flow control item for UART1 and UART2
  UINT8  LpssHsuart0FlowControlEnabled;
  UINT8  LpssHsuart1FlowControlEnabled;
  
  UINT8   SdCardRemovable; // ACPI reporting MMC/SD media as: removable/non-removable
  
  UINT8   GpioWakeCapability;
  UINT8   RtcBattery;
  UINT8   LpeAudioReportedByDSDT;

} SYSTEM_CONFIGURATION;
#pragma pack()

#ifndef PLATFORM_SETUP_VARIABLE_NAME
#define PLATFORM_SETUP_VARIABLE_NAME             L"Setup"
#endif

#pragma pack(1)
typedef struct{
  // Passwords
  UINT16        UserPassword[PASSWORD_MAX_SIZE];
  UINT16        AdminPassword[PASSWORD_MAX_SIZE];
  UINT16        DummyDataForVfrBug;  // Don't change or use

} SYSTEM_PASSWORDS;
#pragma pack()

//
// #defines for Drive Presence
//
#define EFI_HDD_PRESENT       0x01
#define EFI_HDD_NOT_PRESENT   0x00
#define EFI_CD_PRESENT        0x02
#define EFI_CD_NOT_PRESENT    0x00

#define EFI_HDD_WARNING_ON    0x01
#define EFI_CD_WARNING_ON     0x02
#define EFI_SMART_WARNING_ON  0x04
#define EFI_HDD_WARNING_OFF   0x00
#define EFI_CD_WARNING_OFF    0x00
#define EFI_SMART_WARNING_OFF 0x00

#ifndef VFRCOMPILE
extern EFI_GUID gEfiSetupVariableGuid;
#endif

#define SETUP_DATA SYSTEM_CONFIGURATION

#endif // #ifndef _SETUP_VARIABLE
