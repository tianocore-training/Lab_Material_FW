//
// This file contains an 'Intel Peripheral Driver' and is
// licensed for Intel CPUs and chipsets under the terms of your
// license agreement with Intel or your vendor.  This file may
// be modified by the user, subject to additional terms of the
// license agreement
//
/*++

  Copyright (c) 2004 - 2014, Intel Corporation. All rights reserved.<BR>
  This software and associated documentation (if any) is furnished
  under a license and may only be used or copied in accordance
  with the terms of the license. Except as permitted by such
  license, no part of this software or documentation may be
  reproduced, stored in a retrieval system, or transmitted in any
  form or by any means without the express written consent of
  Intel Corporation.



Module Name:

  Asf.h

Abstract:

  Alert Standard Format address variable

--*/

#ifndef AlertStandardFormat_h_included
#define AlertStandardFormat_h_included

//#include "Efi.h"

#pragma pack(1)

//
// ASF address
//

// {3D995FB4-4F05-4073-BE72-A19CFB5DE690}
#define  ALERT_STANDARD_FORMAT_VARIABLE_GUID \
  {0x3d995fb4, 0x4f05, 0x4073, 0xbe, 0x72, 0xa1, 0x9c, 0xfb, 0x5d, 0xe6, 0x90}

#define ALERT_STANDARD_FORMAT_VARIABLE_NAME (L"ASF")
#define ASCII_ALERT_STANDARD_FORMAT_VARIABLE_NAME ("ASF")

extern EFI_GUID gAlertStandardFormatGuid;
extern CHAR16   gAlertStandardFormatName[];

typedef struct {
  UINT8   SmbusAddr;
  struct {
    UINT32  VendorSpecificId;
    UINT16  SubsystemDeviceId;
    UINT16  SubsystemVendorId;
    UINT16  Interface;
    UINT16  DeviceId;
    UINT16  VendorId;
    UINT8   VendorRevision;
    UINT8   DeviceCapabilities;
  } Udid;
  struct {
    UINT8     SubCommand;
    UINT8     Version;
    UINT32    IanaId;
    UINT8     SpecialCommand;
    UINT16    SpecialCommandParam;
    UINT16    BootOptionsBits;
    UINT16    OemParam;
  } AsfBootOptions;
  struct {
    UINT8     Bus;
    UINT8     Device;
    UINT8     Function;
    UINT16    VendorId;
    UINT16    DeviceId;
    UINT16    IderCmdBar;
    UINT16    IderCtrlBar;
    UINT8     IderIrq;
    UINT16    SolBar;
    UINT8     SolIrq;
  } PciInfo;
  struct {
  UINT8   IamtProvisioningStatus;
  BOOLEAN IamtIsProvisioned;
  } IamtInfo;
  struct {
    BOOLEAN FlashUpdatingIsAllowed;
  } MeInfoForEbu;
  UINT32  EitBPFAddress;
} EFI_ASF_VARIABLE;

#pragma pack()

#endif

