//
// This file contains an 'Intel Peripheral Driver' and is
// licensed for Intel CPUs and chipsets under the terms of your
// license agreement with Intel or your vendor.  This file may
// be modified by the user, subject to additional terms of the
// license agreement
//
/*++

  Copyright (c) 2004 - 2014, Intel Corporation. All rights reserved.<BR>
  This software and associated documentation (if any) is furnished
  under a license and may only be used or copied in accordance
  with the terms of the license. Except as permitted by such
  license, no part of this software or documentation may be
  reproduced, stored in a retrieval system, or transmitted in any
  form or by any means without the express written consent of
  Intel Corporation.


Module Name:

  IdccData.h

Abstract:

--*/

#ifndef _IDCCDATAHUB_GUID_H_
#define _IDCCDATAHUB_GUID_H_

// This GUID is for the IDCC related data found in the Data Hub
#define IDCC_DATA_HUB_GUID \
  { 0x788e1d9f, 0x1eab, 0x47d2, 0xa2, 0xf3, 0x78, 0xca, 0xe8, 0x7d, 0x60, 0x12 }

extern EFI_GUID gIdccDataHubGuid;

#pragma pack(1)
typedef struct {
  UINT32    Type;
  UINT32    RecordLength;
} EFI_IDCC_DATA_HEADER;

typedef struct {
  EFI_IDCC_DATA_HEADER  IdccHeader;
  UINT32                Tcontrol;
} EFI_IDCC_TCONTROL;

typedef struct {
  UINT32    EntryCount;
} EFI_IDCC_CLOCK_COMMON;

typedef struct {
  UINT8     Polarity;
  UINT8     Percent;
  UINT32    FpValue;
} EFI_IDCC_TYPE_2_DATA;

typedef struct {
  UINT8     SetupVal;
  UINT32    FpValue;
} EFI_IDCC_TYPE_3_4_DATA;

typedef struct {
  EFI_IDCC_DATA_HEADER  IdccHeader;
  UINT32                ProcessorRatio;
} EFI_IDCC_PROCESSOR_RATIO;

typedef struct {
  EFI_IDCC_DATA_HEADER  IdccHeader;
  UINT32                BoardFormFactor;
} EFI_IDCC_BOARD_FORM_FACTOR;

typedef struct {
  EFI_IDCC_DATA_HEADER  IdccHeader;
  UINT32                ProcessorInfo;
} EFI_IDCC_PROCESSOR_INFO;

#define EFI_IDCC_PROCESSOR_UNCON    (1 << 0)  // Bit 0: UnCon CPU 
#define EFI_IDCC_PROCESSOR_UNLOCK   (1 << 1)  // Bit 1: UnLock CPU
#define EFI_IDCC_PROCESSOR_CNR      (1 << 2)  // Bit 2: CNR CPU
#define EFI_IDCC_PROCESSOR_KNF      (1 << 3)  // Bit 3: KNF CPU

typedef struct {
  EFI_IDCC_DATA_HEADER  IdccHeader;
  UINT32    MinFSB;
  UINT32    MaxFSB;
  UINT8     StepFSB;
} EFI_IDCC_FSB_DATA;

#pragma pack()

#define EFI_IDCC_POSITIVE   0
#define EFI_IDCC_NEGATIVE   1

// Board Form Factor equates
#define ATX_FORM_FACTOR		0x00
#define BTX_FORM_FACTOR		0x01


#define EFI_IDCC_TCONTROL_TYPE          1
#define EFI_IDCC_FSB_TYPE               2
#define EFI_IDCC_PCI_TYPE               3
#define EFI_IDCC_PCIE_TYPE              4
#define EFI_IDCC_PROC_RATIO_TYPE        5
#define EFI_IDCC_BOARD_FORM_FACTOR_TYPE 6
#define EFI_IDCC_PROC_INFO_TYPE         7
#define EFI_IDCC_FSB_DATA_TYPE          8

#endif
