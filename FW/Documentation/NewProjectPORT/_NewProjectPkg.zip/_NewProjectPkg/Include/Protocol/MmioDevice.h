//
// This file contains an 'Intel Peripheral Driver' and is
// licensed for Intel CPUs and chipsets under the terms of your
// license agreement with Intel or your vendor.  This file may
// be modified by the user, subject to additional terms of the
// license agreement
//
/*++

  Copyright (c) 2004 - 2014, Intel Corporation. All rights reserved.<BR>
  This software and associated documentation (if any) is furnished
  under a license and may only be used or copied in accordance
  with the terms of the license. Except as permitted by such
  license, no part of this software or documentation may be
  reproduced, stored in a retrieval system, or transmitted in any
  form or by any means without the express written consent of
  Intel Corporation.

**/

#ifndef __MMIO_DEVICE_H__
#define __MMIO_DEVICE_H__

///
/// Protocol to define for the MMIO device
//
typedef struct {
  ///
  /// Address of a GUID
  ///
  EFI_GUID *Guid;

  ///
  /// Context for the protocol
  ///
  VOID *Context;
} EFI_MMIO_DEVICE_PROTOCOL_ITEM;


typedef struct _EFI_MMIO_DEVICE_PROTOCOL  EFI_MMIO_DEVICE_PROTOCOL;

///
///  The MMIO device protocol defines a memory mapped I/O device
///  for use by the system.
///
struct _EFI_MMIO_DEVICE_PROTOCOL {
  ///
  /// Pointer to an ACPI_EXTENDED_HID_DEVICE_PATH structure
  /// containing HID/HidStr and CID/CidStr values.
  ///
  /// See the note below associated with the UnitIdentification
  /// field.
  ///
  CONST ACPI_EXTENDED_HID_DEVICE_PATH *AcpiPath;

  ///
  /// Allow the use of a shared template for the AcpiPath.
  ///
  /// If this value is non-zero UID value then the AcpiPath must
  /// be a template which contains only the HID/HidStr and CID/CidStr
  /// values.  The UID/UidStr values in the AcpiPath must be zero!
  //
  /// If this value is zero then the AcpiPath is not shared and
  /// must contain either a non-zero UID value or a UidStr value.
  ///
  UINT32 UnitIdentification;

  ///
  /// Hardware revision - ACPI _HRV value
  ///
  UINT32 HardwareRevision;

  ///
  /// Pointer to a data structure containing the controller
  /// resources and configuration.  At a minimum this points
  /// to an EFI_PHYSICAL_ADDRESS for the base address of the
  /// MMIO device.
  ///
  CONST VOID *DriverResources;

  ///
  /// Number of protocols in the array
  ///
  UINTN ProtocolCount;

  ///
  /// List of protocols to define
  ///
  CONST EFI_MMIO_DEVICE_PROTOCOL_ITEM *ProtocolArray;
};

extern EFI_GUID gEfiMmioDeviceProtocolGuid;

#endif  //  __MMIO_DEVICE_H__
