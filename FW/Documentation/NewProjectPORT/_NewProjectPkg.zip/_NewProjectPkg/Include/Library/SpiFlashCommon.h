//
// This file contains an 'Intel Peripheral Driver' and is      
// licensed for Intel CPUs and chipsets under the terms of your
// license agreement with Intel or your vendor.  This file may 
// be modified by the user, subject to additional terms of the 
// license agreement                                           
//
/** @file

  The header file includes the common header files, defines
  internal structure and functions used by SpiFlashCommonLib.

Copyright (c) 2011, Intel Corporation. All rights reserved.<BR>
This software and associated documentation (if any) is furnished
under a license and may only be used or copied in accordance
with the terms of the license. Except as permitted by such
license, no part of this software or documentation may be
reproduced, stored in a retrieval system, or transmitted in any
form or by any means without the express written consent of
Intel Corporation.

**/

#ifndef __SPI_FLASH_COMMON_H__
#define __SPI_FLASH_COMMON_H__

#include <Uefi.h>
#include <Library/BaseLib.h>
#include <Library/PcdLib.h>
#include <Library/DebugLib.h>
#include <Library/BaseMemoryLib.h>
#include <Library/MemoryAllocationLib.h>
#include <Library/UefiDriverEntryPoint.h>
#include <Library/UefiBootServicesTableLib.h>
#include <Protocol/Spi.h>

//
// Serial Flash Status Register definitions
//
#define SF_SR_BUSY  0x01  // Indicates if internal write operation is in progress
#define SF_SR_WEL   0x02  // Indicates if device is memory write enabled
#define SF_SR_BP0   0x04  // Block protection bit 0
#define SF_SR_BP1   0x08  // Block protection bit 1
#define SF_SR_BP2   0x10  // Block protection bit 2
#define SF_SR_BP3   0x20  // Block protection bit 3
#define SF_SR_WPE   0x3C  // Enable write protection on all blocks
#define SF_SR_AAI   0x40  // Auto Address Increment Programming status
#define SF_SR_BPL   0x80  // Block protection lock-down
//
// Operation Instruction definitions for  the Serial Flash Device
//
//
#define SF_INST_WRSR          0x01  // Write Status Register
#define SF_INST_PROG          0x02  // Byte Program
#define SF_INST_READ          0x03  // Read
#define SF_INST_WRDI          0x04  // Write Disable
#define SF_INST_RDSR          0x05  // Read Status Register
#define SF_INST_WREN          0x06  // Write Enable
#define SF_INST_HS_READ       0x0B  // High-speed Read
#define SF_INST_SERASE        0x20  // Sector Erase (4KB)
#define SF_INST_BERASE        0x52  // Block Erase (32KB)
#define SF_INST_64KB_ERASE    0xD8  // Block Erase (64KB)
#define SF_INST_EWSR          0x50  // Enable Write Status Register
#define SF_INST_READ_ID       0xAB  // Read ID
#define SF_INST_JEDEC_READ_ID 0x9F  // JEDEC Read ID
#define SF_INST_DOFR          0x3B  // Dual Output Fast Read
#define SF_INST_SFDP          0x5A  // Serial Flash Discovery Parameters
// -------------------------------------------------------------------
//
#define SECTOR_SIZE_4KB   0x1000      // Common 4kBytes sector size
#define SECTOR_SIZE_64KB  0x10000     // Common 64kBytes sector size
#define BLOCK_SIZE_64KB   0x00010000  // Common 64kBytes block size
#define MAX_FWH_SIZE      0x00100000  // 8Mbit (Note that this can also be used for the 4Mbit )

#define SPI_16MB_SIZE             0x00200000
#define SPI_32MB_SIZE             0x00400000
#define SPI_64MB_SIZE             0x00800000
#define SPI_128MB_SIZE            0x01000000

//
// Prefix Opcode Index on the host SPI controller
//
typedef enum {
  SPI_WREN, // Prefix Opcode 0: Write Enable
  SPI_EWSR, // Prefix Opcode 1: Enable Write Status Register
} PREFIX_OPCODE_INDEX;

//
// Opcode Menu Index on the host SPI controller
//
typedef enum {
  SPI_READ_ID,    // Opcode 0: READ ID, Read cycle with address
  SPI_READ,       // Opcode 1: READ, Read cycle with address
  SPI_RDSR,       // Opcode 2: Read Status Register, No address
  SPI_WRDI_SFDP,  // Opcode 3: Write Disable or Discovery Parameters, No address
  SPI_SERASE,     // Opcode 4: Sector Erase (4KB), Write cycle with address
  SPI_BERASE,     // Opcode 5: Block Erase (32KB), Write cycle with address
  SPI_PROG,       // Opcode 6: Byte Program, Write cycle with address
  SPI_WRSR,       // Opcode 7: Write Status Register, No address
} SPI_OPCODE_INDEX;

//
// SPI Command Configuration
//   Frequency       The expected frequency to be used (value to be programmed to the SSFC
//                   Register)
//   Operation       Which Hardware Sequencing required operation this opcode respoinds to.
//                   The required operations are listed in EDS Table 5-55: "Hardware
//                   Sequencing Commands and Opcode Requirements"
//                   If the opcode does not corresponds to any operation listed, use
//                   EnumSpiOperationOther, and provides TYPE and Code for it in
//                   SpecialOpcodeEntry.
//
typedef struct _SPI_CHIP_COMMAND_CONFIG {
  SPI_CYCLE_FREQUENCY Frequency;
  SPI_OPERATION       Operation;
} SPI_CHIP_COMMAND_CONFIG;

//
// Special Opcode entries
//   OpcodeIndex     Opcode Menu Index whose Opcode Type/Menu Configuration Register need to be
//                   overrided or programmed per "Type" and "Code". Filled this field with 0xFF
//                   as the end tag of SpecialOpcodeEntry.
//   Type            Operation Type (value to be programmed to the OPTYPE register)
//   Code            The opcode (value to be programmed to the OPMENU register)
//
typedef struct _SPI_CHIP_SPECIAL_OPCODE_ENTRY {
  UINT8           OpcodeIndex;
  SPI_OPCODE_TYPE Type;
  UINT8           Code;
} SPI_CHIP_SPECIAL_OPCODE_ENTRY;

//
// Initialization data that can be used to identify SPI flash part
//    DeviceId0       Device ID0 of the SPI device
//    DeviceId1       Device ID1 of the SPI device
//    FlashChipSize   The size of flash chip
//
typedef struct _SPI_CHIP_DATA {
  UINT8  DeviceId0;
  UINT8  DeviceId1;
  UINT32 FlashChipSize;
} SPI_CHIP_DATA;

//
// Initialization data table loaded to the SPI host controller
//    VendorId            Vendor ID of the SPI device
//    TypeDataNum         The number of TypeData
//    TypeData            The initialization data that can be used to identify SPI flash part
//    PrefixOpcode        Prefix opcodes which are loaded into the SPI host controller
//    SpiCmdConfig        Determines Opcode Type, Menu and Frequency of the SPI commands
//    SpecialOpcodeEntry  Special Opcode entry for the special operations.
//
// Note:  Most of time, the SPI flash parts with the same vendor would have the same
//        Prefix Opcode, Opcode menu, so you can provide one table for the SPI flash parts with
//        the same vendor.
//

typedef struct _SPI_CHIP_INIT_DATA {
  UINT8                          VendorId;
  UINT8                          TypeDataNum;
  SPI_CHIP_DATA                  *TypeData;
  UINT8                          PrefixOpcode[SPI_NUM_PREFIX_OPCODE];
  SPI_CHIP_COMMAND_CONFIG        SpiCmdConfig[SPI_NUM_OPCODE];
  SPI_CHIP_SPECIAL_OPCODE_ENTRY  *SpecialOpcodeEntry;
} SPI_CHIP_INIT_DATA;

/**
  Register supported spi flash device info.

  @param[in]  SpiFlashDevice       A point to those supported spi flash devices.

  @retval EFI_SUCCESS              The handlers were registered successfully.
**/
EFI_STATUS
EFIAPI
RegisterSupportedFlashDevice (
  IN  SPI_CHIP_INIT_DATA     *SpiFlashDevice
  );

/**
  Test if it's supported spi flash device.

  @retval EFI_SUCCESS              The tested spi flash device is supported.
  @retval EFI_UNSUPPORTED          The tested spi flash device is not supported.

**/
EFI_STATUS
EFIAPI
SpiFlashInit (
  VOID
  );

/**
  Enable or disable block protection on the Serial Flash device.

  @param[in]  Lock              TRUE to lock. FALSE to unlock.

  @retval     EFI_SUCCESS       Opertion is successful.
  @retval     EFI_DEVICE_ERROR  If there is any device errors.  

**/
EFI_STATUS
EFIAPI
SpiFlashLock (
  IN    BOOLEAN                   Lock
  );

/**
  Read NumBytes bytes of data from the address specified by
  PAddress into Buffer.

  @param[in]      Address       The starting physical address of the read.
  @param[in,out]  NumBytes      On input, the number of bytes to read. On output, the number
                                of bytes actually read.
  @param[out]     Buffer        The destination data buffer for the read.

  @retval         EFI_SUCCESS       Opertion is successful.
  @retval         EFI_DEVICE_ERROR  If there is any device errors.  
  
**/
EFI_STATUS
EFIAPI
SpiFlashRead (
  IN     UINTN                        Address,
  IN OUT UINT32                       *NumBytes,
     OUT UINT8                        *Buffer
  );

/**
  Write NumBytes bytes of data from Buffer to the address specified by
  PAddresss.

  @param[in]      Address         The starting physical address of the write.
  @param[in,out]  NumBytes        On input, the number of bytes to write. On output,
                                  the actual number of bytes written.
  @param[in]      Buffer          The source data buffer for the write.

  @retval         EFI_SUCCESS       Opertion is successful.
  @retval         EFI_DEVICE_ERROR  If there is any device errors.  

**/
EFI_STATUS 
EFIAPI
SpiFlashWrite (
  IN     UINTN                      Address,
  IN OUT UINT32                     *NumBytes,
  IN     UINT8                      *Buffer
  );

/**
  Erase the block starting at Address.

  @param[in]  Address         The starting physical address of the block to be erased.
                              This library assume that caller garantee that the PAddress
                              is at the starting address of this block.
  @param[in]  NumBytes        On input, the number of bytes of the logical block to be erased.
                              On output, the actual number of bytes erased.
  
  @retval     EFI_SUCCESS.      Opertion is successful.
  @retval     EFI_DEVICE_ERROR  If there is any device errors.  

**/
EFI_STATUS 
EFIAPI
SpiFlashBlockErase (
  IN    UINTN                     Address,
  IN    UINTN                     *NumBytes
  );

#endif
