//
// This file contains an 'Intel Peripheral Driver' and is
// licensed for Intel CPUs and chipsets under the terms of your
// license agreement with Intel or your vendor.  This file may
// be modified by the user, subject to additional terms of the
// license agreement
//
/*++

  Copyright (c) 2004 - 2014, Intel Corporation. All rights reserved.<BR>
  This software and associated documentation (if any) is furnished
  under a license and may only be used or copied in accordance
  with the terms of the license. Except as permitted by such
  license, no part of this software or documentation may be
  reproduced, stored in a retrieval system, or transmitted in any
  form or by any means without the express written consent of
  Intel Corporation.

**/

#ifndef __BASE_USBDEVICEMODE_LIB_H__
#define __BASE_USBDEVICEMODE_LIB_H__

#pragma pack(1)
typedef struct {
    UINT8  bLength;
    UINT8  bDescriptorType;
    UINT8  bMaxBurst;
    UINT8  bmAttributes;
    UINT16 wBytesPerInterval;
} endpointCompanionDescriptor;
#pragma pack()

#pragma pack(1)
typedef struct {
    UINT8  bLength;
    UINT8  bDescriptorType;
    UINT8  bEndpointAddress;
    UINT8  bmAttributes;
    UINT16 wMaxPacketSize;
    UINT8  bInterval;
} endpointDescriptor;
#pragma pack()

typedef struct {
    endpointDescriptor          *pEpDesc;
    endpointCompanionDescriptor *pEpCompDesc;
} USB_DEV_EP_INFO;    //usbdEpInfo; 

typedef struct {
    VOID        *pBuf;
    UINT32    dataLen;
} USBD_IO_INFO;

typedef struct {
    USBD_IO_INFO     ioInfo;
    USB_DEV_EP_INFO  epInfo;
} USBD_IO_REQ;


/**
**/
UINTN
EFIAPI
usbdInitDCI (
  VOID
  );

/**

**/
BOOLEAN
EFIAPI
fbInit (
  OUT  VOID  *pParams
  );

/**


**/
BOOLEAN
EFIAPI
fbDeinit (
  VOID 
  );

/**

**/
BOOLEAN
EFIAPI
fbStart (
  VOID
  );

/**

**/
BOOLEAN
EFIAPI
fbStop (
  VOID
  );

BOOLEAN
EFIAPI
usbdSetMmioBar (
  UINT32 mmioBar
  );
  
BOOLEAN
EFIAPI
udciDeinit (
  VOID    *pUdciHndl,
  UINT32  flags
  );  
  
BOOLEAN
EFIAPI
udciIsr (
  VOID    *pUdciHndl
  );    
  
BOOLEAN
EFIAPI
udciConnect (
  VOID    *pUdciHndl
  );    
    
BOOLEAN
EFIAPI
udciDisconnect (
  VOID    *pUdciHndl
  );    
  
BOOLEAN
EFIAPI
udciSetAddress (
  VOID    *pUdciHndl,
  UINT8   address
  );     
  
BOOLEAN
EFIAPI
udciInitEp (
  VOID            *pUdciHndl,
  USB_DEV_EP_INFO *pEpInfo
  );      
  
  
BOOLEAN
EFIAPI
udciEnableEp (
  VOID            *pUdciHndl,
  USB_DEV_EP_INFO *pEpInfo
  );     
  
BOOLEAN
EFIAPI
udciDisableEp (
  VOID            *pUdciHndl,
  USB_DEV_EP_INFO *pEpInfo
  );    
  
BOOLEAN
EFIAPI
udciStallEp (
  VOID            *pUdciHndl,
  USB_DEV_EP_INFO *pEpInfo
  );   

BOOLEAN
EFIAPI
udciClearStallEp (
  VOID            *pUdciHndl,
  USB_DEV_EP_INFO *pEpInfo
  );       
  
  
BOOLEAN
EFIAPI
udciEp0TxStatus (
  VOID            *pUdciHndl
  );       
    
  
BOOLEAN
EFIAPI
udciEpTxData (
  VOID        *pUdciHndl,
  USBD_IO_REQ *pIoReq
  );      

BOOLEAN
EFIAPI
udciEpRxData (
  VOID        *pUdciHndl,
  USBD_IO_REQ *pIoReq
  );      
    
BOOLEAN
EFIAPI
udciRegisterCallbacks (
  VOID            *pUdciHndl
  );       
        
     
#endif // 
