//
// This file contains an 'Intel Peripheral Driver' and is
// licensed for Intel CPUs and chipsets under the terms of your
// license agreement with Intel or your vendor.  This file may
// be modified by the user, subject to additional terms of the
// license agreement
//
/*++

  Copyright (c) 2004 - 2014, Intel Corporation. All rights reserved.<BR>
  This software and associated documentation (if any) is furnished
  under a license and may only be used or copied in accordance
  with the terms of the license. Except as permitted by such
  license, no part of this software or documentation may be
  reproduced, stored in a retrieval system, or transmitted in any
  form or by any means without the express written consent of
  Intel Corporation.


Module Name:

 DfuGpio.h

Abstract:

  
--*/
#ifndef _DXE_DFU_GPIO_H_
#define _DXE_DFU_GPIO_H_


typedef
EFI_STATUS
(EFIAPI *PLATFORM_GPIO_PIN_DIRECTION_GET) (
    IN UINT8 Community,
   	IN UINT8 PinNumber,
	OUT UINT8 *PinDirection
);

typedef
EFI_STATUS
(EFIAPI *PLATFORM_GPIO_PIN_DIRECTION_SET) (
    IN UINT8 Community,
   	IN UINT8 PinNumber,
	IN UINT8 PinDirection
);

typedef
EFI_STATUS
(EFIAPI *PLATFORM_GPIO_PIN_GET) (
    IN UINT8 Community,
    IN UINT8 PinNumber,
	OUT UINT32 *PinValue
);

typedef
EFI_STATUS
(EFIAPI *PLATFORM_GPIO_PIN_SET) (
    IN UINT8 Community,
    IN UINT8 PinNumber
);

typedef
EFI_STATUS
(EFIAPI *PLATFORM_GPIO_PIN_CLEAR) (
    IN UINT8 Community,
    IN UINT8 PinNumber
);

typedef
EFI_STATUS
(EFIAPI *PLATFORM_GPIO_CONFIGURE_PIN_EX) (
    IN UINT8 Community,
	IN UINT8 PinNumber,
	IN UINT8  ConfigureMask,
	IN UINT32 PadConf0,
	IN UINT32 PadConf1,
	IN UINT32 PadVal,
	IN UINT32 PadDtf
);

#pragma pack()

typedef struct _GPIO_OPERATION_PROTOCOL {
   PLATFORM_GPIO_PIN_DIRECTION_GET   PlatformGpioPinDirectionGet;
   PLATFORM_GPIO_PIN_DIRECTION_SET   PlatformGpioPinDirectionSet;
   PLATFORM_GPIO_PIN_GET			PlatformGpioPinGet;
   PLATFORM_GPIO_PIN_SET			PlatformGpioPinSet;
   PLATFORM_GPIO_PIN_CLEAR			PlatformGpioPinClear;
   PLATFORM_GPIO_CONFIGURE_PIN_EX   PlatformGpioConfigurePinEx;
} GPIO_OPERATION_PROTOCOL;

extern EFI_GUID gEfiGpioOperationProtocolGuid;

#endif
