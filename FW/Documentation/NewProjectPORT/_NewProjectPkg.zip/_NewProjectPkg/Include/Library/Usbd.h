//
// This file contains an 'Intel Peripheral Driver' and is
// licensed for Intel CPUs and chipsets under the terms of your
// license agreement with Intel or your vendor.  This file may
// be modified by the user, subject to additional terms of the
// license agreement
//
/*++

  Copyright (c) 2004 - 2014, Intel Corporation. All rights reserved.<BR>
  This software and associated documentation (if any) is furnished
  under a license and may only be used or copied in accordance
  with the terms of the license. Except as permitted by such
  license, no part of this software or documentation may be
  reproduced, stored in a retrieval system, or transmitted in any
  form or by any means without the express written consent of
  Intel Corporation.


**/          

#ifndef _EFI_FAST_BOOT_LIB_
#define _EFI_FAST_BOOT_LIB_

#include <Uefi.h>
#include <Library/UefiLib.h>
#include <Library/DebugLib.h>
#include <Library/ShellCEntryLib.h>
#include <Library/IoLib.h>
#include <Library/TimerLib.h>
#include <Library/UsbDeviceModeLib.h>
#include <Protocol/RunTimeUsbDeviceMode.h>
#include <Library/UefiBootServicesTableLib.h>
#include <PchRegs.h>



typedef struct  {
    UINT16 DevProductId;          // Product ID value for standard USB Device Descriptor
    UINT16 DevBcd;                // BCD value for standard USB Device Descriptor 
//    CHAR8  *pDevProductStr;       // Pointer to NULL terminated wide char string 
//    CHAR8  *pDevSerialNumStr;     // Pointer to NULL terminated wide char string 
    CHAR16  *pDevProductStr;       // Pointer to NULL terminated wide char string 
    CHAR16  *pDevSerialNumStr;     // Pointer to NULL terminated wide char string 
    UINT32 KernelLoadAddr;        // kernel base load address, not including any fastboot header 
    UINT32 KernelEntryOffset;     // offset from load address 
    UINT32 TimeoutMs;             // Timeout in ms for connecting to host. If 0, waits forever 
} FASTBOOTCMDPARAM;

FASTBOOTCMDPARAM FastbootParams;

#define PCIEX_BASE_ADDRESS  0xE0000000
#define PCI_EXPRESS_BASE_ADDRESS ((VOID *) (UINTN) PCIEX_BASE_ADDRESS)
#define MmPciAddress( Segment, Bus, Device, Function, Register ) \
  ( (UINTN)PCI_EXPRESS_BASE_ADDRESS + \
    (UINTN)(Bus << 20) + \
    (UINTN)(Device << 15) + \
    (UINTN)(Function << 12) + \
    (UINTN)(Register) \
  )

/* Fastboot configurable device strings. Must be NULL terminated */
static CHAR16 gStrProduct[] = {L'I', L'n', L't', L'e', L'l', L' ', L'A', L'n', L'd', L'r',L'o',L'i',L'd',L' ',L'A',L'D',L'B',L' ',L'I',L'n',L't',L'e',L'r',L'f',L'a',L'c',L'e',L'\0'};
static CHAR16 gStrSerialNumber[] = {L'I', L'N', L'T', L'1', L'2', L'3', L'4', L'5', L'6', L'\0'};

EFI_STATUS
EFIAPI
FastBootDataInit (
VOID
  );

EFI_STATUS
EFIAPI
FastBootStart (
VOID
  );

#endif
