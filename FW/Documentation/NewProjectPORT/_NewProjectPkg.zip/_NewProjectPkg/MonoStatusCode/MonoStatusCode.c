/*++
  This file contains an 'Intel Peripheral Driver' and is        
  licensed for Intel CPUs and chipsets under the terms of your  
  license agreement with Intel or your vendor.  This file may   
  be modified by the user, subject to additional terms of the   
  license agreement                                             
--*/
/** @file

  Copyright (c) 2004 - 2014, Intel Corporation. All rights reserved.<BR>
  This software and associated documentation (if any) is furnished
  under a license and may only be used or copied in accordance
  with the terms of the license. Except as permitted by such
  license, no part of this software or documentation may be
  reproduced, stored in a retrieval system, or transmitted in any
  form or by any means without the express written consent of
  Intel Corporation.

Module Name:


  MonoStatusCode.c

Abstract:

  PEIM to provide the status code functionality, to aid in system debug.
  It includes output to 0x80 port and/or to serial port.  
  This PEIM is monolithic. Different platform should provide different library.

--*/

#include "MonoStatusCode.h"
#include "PlatformStatusCode.h"
#define CMOS_EFI_DEBUG              0x14

//
// Module globals
//
EFI_PEI_PROGRESS_CODE_PPI     mStatusCodePpi = { PlatformReportStatusCode };

EFI_PEI_PPI_DESCRIPTOR  mPpiListStatusCode = {
  (EFI_PEI_PPI_DESCRIPTOR_PPI | EFI_PEI_PPI_DESCRIPTOR_TERMINATE_LIST),
  &gEfiPeiStatusCodePpiGuid,
  &mStatusCodePpi
};

//
// Function implemenations
//
EFI_STATUS
EFIAPI
TranslateDxeStatusCodeToPeiStatusCode (
  IN EFI_STATUS_CODE_TYPE     CodeType,
  IN EFI_STATUS_CODE_VALUE    Value,
  IN UINT32                   Instance,
  IN EFI_GUID                 * CallerId,
  IN EFI_STATUS_CODE_DATA     * Data OPTIONAL
  )
/*++

Routine Description:

  Translate from a DXE status code interface into a PEI-callable
  interface, making the PEI the least common denominator..

Arguments:

  Same as DXE ReportStatusCode RT service
  
Returns:

  None

--*/
{
  return PlatformReportStatusCode (NULL, CodeType, Value, Instance, CallerId, Data);
}

EFI_STATUS
EFIAPI
InitializeDxeReportStatusCode (
  IN const EFI_PEI_SERVICES       **PeiServices
  )
/*++

Routine Description:

  Build a hob describing the status code listener that has been installed.
  This will be used by DXE code until a runtime status code listener is 
  installed.

Arguments:

  PeiServices      - General purpose services available to every PEIM.
    
Returns:

  Status -  EFI_SUCCESS if the interface could be successfully
            installed

--*/
{
  EFI_STATUS  Status = EFI_UNSUPPORTED;

  VOID        *Instance;
  
  VOID        *Result;
  
  Instance = (VOID *) (UINTN) TranslateDxeStatusCodeToPeiStatusCode;

  Result = BuildGuidDataHob (
            &gEfiStatusCodeRuntimeProtocolGuid,
            &Instance,
            sizeof (VOID *)
            );
  if (Result != NULL) {
    Status = EFI_SUCCESS;
  }
  return Status;
}

VOID
EFIAPI
InitializeMonoStatusCode (
  IN EFI_FFS_FILE_HEADER       *FfsHeader,
  IN CONST EFI_PEI_SERVICES          **PeiServices
  )
/*++

Routine Description:

  Initialize the platform status codes and publish the platform status code 
  PPI.

Arguments:

  FfsHeader   - FV this PEIM was loaded from.
  PeiServices - General purpose services available to every PEIM.
    
Returns:

  Status -  EFI_SUCCESS

--*/
{
  EFI_STATUS  Status;

  //
  // Initialize status code listeners.
  //
  PlatformInitializeStatusCode (FfsHeader, PeiServices);

  //
  // Publish the status code capability to other modules
  //
  Status = (*PeiServices)->InstallPpi (PeiServices, &mPpiListStatusCode);

  ASSERT_EFI_ERROR (Status);

  DEBUG ((DEBUG_ERROR, "\nMono Status Code PEIM Loaded\n"));

  return ;
}
