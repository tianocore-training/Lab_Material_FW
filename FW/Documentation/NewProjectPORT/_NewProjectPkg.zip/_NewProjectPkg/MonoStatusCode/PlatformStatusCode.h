//
// This file contains an 'Intel Peripheral Driver' and is
// licensed for Intel CPUs and chipsets under the terms of your
// license agreement with Intel or your vendor.  This file may
// be modified by the user, subject to additional terms of the
// license agreement
//
/*++

  Copyright (c) 2004 - 2014, Intel Corporation. All rights reserved.<BR>
  This software and associated documentation (if any) is furnished
  under a license and may only be used or copied in accordance
  with the terms of the license. Except as permitted by such
  license, no part of this software or documentation may be
  reproduced, stored in a retrieval system, or transmitted in any
  form or by any means without the express written consent of
  Intel Corporation.

Module Name:

  PlatformStatusCode.h 
   
Abstract:

  Contains Platform specific implementations required to use status codes.

--*/

#ifndef _PLATFORM_STATUS_CODE_H_
#define _PLATFORM_STATUS_CODE_H_


#define CONFIG_PORT0    0x4E
#define INDEX_PORT0     0x4E
#define DATA_PORT0      0x4F
#define PCI_IDX        0xCF8
#define PCI_DAT        0xCFC

#include "MonoStatusCode.h"

/*++

Copyright (c)  1999 - 2005 Intel Corporation. All rights reserved
This software and associated documentation (if any) is furnished
under a license and may only be used or copied in accordance
with the terms of the license. Except as permitted by such
license, no part of this software or documentation may be
reproduced, stored in a retrieval system, or transmitted in any
form or by any means without the express written consent of
Intel Corporation.


Module Name:

  Port80StatusCodeLib.h

Abstract:

  Lib to provide status code reporting via port 80.

--*/

#ifndef _PEI_PORT_80_STATUS_CODE_H_
#define _PEI_PORT_80_STATUS_CODE_H_



//
// Status code reporting function
//
EFI_STATUS
Port80ReportStatusCode (
  IN CONST EFI_PEI_SERVICES         **PeiServices,
  IN EFI_STATUS_CODE_TYPE     CodeType,
  IN EFI_STATUS_CODE_VALUE    Value,
  IN UINT32                   Instance,
  IN CONST EFI_GUID                 * CallerId,
  IN CONST EFI_STATUS_CODE_DATA     * Data OPTIONAL
  )
/*++

Routine Description:

  GC_TODO: Add function description

Arguments:

  PeiServices - GC_TODO: add argument description
  CodeType    - GC_TODO: add argument description
  Value       - GC_TODO: add argument description
  Instance    - GC_TODO: add argument description
  CallerId    - GC_TODO: add argument description
  Data        - GC_TODO: add argument description

Returns:

  GC_TODO: add return values

--*/
;

#endif

//#include "SerialStatusCodeLib.h"
/*++

Copyright (c)  1999 - 2005 Intel Corporation. All rights reserved
This software and associated documentation (if any) is furnished
under a license and may only be used or copied in accordance
with the terms of the license. Except as permitted by such
license, no part of this software or documentation may be
reproduced, stored in a retrieval system, or transmitted in any
form or by any means without the express written consent of
Intel Corporation.


Module Name:

  SerialStatusCodeLib.h

Abstract:

  Lib to provide Serial I/O status code reporting.

--*/

#ifndef _PEI_SERIAL_STATUS_CODE_LIB_H_
#define _PEI_SERIAL_STATUS_CODE_LIB_H_


#include <Guid/StatusCodeDataTypeId.h>
#include <Guid/StatusCodeDataTypeDebug.h>
#include <Library/ReportStatusCodeLib.h>
#include <Library/PrintLib.h>
#include <Library/BaseMemoryLib.h>
//
// Initialization function
//
VOID
SerialInitializeStatusCode (
  VOID
  )
/*++

Routine Description:

  GC_TODO: Add function description

Arguments:

  None

Returns:

  GC_TODO: add return values

--*/
;

//
// Status code reporting function
//
EFI_STATUS
SerialReportStatusCode (
  IN CONST EFI_PEI_SERVICES         **PeiServices,
  IN EFI_STATUS_CODE_TYPE     CodeType,
  IN EFI_STATUS_CODE_VALUE    Value,
  IN UINT32                   Instance,
  IN CONST EFI_GUID                 * CallerId,
  IN CONST EFI_STATUS_CODE_DATA     * Data OPTIONAL
  )
/*++

Routine Description:

  GC_TODO: Add function description

Arguments:

  PeiServices - GC_TODO: add argument description
  CodeType    - GC_TODO: add argument description
  Value       - GC_TODO: add argument description
  Instance    - GC_TODO: add argument description
  CallerId    - GC_TODO: add argument description
  Data        - GC_TODO: add argument description

Returns:

  GC_TODO: add return values

--*/
;

#endif



extern EFI_PEI_PROGRESS_CODE_PPI    mStatusCodePpi;
extern EFI_PEI_PPI_DESCRIPTOR mPpiListStatusCode;
#define EFI_SIGNATURE_16(A, B)        ((A) | (B << 8))
#define EFI_SIGNATURE_32(A, B, C, D)  (EFI_SIGNATURE_16 (A, B) | (EFI_SIGNATURE_16 (C, D) << 16))
#define STATUSCODE_PEIM_SIGNATURE EFI_SIGNATURE_32 ('p', 's', 't', 'c')

typedef struct {
  UINT32                    Signature;
  EFI_FFS_FILE_HEADER       *FfsHeader;
  EFI_PEI_NOTIFY_DESCRIPTOR StatusCodeNotify;
} STATUSCODE_CALLBACK_STATE_INFORMATION;

#pragma pack(1)
typedef struct {
  UINT16  Limit;
  UINT32  Base;
} GDT_DSCRIPTOR;
#pragma pack()

#define STATUSCODE_PEIM_FROM_THIS(a) \
  BASE_CR ( \
  a, \
  STATUSCODE_CALLBACK_STATE_INFORMATION, \
  StatusCodeNotify \
  )

VOID
EFIAPI
PlatformInitializeStatusCode (
  IN EFI_FFS_FILE_HEADER       *FfsHeader,
  IN CONST EFI_PEI_SERVICES    **PeiServices
  );


//
// Function declarations
//
EFI_STATUS
EFIAPI
MemoryDiscoveredPpiNotifyCallback (
  IN EFI_PEI_SERVICES           **PeiServices,
  IN EFI_PEI_NOTIFY_DESCRIPTOR  *NotifyDescriptor,
  IN VOID                       *Ppi
  )
/*++

Routine Description:

  Install Firmware Volume Hob's once there is main memory

Arguments:

  PeiServices      - General purpose services available to every PEIM.
  NotifyDescriptor - Not Used 
  Ppi              - Not Used
  
Returns:

  Status -  EFI_SUCCESS if the interface could be successfully
            installed

--*/
;

#endif
