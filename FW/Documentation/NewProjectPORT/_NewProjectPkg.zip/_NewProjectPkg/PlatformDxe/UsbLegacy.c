/*++
  This file contains an 'Intel Peripheral Driver' and is        
  licensed for Intel CPUs and chipsets under the terms of your  
  license agreement with Intel or your vendor.  This file may   
  be modified by the user, subject to additional terms of the   
  license agreement                                             
--*/
/** @file

  Copyright (c) 2004 - 2014, Intel Corporation. All rights reserved.<BR>
  This software and associated documentation (if any) is furnished
  under a license and may only be used or copied in accordance
  with the terms of the license. Except as permitted by such
  license, no part of this software or documentation may be
  reproduced, stored in a retrieval system, or transmitted in any
  form or by any means without the express written consent of
  Intel Corporation.

Module Name:


  UsbLegacy.c
    
Abstract:

  The Usb Legacy Protocol is used provide a standard interface to the
  UsbLegacy code for platform modifications of operation.
  
  
 

--*/
#include "PlatformDxe.h"
#include <Guid/SetupVariable.h>
#include <Protocol/UsbLegacyPlatform.h>


#include "UsbLegacy.h"
#include "BoardUsbLegacy.h"

KEY_ELEMENT mKeyList[] = PLATFORM_KEY_LIST;

//
// Local  prototypes
//
EFI_USB_LEGACY_PLATFORM_PROTOCOL    mUsbLegacyPlatform;


EFI_STATUS
GetUsbPlatformOptions (
  IN   EFI_USB_LEGACY_PLATFORM_PROTOCOL *This,
  OUT  USB_LEGACY_MODIFIERS           *UsbLegacyModifiers
  )
/*++

  Routine Description:
    Return all platform information that can modify USB legacy operation

  Arguments:
    This                - Protocol instance pointer.
    UsbLegacyModifiers  - List of keys to monitor from. This includes both

  Returns:
    EFI_SUCCESS   - Modifiers exist.
    EFI_NOT_FOUND - Modifiers not not exist.

--*/

{
  UsbLegacyModifiers->UsbLegacyEnable           = 0x00;
  UsbLegacyModifiers->UsbZip                    = 0x00;
  UsbLegacyModifiers->UsbZipEmulation           = 0x00;
  UsbLegacyModifiers->UsbFixedDiskWpBootSector  = 0x00;
  UsbLegacyModifiers->UsbBoot                   = 0x00;
  //
  // Check SETUP for behavior modifications
  //
  //
  // mSystemConfiguration.UsbLegacy uses negative logic. 0 = enabled.
  //
  UsbLegacyModifiers->UsbLegacyEnable = 
       mSystemConfiguration.UsbLegacy + 1; 

  UsbLegacyModifiers->UsbZip = 0x02;

  UsbLegacyModifiers->UsbZipEmulation = 
       mSystemConfiguration.UsbZipEmulation;

  UsbLegacyModifiers->UsbFixedDiskWpBootSector = 
       mSystemConfiguration.Fdbs +1;

//  UsbLegacyModifiers->UsbFixedDiskWpBootSector = 2;
  UsbLegacyModifiers->UsbBoot = 
       mSystemConfiguration.BootUsb +1;
//UsbLegacyPlatform.165_001 Add Start
  /*++
  UsbLegacyModifiers->UsbEhciEnable = 
              mSystemConfiguration.UsbEhciEnable;
  --*/       
  UsbLegacyModifiers->UsbEhciEnable = 1;       


  UsbLegacyModifiers->UsbMassEmulation = mSystemConfiguration.UsbBIOSINT13DeviceEmulation;
  UsbLegacyModifiers->UsbMassEmulationSizeLimit = mSystemConfiguration.UsbBIOSINT13DeviceEmulationSize;
  return EFI_SUCCESS;
}

EFI_STATUS
GetPlatformMonitorKeyOptions (
  IN   EFI_USB_LEGACY_PLATFORM_PROTOCOL *This,
  OUT  KEY_ELEMENT                    **KeyList,
  OUT  UINTN                          *KeyListSize
  )
/*++

  Routine Description:
    Return all platform information that can modify USB legacy operation

  Arguments:
    This          - Protocol instance pointer.
    KeyList       - List of keys to monitor from. This includes both
                    USB & PS2 keyboard inputs.
    KeyListSize   - Size of KeyList in bytes

  Returns:
    EFI_SUCCESS   - Keys are to be monitored.
    EFI_NOT_FOUND - No keys are to be monitored.

--*/
{
  *KeyList = &mKeyList[0];
  *KeyListSize = sizeof(mKeyList);
  return EFI_SUCCESS;
}

EFI_STATUS
UsbLegacyPlatformInstall (
  )
/*++

Routine Description:
  Install Driver to produce USB Legacy platform protocol. 

Arguments:
  (Standard EFI Image entry - EFI_IMAGE_ENTRY_POINT)

Returns: 

  EFI_SUCCESS - USB Legacy Platform protocol installed

  Other       - No protocol installed, unload driver.

--*/
{
  EFI_STATUS                           Status;
  EFI_HANDLE                           Handle;
  //
  // Grab a copy of all the protocols we depend on. Any error would
  // be a dispatcher bug!.
  //


  mUsbLegacyPlatform.GetUsbPlatformOptions  = GetUsbPlatformOptions;
  mUsbLegacyPlatform.GetPlatformMonitorKeyOptions  = GetPlatformMonitorKeyOptions;


  //
  // Make a new handle and install the protocol
  //
  Handle = NULL;
  Status = gBS->InstallProtocolInterface (
                  &Handle,
                  &gEfiUsbLegacyPlatformProtocolGuid, 
                  EFI_NATIVE_INTERFACE,
                  &mUsbLegacyPlatform
                  );
  return Status;
}
