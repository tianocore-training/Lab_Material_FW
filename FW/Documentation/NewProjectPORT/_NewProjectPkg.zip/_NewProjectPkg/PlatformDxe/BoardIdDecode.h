//
// This file contains an 'Intel Peripheral Driver' and is
// licensed for Intel CPUs and chipsets under the terms of your
// license agreement with Intel or your vendor.  This file may
// be modified by the user, subject to additional terms of the
// license agreement
//
/*++

  Copyright (c) 2004 - 2014, Intel Corporation. All rights reserved.<BR>
  This software and associated documentation (if any) is furnished
  under a license and may only be used or copied in accordance
  with the terms of the license. Except as permitted by such
  license, no part of this software or documentation may be
  reproduced, stored in a retrieval system, or transmitted in any
  form or by any means without the express written consent of
  Intel Corporation.

Module Name:

  BoardIdDecode.h

Abstract:

  Header file for Platform Initialization Driver.

Revision History

++*/

//
// Board AA# and Board ID
//
#define DEFAULT_BOARD_AA                  "FFFFFF"

// Mount Washington (LVDS) LOEM
#define MW_ITX_MPCIE_LVDS_LOEM_AA         "E93081"
#define MW_ITX_MPCIE_LVDS_LOEM_ID         3

// Mount Washington (LVDS) Channel
#define MW_ITX_MPCIE_LVDS_CHANNEL_AA      "E93080"
#define MW_ITX_MPCIE_LVDS_CHANNEL_ID      3

// Mount Washington Channel
#define MW_ITX_MPCIE_CHANNEL_AA           "E93082"
#define MW_ITX_MPCIE_CHANNEL_ID           1

// Kinston (mPCIe + LVDS) LOEM
#define KT_ITX_MPCIE_LVDS_LOEM_AA         "E93085"
#define KT_ITX_MPCIE_LVDS_LOEM_ID         2

// Kinston (LVDS) Channel
#define KT_ITX_CHANNEL_AA                 "E93083"
#define KT_ITX_CHANNEL_ID                 0

// Kinston LOEM
#define KT_ITX_LOEM_AA                    "E93084"
#define KT_ITX_LOEM_ID                    0

