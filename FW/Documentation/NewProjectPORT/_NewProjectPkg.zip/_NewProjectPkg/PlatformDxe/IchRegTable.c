/*++
  This file contains an 'Intel Peripheral Driver' and is        
  licensed for Intel CPUs and chipsets under the terms of your  
  license agreement with Intel or your vendor.  This file may   
  be modified by the user, subject to additional terms of the   
  license agreement                                             
--*/
/** @file

  Copyright (c) 2004 - 2014, Intel Corporation. All rights reserved.<BR>
  This software and associated documentation (if any) is furnished
  under a license and may only be used or copied in accordance
  with the terms of the license. Except as permitted by such
  license, no part of this software or documentation may be
  reproduced, stored in a retrieval system, or transmitted in any
  form or by any means without the express written consent of
  Intel Corporation.

Module Name:


  IchRegTable.c

Abstract:

  Register initialization table for Ich.

 

--*/

#include "BuildVariables.h"
#include <Library/EfiRegTableLib.h>
#include "PlatformDxe.h"
//#include <Guid/PlatformInfo.h>
extern EFI_PLATFORM_INFO_HOB      mPlatformInfo;

#define R_EFI_PCI_SVID 0x2C

EFI_REG_TABLE mSubsystemIdRegs [] = {

  //
  // Program SVID and SID for PCI devices.
  // Combine two 16 bit PCI_WRITE into one 32 bit PCI_WRITE in order to boost performance
  //
  PCI_WRITE (
      MC_BUS, MC_DEV, MC_FUN, R_EFI_PCI_SVID, EfiPciWidthUint32,
      V_PCH_DEFAULT_SVID_SID, OPCODE_FLAG_S3SAVE
    ),

  PCI_WRITE (
      IGD_BUS, IGD_DEV, IGD_FUN_0, R_EFI_PCI_SVID, EfiPciWidthUint32,
      V_PCH_DEFAULT_SVID_SID, OPCODE_FLAG_S3SAVE
    ),

  PCI_WRITE(
      DEFAULT_PCI_BUS_NUMBER_PCH, 0, 0, R_EFI_PCI_SVID, EfiPciWidthUint32,
      V_PCH_DEFAULT_SVID_SID, OPCODE_FLAG_S3SAVE
    ),
  PCI_WRITE (
      DEFAULT_PCI_BUS_NUMBER_PCH, PCI_DEVICE_NUMBER_PCH_LPC, PCI_FUNCTION_NUMBER_PCH_LPC, R_PCH_LPC_SS, EfiPciWidthUint32,
      V_PCH_DEFAULT_SVID_SID, OPCODE_FLAG_S3SAVE
    ),
  PCI_WRITE (
      DEFAULT_PCI_BUS_NUMBER_PCH, PCI_DEVICE_NUMBER_PCH_SATA, PCI_FUNCTION_NUMBER_PCH_SATA, R_PCH_SATA_SS, EfiPciWidthUint32,
      V_PCH_DEFAULT_SVID_SID, OPCODE_FLAG_S3SAVE
    ),
  PCI_WRITE (
      DEFAULT_PCI_BUS_NUMBER_PCH, PCI_DEVICE_NUMBER_PCH_SMBUS, PCI_FUNCTION_NUMBER_PCH_SMBUS, R_PCH_SMBUS_SVID, EfiPciWidthUint32,
      V_PCH_DEFAULT_SVID_SID, OPCODE_FLAG_S3SAVE
    ),
/*  PCI_WRITE (
      DEFAULT_PCI_BUS_NUMBER_PCH, PCI_DEVICE_NUMBER_PCH_AZALIA, PCI_FUNCTION_NUMBER_PCH_AZALIA, R_PCH_HDA_SVID, EfiPciWidthUint32,
      V_PCH_DEFAULT_SVID_SID, OPCODE_FLAG_S3SAVE
    ),*/
//  PCI_WRITE (
//      DEFAULT_PCI_BUS_NUMBER_PCH, PCI_DEVICE_NUMBER_PCH_USB, PCI_FUNCTION_NUMBER_PCH_EHCI, R_PCH_EHCI_ACCESS_CNTL,
//      EfiPciWidthUint8, V_PCH_EHCI_ACCESS_CNTL_WRT_RDONLY_E, OPCODE_FLAG_S3SAVE
//    ),
  PCI_WRITE (
      DEFAULT_PCI_BUS_NUMBER_PCH, PCI_DEVICE_NUMBER_PCH_USB, PCI_FUNCTION_NUMBER_PCH_EHCI, R_PCH_EHCI_SVID, EfiPciWidthUint32,
      V_PCH_DEFAULT_SVID_SID, OPCODE_FLAG_S3SAVE
    ),
//  PCI_WRITE (
//      DEFAULT_PCI_BUS_NUMBER_PCH, PCI_DEVICE_NUMBER_PCH_USB, PCI_FUNCTION_NUMBER_PCH_EHCI, R_PCH_EHCI_ACCESS_CNTL,
//      EfiPciWidthUint8, V_PCH_EHCI_ACCESS_CNTL_WRT_RDONLY_D, OPCODE_FLAG_S3SAVE
//    ),

  PCI_WRITE (
      DEFAULT_PCI_BUS_NUMBER_PCH, PCI_DEVICE_NUMBER_PCH_PCIE_ROOT_PORTS, PCI_FUNCTION_NUMBER_PCH_PCIE_ROOT_PORT_1, R_PCH_PCIE_SVID, EfiPciWidthUint32,
      V_PCH_DEFAULT_SVID_SID, OPCODE_FLAG_S3SAVE
    ),
  PCI_WRITE (
      DEFAULT_PCI_BUS_NUMBER_PCH, PCI_DEVICE_NUMBER_PCH_PCIE_ROOT_PORTS, PCI_FUNCTION_NUMBER_PCH_PCIE_ROOT_PORT_2, R_PCH_PCIE_SVID, EfiPciWidthUint32,
      V_PCH_DEFAULT_SVID_SID, OPCODE_FLAG_S3SAVE
    ),
  PCI_WRITE (
      DEFAULT_PCI_BUS_NUMBER_PCH, PCI_DEVICE_NUMBER_PCH_PCIE_ROOT_PORTS, PCI_FUNCTION_NUMBER_PCH_PCIE_ROOT_PORT_3, R_PCH_PCIE_SVID, EfiPciWidthUint32,
      V_PCH_DEFAULT_SVID_SID, OPCODE_FLAG_S3SAVE
    ),
  PCI_WRITE (
      DEFAULT_PCI_BUS_NUMBER_PCH, PCI_DEVICE_NUMBER_PCH_PCIE_ROOT_PORTS, PCI_FUNCTION_NUMBER_PCH_PCIE_ROOT_PORT_4, R_PCH_PCIE_SVID, EfiPciWidthUint32,
      V_PCH_DEFAULT_SVID_SID, OPCODE_FLAG_S3SAVE
    ),
  TERMINATE_TABLE
};

VOID
InitializeSubsystemIds (
  )
/*++

Routine Description:
  Updates the mSubsystemIdRegs table, and processes it.  This should program
  the Subsystem Vendor and Device IDs.

Arguments:

Returns:
  VOID

--*/
{

  EFI_REG_TABLE *RegTablePtr;
//  EFI_PLATFORM_INFO_HOB     *PlatformInfo=NULL;
  UINT32 SubsystemVidDid;
  UINT32 SubsystemAudioVidDid;

  SubsystemVidDid = mPlatformInfo.SsidSvid;
  SubsystemAudioVidDid = mPlatformInfo.SsidSvid;

  RegTablePtr = mSubsystemIdRegs;


  //
  // Check Board ID GPI to see if we need to use alternate SSID
  //
//  if (mSubsystemDeviceId != V_DEFAULT_SUBSYSTEM_DEVICE_ID) {

    // While we are not at the end of the table
    while (RegTablePtr->Generic.OpCode != OP_TERMINATE_TABLE) {
      // If the data to write is the original SSID
      if (RegTablePtr->PciWrite.Data ==
            ((V_PCH_DEFAULT_SID << 16) |
             V_PCH_INTEL_VENDOR_ID)
         ) {
        // Then overwrite it to use the alternate SSID
        RegTablePtr->PciWrite.Data = SubsystemVidDid;
      }

      // Go to next table entry
      RegTablePtr++;
    }
//  }

  RegTablePtr = mSubsystemIdRegs;

  //
  // Check Board ID GPI to see if we need to use alternate SSID
  //
//  if (mSubsystemAudioDeviceId != V_DEFAULT_SUBSYSTEM_DEVICE_ID) {
    // While we are not at the end of the table
/*    while (RegTablePtr->Generic.OpCode != OP_TERMINATE_TABLE) {
      // If the data to write is the original SSI
      if (RegTablePtr->PciWrite.PciAddress ==
          EFI_PCI_ADDRESS (DEFAULT_PCI_BUS_NUMBER_ICH, PCI_DEVICE_NUMBER_PCH_AZALIA, PCI_FUNCTION_NUMBER_PCH_AZALIA, R_PCH_HDA_SVID)
         ) {
        // Then overwrite it to use the alternate SSID
        RegTablePtr->PciWrite.Data = SubsystemAudioVidDid;
      }

      // Go to next table entry
      RegTablePtr++;
    }*/
//  }

  //
  // Program the SSVID/SSDID
  //
  ProcessRegTablePci (mSubsystemIdRegs, mPciRootBridgeIo, NULL);

}
