//
// This file contains an 'Intel Peripheral Driver' and is
// licensed for Intel CPUs and chipsets under the terms of your
// license agreement with Intel or your vendor.  This file may
// be modified by the user, subject to additional terms of the
// license agreement
//
/*++

  Copyright (c) 2004 - 2014, Intel Corporation. All rights reserved.<BR>
  This software and associated documentation (if any) is furnished
  under a license and may only be used or copied in accordance
  with the terms of the license. Except as permitted by such
  license, no part of this software or documentation may be
  reproduced, stored in a retrieval system, or transmitted in any
  form or by any means without the express written consent of
  Intel Corporation.

Module Name:

  Pci1394.h

Abstract:

  Header file for Platform Initialization Driver.

Revision History

++*/

#ifndef _1394_DRIVER_H
#define _1394_DRIVER_H

#define EFI_DEFAULT_1394_GUIDHIGH                 0x0002B300    // Intel IEEE Vendor ID
#define EFI_DEFAULT_1394_GUIDLOW                  0x37134437    // a random number                      

#define V_PCI_1394_VENDOR_ID                      0x104c
#define V_PCI_1394_DEVICE_ID                      0x8024
#define V_PCI_1394_DEVICE_ID_2                    0x8023
#define V_PCI_1394_DEVICE_ID_3                    0x8235
#define R_PCI_TI_1394_BASE_ADDRESS_REG            0x10
#define R_PCI_TI_1394_SUBSYSTEM_VENDOR_DEVICE_ID  0xF8

#define PCI_DEVICE_NUMBER_TI_PCIBR    0x00
#define PCI_FUNCTION_NUMBER_TI_PCIBR  0x00

#include EFI_PROTOCOL_DEFINITION (PciIo)

VOID
Init1394(
  IN    EFI_PCI_IO_PROTOCOL           *PciIo
  );

VOID
InitTI1394(
  IN    EFI_PCI_IO_PROTOCOL           *PciIo
  );
#endif
