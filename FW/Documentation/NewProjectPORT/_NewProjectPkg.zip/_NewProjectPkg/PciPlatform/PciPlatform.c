/*++
  This file contains an 'Intel Peripheral Driver' and is        
  licensed for Intel CPUs and chipsets under the terms of your  
  license agreement with Intel or your vendor.  This file may   
  be modified by the user, subject to additional terms of the   
  license agreement                                             
--*/
/** @file

  Copyright (c) 2004 - 2014, Intel Corporation. All rights reserved.<BR>
  This software and associated documentation (if any) is furnished
  under a license and may only be used or copied in accordance
  with the terms of the license. Except as permitted by such
  license, no part of this software or documentation may be
  reproduced, stored in a retrieval system, or transmitted in any
  form or by any means without the express written consent of
  Intel Corporation.

Module Name:


    PciPlatform.c

Abstract:
--*/


#include "PciPlatform.h"
#include "PchRegs.h"
#include "PchAccess.h"
#include "VlvCommonDefinitions.h"
#include "PlatformBootMode.h"

#include <Library/BaseLib.h>
#include <Library/BaseMemoryLib.h>
#include <Protocol/CpuIo.h>
#include <Protocol/PciIo.h>
#include <Guid/SetupVariable.h>
#include <Protocol/PciRootBridgeIo.h>
#include "SetupMode.h"
#include <Library/UefiBootServicesTableLib.h>
#include <Library/UefiRuntimeServicesTableLib.h>
#include <Library/DebugLib.h>
#include <Protocol/FirmwareVolume.h>
#include <Library/HobLib.h>
#include <IndustryStandard/pci22.h>

extern  PCI_OPTION_ROM_TABLE  mPciOptionRomTable[];
extern  UINTN                 mSizeOptionRomTable;

EFI_PCI_PLATFORM_PROTOCOL mPciPlatform = {
  PhaseNotify,
  PlatformPrepController,
  GetPlatformPolicy,
  GetPciRom
};

EFI_HANDLE mPciPlatformHandle = NULL;


SYSTEM_CONFIGURATION          mSystemConfiguration;

BOOLEAN
BootLegacyNetwork (
  )
{
  EFI_CPU_IO_PROTOCOL             *CpuIo;
  UINT8                           Index;
  UINT8                           Data;
  EFI_STATUS                      Status;

  Status = gBS->LocateProtocol (&gEfiCpuIoProtocolGuid, NULL, &CpuIo);
  ASSERT_EFI_ERROR (Status);

  // BUGBUG we need to organize CMOS access
  Index = EFI_CMOS_BOOT_FLAG_ADDRESS;
  CpuIo->Io.Write (CpuIo, EfiCpuIoWidthUint8, 0x72, 1, &Index);
  CpuIo->Io.Read (CpuIo, EfiCpuIoWidthUint8, 0x73, 1, &Data);

  return ((Data & B_CMOS_FORCE_NETWORK_BOOT) == B_CMOS_FORCE_NETWORK_BOOT);
}

EFI_STATUS
GetRawImage (
  IN EFI_GUID   *NameGuid,
  IN OUT VOID   **Buffer,
  IN OUT UINTN  *Size
  )
{
  EFI_STATUS                    Status;
  EFI_HANDLE                    *HandleBuffer;
  UINTN                         HandleCount;
  UINTN                         Index;
  EFI_FIRMWARE_VOLUME_PROTOCOL  *Fv;
  UINT32                        AuthenticationStatus;

  Status = gBS->LocateHandleBuffer (ByProtocol,
                                    &gEfiFirmwareVolumeProtocolGuid,
                                    NULL,
                                    &HandleCount,
                                    &HandleBuffer
                                    );
  if (EFI_ERROR (Status) || HandleCount == 0) {
    return EFI_NOT_FOUND;
  }

  //
  // Find desired image in all Fvs
  //
  for (Index = 0; Index < HandleCount; Index++) {
    Status = gBS->HandleProtocol(HandleBuffer[Index],
                                 &gEfiFirmwareVolumeProtocolGuid,
                                 &Fv
                                 );

    if ( EFI_ERROR ( Status ) ) {
      return EFI_LOAD_ERROR;
    }

    //
    // Try a raw file
    //
    *Buffer = NULL;
    *Size = 0;
    Status = Fv->ReadSection (Fv,
                              NameGuid,
                              EFI_SECTION_RAW,
                              0,
                              Buffer,
                              Size,
                              &AuthenticationStatus
                              );

    if ( !EFI_ERROR ( Status )) {
        break;
    }
  }

  if ( Index >= HandleCount ) {
    return EFI_NOT_FOUND;
  }

  return EFI_SUCCESS;
}

EFI_STATUS
PhaseNotify (
  IN EFI_PCI_PLATFORM_PROTOCOL              *This,
  IN  EFI_HANDLE                                     HostBridge,
  IN  EFI_PCI_HOST_BRIDGE_RESOURCE_ALLOCATION_PHASE  Phase,
  IN  EFI_PCI_CHIPSET_EXECUTION_PHASE                ChipsetPhase
  ) {
  return EFI_UNSUPPORTED;
}


EFI_STATUS
PlatformPrepController (
  IN EFI_PCI_PLATFORM_PROTOCOL              *This,
  IN  EFI_HANDLE                                     HostBridge,
  IN  EFI_HANDLE                                     RootBridge,
  IN  EFI_PCI_ROOT_BRIDGE_IO_PROTOCOL_PCI_ADDRESS    PciAddress,
  IN  EFI_PCI_CONTROLLER_RESOURCE_ALLOCATION_PHASE   Phase,
  IN  EFI_PCI_CHIPSET_EXECUTION_PHASE                ChipsetPhase
  )
{
  return EFI_UNSUPPORTED;
}

EFI_STATUS
GetPlatformPolicy (
  IN CONST EFI_PCI_PLATFORM_PROTOCOL        *This,
  OUT EFI_PCI_PLATFORM_POLICY               *PciPolicy
  )
{
  *PciPolicy = EFI_RESERVE_VGA_IO_ALIAS;
  return EFI_SUCCESS;
}

EFI_STATUS
GetPciRom (
  IN CONST EFI_PCI_PLATFORM_PROTOCOL    *This,
  IN EFI_HANDLE                           PciHandle,
  OUT  VOID                               **RomImage,
  OUT  UINTN                              *RomSize
  )
/*++

Routine Description:
  GetPciRom from platform specific location for specific PCI device

Arguments:
  This -- Protocol instance
  PciHandle -- Identify the specific PCI devic
  RomImage -- Returns the ROM Image memory location
  RomSize -- Returns Rom Image size

Returns:

  EFI_SUCCESS
  EFI_NOT_FOUND
  EFI_OUT_OF_RESOURCES

--*/
{
  EFI_STATUS                    Status;
  EFI_PCI_IO_PROTOCOL           *PciIo;
  EFI_PCI_ROOT_BRIDGE_IO_PROTOCOL *PciRootBridgeIo;
  UINTN                         Segment;
  UINTN                         Bus;
  UINTN                         Device;
  UINTN                         Function;
  UINT16                        VendorId;
  UINT16                        DeviceId;
  UINT16                        DeviceClass;
  UINTN                         TableIndex;
  UINT8                         Data8;
  BOOLEAN                       MfgMode;
//  VOID                          *HobList;
  EFI_PLATFORM_SETUP_ID         *BootModeBuffer;

  EFI_PEI_HOB_POINTERS        GuidHob;

//  PCI_OPTION_ROM_TABLE          *CurrentPciOptionRomTablePtr;

//  //
//  // Check for Mfg Mode
//  //
//  Status = EfiLibGetSystemConfigurationTable (&gEfiHobListGuid, &HobList);
  MfgMode = FALSE;
//  if (!EFI_ERROR (Status)) {
//    Status = GetNextGuidHob (&HobList, &gEfiPlatformBootModeGuid, &BootModeBuffer, NULL);
//    if (!EFI_ERROR(Status)) {
//      if ( !EfiCompareMem (
//              &BootModeBuffer->SetupName,
//              gEfiManufacturingSetupName,
//              EfiStrSize (gEfiManufacturingSetupName)
//              )
//         ) {
//        MfgMode = TRUE;
//      }
//    }
//  }

// Check if system is in manufacturing mode.

  GuidHob.Raw = GetHobList ();
  if (GuidHob.Raw == NULL) {
    return EFI_NOT_FOUND;
  }

  if ((GuidHob.Raw = GetNextGuidHob (&gEfiPlatformBootModeGuid, GuidHob.Raw)) != NULL) {
      BootModeBuffer = GET_GUID_HOB_DATA (GuidHob.Guid);

      if (!CompareMem (&BootModeBuffer->SetupName, MANUFACTURE_SETUP_NAME,
          StrSize (MANUFACTURE_SETUP_NAME)))
      {
        // System is in manufacturing mode.
        MfgMode = TRUE;
      }
   }

  Status = gBS->HandleProtocol (PciHandle,
                                &gEfiPciIoProtocolGuid,
                                (VOID **)&PciIo);
  if (EFI_ERROR (Status)) {
    return EFI_NOT_FOUND;
  }

  Status = gBS->LocateProtocol (&gEfiPciRootBridgeIoProtocolGuid, NULL, &PciRootBridgeIo);

  if (EFI_ERROR (Status)) {
    return EFI_NOT_FOUND;
  }

  PciIo->Pci.Read (PciIo, EfiPciIoWidthUint16, 0x0A, 1, &DeviceClass);

  PciIo->GetLocation (PciIo, &Segment, &Bus, &Device, &Function);

  PciIo->Pci.Read (PciIo, EfiPciIoWidthUint16, 0, 1, &VendorId);

  PciIo->Pci.Read (PciIo, EfiPciIoWidthUint16, 2, 1, &DeviceId);
  //
  // WA for PCIe SATA card (SYBA SY-PEX400-40)
  //
  if ((VendorId == 0x1B21) && (DeviceId == 0x0612)) {
    Data8 = 0x07;
    PciIo->Pci.Write (PciIo, EfiPciIoWidthUint8, 4, 1, &Data8);  
  }
  if ((VendorId == IGD_VID) && ((DeviceId == IGD_DID_VLV_A0) ||
      (DeviceId == IGD_DID_II) || (DeviceId == IGD_DID_0BE4) ||
      (DeviceId == IGD_DID_QS)))
  {
     if ((mSystemConfiguration.GOPEnable == 1) && (mSystemConfiguration.OsSelection != 2))
     {
       return EFI_NOT_FOUND;
     }
  }
    //
    // Do not run RAID or AHCI Option ROM if IDE
    //
    if ( (DeviceClass == ((PCI_CLASS_MASS_STORAGE << 8 ) | PCI_CLASS_MASS_STORAGE_IDE))
      ) {
      return EFI_NOT_FOUND;
    }

    //
    // Run PXE ROM only if Boot network is enabled and not in MFG mode
    //
    if (DeviceClass == ((PCI_CLASS_NETWORK << 8 ) | PCI_CLASS_NETWORK_ETHERNET)) {
    if (((mSystemConfiguration.BootNetwork == 0) && (MfgMode == FALSE )) || (mSystemConfiguration.FastBoot == 1)) {
          return EFI_NOT_FOUND;
    }
    }

    //
    // Loop through table of Onboard option rom descriptions
    //
    for (TableIndex = 0; mPciOptionRomTable[TableIndex].VendorId != 0xffff; TableIndex++) {

      //
      // See if the PCI device specified by PciHandle matches at device in mPciOptionRomTable
      //
      if (VendorId != mPciOptionRomTable[TableIndex].VendorId ||
          DeviceId != mPciOptionRomTable[TableIndex].DeviceId ||
          ((DeviceClass == ((PCI_CLASS_NETWORK << 8 ) | PCI_CLASS_NETWORK_ETHERNET)) &&
           (mPciOptionRomTable[TableIndex].Flag != mSystemConfiguration.BootNetwork))
  //BUGBUG: Why we need to check for Segment, Bus, Device, Function number since these are dynamic? Take them out now. --MengWei
  //        Segment != mPciOptionRomTable[TableIndex].Segment   ||
  //        Bus != mPciOptionRomTable[TableIndex].Bus ||
  //        Device != mPciOptionRomTable[TableIndex].Device ||
  //        Function != mPciOptionRomTable[TableIndex].Function
        ) {
        continue;
      }

      Status = GetRawImage( &mPciOptionRomTable[TableIndex].FileName,
                            RomImage,
                            RomSize
                        );

      if ((VendorId == IGD_VID) && (DeviceId == IGD_DID_VLV_A0)){
        *(UINT16 *)(((UINTN) *RomImage) + OPROM_DID_OFFSET) = IGD_DID_VLV_A0;
      }

      if ((VendorId == IGD_VID) && (DeviceId == IGD_DID_II)){
        *(UINT16 *)(((UINTN) *RomImage) + OPROM_DID_OFFSET) = IGD_DID_II;
      }

      if ((VendorId == IGD_VID) && (DeviceId == IGD_DID_0BE4)){
        *(UINT16 *)(((UINTN) *RomImage) + OPROM_DID_OFFSET) = IGD_DID_0BE4;
      }

      if ((VendorId == IGD_VID) && (DeviceId == IGD_DID_QS)){
        *(UINT16 *)(((UINTN) *RomImage) + OPROM_DID_OFFSET) = IGD_DID_QS;
      }


        if (EFI_ERROR (Status)) {
          continue;
        }
        return EFI_SUCCESS;
      }

  return EFI_NOT_FOUND;
}


EFI_STATUS
PciPlatformDriverEntry (
  IN EFI_HANDLE        ImageHandle,
  IN EFI_SYSTEM_TABLE  *SystemTable
  )
/*++

Routine Description:

Arguments:
  (Standard EFI Image entry - EFI_IMAGE_ENTRY_POINT)

Returns:
  EFI_STATUS

--*/
{
  EFI_STATUS  Status;
  UINTN       VarSize;

  VarSize = sizeof(SYSTEM_CONFIGURATION);
  Status = gRT->GetVariable(L"Setup",
                            &gEfiNormalSetupGuid,
                            NULL,
                            &VarSize,
                            &mSystemConfiguration);
  ASSERT_EFI_ERROR(Status);
  //
  // Install on a new handle
  //
  Status = gBS->InstallProtocolInterface (
                  &mPciPlatformHandle,
                  &gEfiPciPlatformProtocolGuid,
                  EFI_NATIVE_INTERFACE,
                  &mPciPlatform
                  );

  return Status;
}


