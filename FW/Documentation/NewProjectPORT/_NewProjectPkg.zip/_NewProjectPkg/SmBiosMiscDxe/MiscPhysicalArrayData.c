/*++
  This file contains an 'Intel Peripheral Driver' and is        
  licensed for Intel CPUs and chipsets under the terms of your  
  license agreement with Intel or your vendor.  This file may   
  be modified by the user, subject to additional terms of the   
  license agreement                                             
--*/
/*++

Copyright (c) 2006 - 2012, Intel Corporation. All rights reserved.<BR>
This software and associated documentation (if any) is furnished
under a license and may only be used or copied in accordance
with the terms of the license. Except as permitted by such
license, no part of this software or documentation may be
reproduced, stored in a retrieval system, or transmitted in any
form or by any means without the express written consent of
Intel Corporation.


Module Name:

  MiscPhysicalArrayData.c
  
Abstract: 

  BIOS Physical Array static data.
  SMBIOS type 16.

--*/


#include "CommonHeader.h"

#include "MiscSubclassDriver.h"



//
// Static (possibly build generated) Physical Memory Array Dat.
//
MISC_SMBIOS_TABLE_DATA(EFI_MEMORY_ARRAY_LOCATION_DATA, MiscPhysicalMemoryArray) = 
{ 
	EfiMemoryArrayLocationSystemBoard,						// Memory location 
	EfiMemoryArrayUseSystemMemory, 						    // Memory array use
	EfiMemoryErrorCorrectionNone, 						    // Memory error correction
	0,                                                      // Maximum Memory Capacity  						
	0x01						                            // Number of Devices       			
};
