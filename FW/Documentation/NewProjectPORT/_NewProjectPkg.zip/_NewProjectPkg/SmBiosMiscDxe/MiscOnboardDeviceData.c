/*++
  This file contains an 'Intel Peripheral Driver' and is        
  licensed for Intel CPUs and chipsets under the terms of your  
  license agreement with Intel or your vendor.  This file may   
  be modified by the user, subject to additional terms of the   
  license agreement                                             
--*/
/** @file

Copyright (c) 2004 - 2009, Intel Corporation. All rights reserved.<BR>
This software and associated documentation (if any) is furnished
under a license and may only be used or copied in accordance
with the terms of the license. Except as permitted by such
license, no part of this software or documentation may be
reproduced, stored in a retrieval system, or transmitted in any
form or by any means without the express written consent of
Intel Corporation.


Module Name:

  MiscOnboardDeviceData.c

Abstract:

  Static data of Onboard device information .
  The onboard device information is Misc. subclass type 8 and SMBIOS type 10.


**/


#include "CommonHeader.h"

#include "MiscSubclassDriver.h"

//
// Static (possibly build generated) Bios Vendor data.
//
MISC_SMBIOS_TABLE_DATA(EFI_MISC_ONBOARD_DEVICE_DATA, MiscOnboardDeviceVideo) = {
  STRING_TOKEN(STR_MISC_ONBOARD_DEVICE_VIDEO),  // OnBoardDeviceDescription
  {                             // OnBoardDeviceStatus
    EfiOnBoardDeviceTypeVideo,  // DeviceType
    1,                          // DeviceEnabled
    0                           // Reserved
  },
  0                             // OnBoardDevicePath
};
MISC_SMBIOS_TABLE_DATA(EFI_MISC_ONBOARD_DEVICE_DATA, MiscOnboardDeviceAudio) = {
  STRING_TOKEN(STR_MISC_ONBOARD_DEVICE_AUDIO),    // OnBoardDeviceDescription
  {                                 // OnBoardDeviceStatus
    EfiOnBoardDeviceTypeSound,      // DeviceType
    1,                              // DeviceEnabled
    0                               // Reserved
  },
  0                                 // OnBoardDevicePath
};

/*
//
// Static (possibly build generated) Bios Vendor data.
//
MISC_SMBIOS_TABLE_DATA(EFI_MISC_ONBOARD_DEVICES_EXTENDED_INFORMATION_DATA, MiscOnboardDeviceVideoExt) = {
  STRING_TOKEN(STR_MISC_ONBOARD_DEVICE_VIDEO),    // ReferenceDesignation
  {                                 // OnBoardDeviceStatus
    EfiOnBoardDeviceTypeVideo,      // TypeOfDevice
    1                               // DeviceStatus
  },
  0,                                // DeviceTypeInstance
  0,                                // SegmentGroupNum
  IGD_BUS,                          // BusNum
  {                                 // DevFuncNum
    IGD_FUN_0,                      // FunctionNum
    IGD_DEV                         // DeviceNum
  } 
};

MISC_SMBIOS_TABLE_DATA(EFI_MISC_ONBOARD_DEVICES_EXTENDED_INFORMATION_DATA, MiscOnboardDeviceNetworkExt) = {
  STRING_TOKEN(STR_MISC_ONBOARD_DEVICE_NETWORK),  // ReferenceDesignation
  {                                 // DeviceType
    EfiOnBoardDeviceTypeEthernet,   // TypeOfDevice
    1                               // DeviceStatus
  },
  0,                                // DeviceTypeInstance
  0,                                // SegmentGroupNum
  1,                                // BusNum
  {                                 // DevFuncNum
    0,                              // FunctionNum
    0                               // DeviceNum
  } 
};

MISC_SMBIOS_TABLE_DATA(EFI_MISC_ONBOARD_DEVICES_EXTENDED_INFORMATION_DATA, MiscOnboardDeviceAudioExt) = {
  STRING_TOKEN(STR_MISC_ONBOARD_DEVICE_AUDIO),    // ReferenceDesignation
  {                                 // DeviceType
    EfiOnBoardDeviceTypeSound,      // TypeOfDevice
    1                               // DeviceStatus
  },
  0,                                // DeviceTypeInstance
  0,                                // SegmentGroupNum
  DEFAULT_PCI_BUS_NUMBER_ICH,       // BusNum
  {                                 // DevFuncNum
    PCI_FUNCTION_NUMBER_ICH_AZALIA, // FunctionNum
    PCI_DEVICE_NUMBER_ICH_AZALIA    // DeviceNum
  } 
};
*/
