//
// This file contains an 'Intel Peripheral Driver' and is      
// licensed for Intel CPUs and chipsets under the terms of your
// license agreement with Intel or your vendor.  This file may 
// be modified by the user, subject to additional terms of the 
// license agreement                                           
//
/** @file

Copyright (c) 2004 - 2009, Intel Corporation. All rights reserved.<BR>
This software and associated documentation (if any) is furnished
under a license and may only be used or copied in accordance
with the terms of the license. Except as permitted by such
license, no part of this software or documentation may be
reproduced, stored in a retrieval system, or transmitted in any
form or by any means without the express written consent of
Intel Corporation.


Module Name:

  MiscSubclassDriver.h

Abstract:

  Header file for MiscSubclass Driver.


**/

#ifndef _MISC_SUBCLASS_DRIVER_H
#define _MISC_SUBCLASS_DRIVER_H


#include "CommonHeader.h"

extern UINT8  MiscSubclassStrings[];


#define T14_FVI_STRING          "Driver/firmware version"
#define EFI_SMBIOS_TYPE_FIRMWARE_VERSION_INFO 0x90
#define EFI_SMBIOS_TYPE_MISC_VERSION_INFO 0x94
#define TOUCH_ACPI_ID    "I2C05\\SFFFF\\400K"
#define TOUCH_RESET_GPIO_MMIO  0xFED0C508
#define EFI_SMBIOS_TYPE_SEC_INFO 0x83
#define IntelIdentifer 0x6F725076
//
// Data table entry update function.
//
typedef EFI_STATUS (EFIAPI EFI_MISC_SMBIOS_DATA_FUNCTION) (
  IN  VOID                 *RecordData,
  IN  EFI_SMBIOS_PROTOCOL  *Smbios
  );

//
// Data table entry definition.
//
typedef struct {
  //
  // intermediat input data for SMBIOS record
  //
  VOID                              *RecordData;
  EFI_MISC_SMBIOS_DATA_FUNCTION     *Function;
} EFI_MISC_SMBIOS_DATA_TABLE;

//
// Data Table extern definitions.
//
#define MISC_SMBIOS_TABLE_EXTERNS(NAME1, NAME2, NAME3) \
extern NAME1 NAME2 ## Data; \
extern EFI_MISC_SMBIOS_DATA_FUNCTION NAME3 ## Function


//
// Data Table entries
//
#define MISC_SMBIOS_TABLE_ENTRY_DATA_AND_FUNCTION(NAME1, NAME2) \
{ \
  & NAME1 ## Data, \
  & NAME2 ## Function \
}

//
// Global definition macros.
//
#define MISC_SMBIOS_TABLE_DATA(NAME1, NAME2) \
  NAME1 NAME2 ## Data

#define MISC_SMBIOS_TABLE_FUNCTION(NAME2) \
  EFI_STATUS EFIAPI NAME2 ## Function( \
  IN  VOID                  *RecordData, \
  IN  EFI_SMBIOS_PROTOCOL   *Smbios \
  )

#pragma pack(1)
//
// This is definition for SMBIOS Oem data type 0x83
//
typedef struct {
  UINT32                            SecEnable                :1;
  UINT32                            Reserved0                :12;
  UINT32                            ATSupport                :1;
  UINT32                            Reserved1                :18;
  UINT32                            SecFwMinorVersion        :16;       
  UINT32                            SecFwMajorVersion        :16;            
  UINT32                            SecFwBuildVersion        :16;            
  UINT32                            SecFwHotfixVersion       :16;             
} SEC_CAPABILITYS; 

typedef struct {
  UINT32                            Reserved0                :5;
  UINT32                            ATConfigured             :1;
  UINT32                            Reserved1                :26;                
} SEC_CFG_STATE; 

typedef struct {
  UINT32                            Reserved0                :4;
  UINT32                            SecBiosSetup             :1;
  UINT32                            Reserved1                :1; 
  UINT32                            ATPBA                    :1;
  UINT32                            ATWWAN                   :1;
  UINT32                            Reserved2                :24;                
} BIOS_SEC_CAPABILITYS; 

typedef struct {
  UINT32                            Identifer;                
} STRUCTURE_IDENTIFIER; 

typedef struct {
  UINT32                            SecFwMinorVersion        :16;       
  UINT32                            SecFwMajorVersion        :16;         
  UINT32                            SecFwBuildVersion        :16;                
  UINT32                            SecFwHotfixVersion       :16; 
} EFI_MISC_OEM_TYPE_0x83; 

//
// This is definition for SMBIOS Oem data type 0x83
//
typedef struct {
  SMBIOS_STRUCTURE          Hdr;
  UINT32                    Reserved0;
  UINT32                    Reserved1;
  UINT32                    Reserved2;
  UINT32                    Reserved3;
  UINT32                    Reserved4;
  SEC_CAPABILITYS           SeCCapabilities;
  SEC_CFG_STATE             SeCCfgState;
  UINT32                    Reserved5;
  UINT32                    Reserved6;
  UINT32                    Reserved7;
  BIOS_SEC_CAPABILITYS      BiosSeCCapabilities;
  STRUCTURE_IDENTIFIER      StructureIdentifer;
  UINT32                    Reserverd8;
} SMBIOS_TABLE_TYPE83; 


//
// This is definition for SMBIOS Oem data type 0x90
//
typedef struct {
  STRING_REF                         SECVersion;
  STRING_REF                         uCodeVersion;
  STRING_REF                         GOPVersion;
  STRING_REF                         CpuStepping;
} EFI_MISC_OEM_TYPE_0x90; 

//
// This is definition for SMBIOS Oem data type 0x90
//
typedef struct {
  SMBIOS_STRUCTURE          Hdr;
  SMBIOS_TABLE_STRING       SECVersion;
  SMBIOS_TABLE_STRING       uCodeVersion;
  SMBIOS_TABLE_STRING       GOPVersion;
  SMBIOS_TABLE_STRING       CpuStepping;
} SMBIOS_TABLE_TYPE90; 

typedef struct {
  STRING_REF                GopVersion;
  STRING_REF                UCodeVersion;
  STRING_REF                MRCVersion;
  STRING_REF                SECVersion;
  STRING_REF                ULPMCVersion;
  STRING_REF                PMCVersion;
  STRING_REF                PUnitVersion;
  STRING_REF                SoCVersion;
  STRING_REF                BoardVersion;
  STRING_REF                FabVersion;
  STRING_REF                CPUFlavor;
  STRING_REF                BiosVersion;
  STRING_REF                PmicVersion;
  STRING_REF                TouchVersion; 
  STRING_REF                SecureBoot;
  STRING_REF                BootMode;
  STRING_REF                SpeedStepMode;
  STRING_REF                CPUTurboMode;
  STRING_REF                MaxCState;
  STRING_REF                GfxTurbo;         
  STRING_REF                S0ix;
  STRING_REF                RC6;
}EFI_MISC_OEM_TYPE_0x94;

typedef struct {
  SMBIOS_STRUCTURE          Hdr;
  SMBIOS_TABLE_STRING       GopVersion;
  SMBIOS_TABLE_STRING       uCodeVersion;
  SMBIOS_TABLE_STRING       MRCVersion;
  SMBIOS_TABLE_STRING       SECVersion;
  SMBIOS_TABLE_STRING       ULPMCVersion;
  SMBIOS_TABLE_STRING       PMCVersion;
  SMBIOS_TABLE_STRING       PUnitVersion;
  SMBIOS_TABLE_STRING       SoCVersion;
  SMBIOS_TABLE_STRING       BoardVersion;
  SMBIOS_TABLE_STRING       FabVersion;
  SMBIOS_TABLE_STRING       CPUFlavor;
  SMBIOS_TABLE_STRING       BiosVersion;
  SMBIOS_TABLE_STRING       PmicVersion;
  SMBIOS_TABLE_STRING       TouchVersion;
  SMBIOS_TABLE_STRING       SecureBoot;
  SMBIOS_TABLE_STRING       BootMode;
  SMBIOS_TABLE_STRING       SpeedStepMode;
  SMBIOS_TABLE_STRING       CPUTurboMode;
  SMBIOS_TABLE_STRING       MaxCState;
  SMBIOS_TABLE_STRING       GfxTurbo; 
  SMBIOS_TABLE_STRING       S0ix;
  SMBIOS_TABLE_STRING       RC6;
}SMBIOS_TABLE_TYPE94;

#pragma pack()
// Data Table Array
//
extern EFI_MISC_SMBIOS_DATA_TABLE mMiscSubclassDataTable[];

//
// Data Table Array Entries
//
extern UINTN                        mMiscSubclassDataTableEntries;
extern EFI_HII_HANDLE               mHiiHandle;

//
// Prototypes
//
EFI_STATUS
MiscSubclassDriverEntryPoint (
  IN EFI_HANDLE         ImageHandle,
  IN EFI_SYSTEM_TABLE   *SystemTable
  );

EFI_STRING
EFIAPI
SmbiosMiscGetString (
  IN EFI_STRING_ID   StringId
  );

#endif
