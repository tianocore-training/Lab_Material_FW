/*++
  This file contains an 'Intel Peripheral Driver' and is        
  licensed for Intel CPUs and chipsets under the terms of your  
  license agreement with Intel or your vendor.  This file may   
  be modified by the user, subject to additional terms of the   
  license agreement                                             
--*/
/** @file

  Copyright (c) 2004 - 2014, Intel Corporation. All rights reserved.<BR>
  This software and associated documentation (if any) is furnished
  under a license and may only be used or copied in accordance
  with the terms of the license. Except as permitted by such
  license, no part of this software or documentation may be
  reproduced, stored in a retrieval system, or transmitted in any
  form or by any means without the express written consent of
  Intel Corporation.


Module Name:


  PpmPolicy.c

Abstract:

  This file is a wrapper for Intel PPM Platform Policy driver.
  Get Setup Value to initilize Intel PPM DXE Platform Policy.

--*/
#include "PpmPolicy.h"
#include <Protocol/MpService.h>
#include <Library/CpuConfigLib.h>
#include "Guid/SetupVariable.h"
#include <Library/BaseLib.h>
#include <Library/DebugLib.h>
#include "CpuRegs.h"
//for PchStepping
#include <PchRegs.h>
#include <Library/PchPlatformLib.h>

#define EFI_CPUID_FAMILY                      0x0F00
#define EFI_CPUID_MODEL                       0x00F0
#define EFI_CPUID_STEPPING                    0x000F



EFI_STATUS PpmPolicyEntry(
  IN EFI_HANDLE ImageHandle,
  IN EFI_SYSTEM_TABLE *SystemTable
)
{
  EFI_MP_SERVICES_PROTOCOL *MpService;
  EFI_CPUID_REGISTER        Cpuid01 = { 0, 0, 0, 0};
  EFI_HANDLE                Handle;
  EFI_STATUS                Status;
  EFI_GUID                  SetupGuid = SYSTEM_CONFIGURATION_GUID;
  UINTN                     VariableSize = sizeof(SYSTEM_CONFIGURATION);
  SYSTEM_CONFIGURATION      SetupVariables;
  UINTN                     CpuCount;
  UINT64                    MaxRatio;
  UINT8                     CPUMobileFeature;

  PCH_STEPPING              Stepping;


  gBS = SystemTable->BootServices;
  pBS = SystemTable->BootServices;
  pRS = SystemTable->RuntimeServices;

  //
  // Set PPM policy structure to known value
  //
  gBS->SetMem (&mDxePlatformPpmPolicy, sizeof(PPM_PLATFORM_POLICY_PROTOCOL), 0);

  //
  // Find the MpService Protocol
  //
  Status = pBS->LocateProtocol (&gEfiMpServiceProtocolGuid,
                                NULL,
                                &MpService
                               );
  ASSERT_EFI_ERROR (Status);

  //
  // Get processor count from MP service.
  //
  Status = MpService->GetNumberOfProcessors (MpService, &CpuCount, NULL);
  ASSERT_EFI_ERROR (Status);

  //
  // Store the CPUID for use by SETUP items.
  //
  AsmCpuid (EFI_CPUID_VERSION_INFO, &Cpuid01.RegEax, &Cpuid01.RegEbx, &Cpuid01.RegEcx, &Cpuid01.RegEdx);
  MaxRatio = ((RShiftU64 (AsmReadMsr64(EFI_MSR_IA32_PLATFORM_ID), 8)) & 0x1F);

  Status = pRS->GetVariable(
                         L"Setup",
                         &SetupGuid,
                         NULL,
                         &VariableSize,
                         &SetupVariables
                         );

  mDxePlatformPpmPolicy.Revision                       = PPM_PLATFORM_POLICY_PROTOCOL_REVISION_4;

  //Read CPU Mobile feature from PLATFORM_ID_MSR MSR(0x17) NOTFB_I_AM_NOT_MOBILE_FUSE_CLIAMC00H Bit 28
  //Bit Description: { Disables Mobile features 0 = I am NOT a mobile part 1 = I am a mobile part (default)"}
  CPUMobileFeature = ((RShiftU64 (AsmReadMsr64(EFI_MSR_IA32_PLATFORM_ID), 28)) & 0x1);

  if (!EFI_ERROR(Status)) {
    if (CPUMobileFeature == 1){//CPU mobile feature
      mDxePlatformPpmPolicy.FunctionEnables.EnableGv       = SetupVariables.EnableGv;
      mDxePlatformPpmPolicy.FunctionEnables.EnableCx       = SetupVariables.EnableCx;
      mDxePlatformPpmPolicy.FunctionEnables.EnableCxe      = SetupVariables.EnableCxe;
      mDxePlatformPpmPolicy.FunctionEnables.EnableTm       = SetupVariables.EnableTm;
      mDxePlatformPpmPolicy.FunctionEnables.EnableC4  = SetupVariables.EnableC4;
      mDxePlatformPpmPolicy.FunctionEnables.EnableC6       = SetupVariables.EnableC6;
      if(SetupVariables.MaxCState == 3){ //MaxC7
        mDxePlatformPpmPolicy.FunctionEnables.EnableC7       = ICH_DEVICE_ENABLE;
        mDxePlatformPpmPolicy.FunctionEnables.EnableC6       = ICH_DEVICE_ENABLE;
        mDxePlatformPpmPolicy.FunctionEnables.EnableC4       = ICH_DEVICE_ENABLE;
      } else if(SetupVariables.MaxCState == 2){//MaxC6
        mDxePlatformPpmPolicy.FunctionEnables.EnableC7       = ICH_DEVICE_DISABLE;
        mDxePlatformPpmPolicy.FunctionEnables.EnableC6       = ICH_DEVICE_ENABLE;
        mDxePlatformPpmPolicy.FunctionEnables.EnableC4       = ICH_DEVICE_ENABLE;
      }else if(SetupVariables.MaxCState == 1){//MaxC4
        mDxePlatformPpmPolicy.FunctionEnables.EnableC7       = ICH_DEVICE_DISABLE;
        mDxePlatformPpmPolicy.FunctionEnables.EnableC6       = ICH_DEVICE_DISABLE;
        mDxePlatformPpmPolicy.FunctionEnables.EnableC4       = ICH_DEVICE_ENABLE;
      }else{//MaxC1
        mDxePlatformPpmPolicy.FunctionEnables.EnableC7       = ICH_DEVICE_DISABLE;
        mDxePlatformPpmPolicy.FunctionEnables.EnableC6       = ICH_DEVICE_DISABLE;
        mDxePlatformPpmPolicy.FunctionEnables.EnableC4       = ICH_DEVICE_DISABLE;
      }
      mDxePlatformPpmPolicy.FunctionEnables.S0ixSupport      = ICH_DEVICE_DISABLE;
      DEBUG ((EFI_D_ERROR, "PpmPolicy.S0ixSupport=%d\n" ,mDxePlatformPpmPolicy.FunctionEnables.S0ixSupport ));
    }else{//CPU desktop feature
       mDxePlatformPpmPolicy.FunctionEnables.EnableGv       = ICH_DEVICE_DISABLE;
       mDxePlatformPpmPolicy.FunctionEnables.EnableCx       = ICH_DEVICE_DISABLE;
       mDxePlatformPpmPolicy.FunctionEnables.EnableCxe      = ICH_DEVICE_DISABLE;
       //mDxePlatformPpmPolicy.FunctionEnables.EnableHardC4E  = ICH_DEVICE_DISABLE;
       mDxePlatformPpmPolicy.FunctionEnables.EnableTm       = ICH_DEVICE_DISABLE;
       mDxePlatformPpmPolicy.FunctionEnables.EnableC4       = ICH_DEVICE_DISABLE;
       mDxePlatformPpmPolicy.FunctionEnables.EnableC6       = ICH_DEVICE_DISABLE;
       mDxePlatformPpmPolicy.FunctionEnables.EnableC7       = ICH_DEVICE_DISABLE;
    }

    mDxePlatformPpmPolicy.FunctionEnables.EnableEmttm    = ICH_DEVICE_DISABLE;
    mDxePlatformPpmPolicy.FunctionEnables.EnableProcHot  = SetupVariables.EnableProcHot;
    mDxePlatformPpmPolicy.FunctionEnables.TStatesEnable  = ICH_DEVICE_ENABLE;
    mDxePlatformPpmPolicy.FunctionEnables.EnableDynamicFsb=ICH_DEVICE_DISABLE;
    if (SetupVariables.TurboModeEnable == 2) {
      Stepping = PchStepping();
      if (Stepping < PchB3) {
        // If SoC is B0~B2 Stepping, disable the Turbo
        mDxePlatformPpmPolicy.FunctionEnables.EnableTurboMode= ICH_DEVICE_DISABLE;
      } else {
        mDxePlatformPpmPolicy.FunctionEnables.EnableTurboMode= ICH_DEVICE_ENABLE;
      }
    } else {
      mDxePlatformPpmPolicy.FunctionEnables.EnableTurboMode= SetupVariables.TurboModeEnable;
    } 
    mDxePlatformPpmPolicy.FunctionEnables.EnableTm      = SetupVariables.EnableTm;
    mDxePlatformPpmPolicy.FunctionEnables.HTD           = SetupVariables.ProcessorHtMode;
    if (SetupVariables.ActiveProcessorCores == 1) // single core
    {
//      mDxePlatformPpmPolicy.FunctionEnables.EnableCMP      = ICH_DEVICE_ENABLE;
      mDxePlatformPpmPolicy.FunctionEnables.EnableCMP      = ICH_DEVICE_DISABLE;
    }
    else
    {
//      mDxePlatformPpmPolicy.FunctionEnables.EnableCMP      = ICH_DEVICE_DISABLE;
      mDxePlatformPpmPolicy.FunctionEnables.EnableCMP      = ICH_DEVICE_ENABLE;
    }

  } else {
    mDxePlatformPpmPolicy.FunctionEnables.EnableGv       = ICH_DEVICE_ENABLE;
    mDxePlatformPpmPolicy.FunctionEnables.EnableCx       = ICH_DEVICE_ENABLE;
    mDxePlatformPpmPolicy.FunctionEnables.EnableCxe      = ICH_DEVICE_ENABLE;
    mDxePlatformPpmPolicy.FunctionEnables.EnableTm      = ICH_DEVICE_ENABLE;
    mDxePlatformPpmPolicy.FunctionEnables.EnableEmttm    = ICH_DEVICE_ENABLE;
    mDxePlatformPpmPolicy.FunctionEnables.EnableProcHot  = ICH_DEVICE_ENABLE;
    mDxePlatformPpmPolicy.FunctionEnables.HTD           = ICH_DEVICE_ENABLE;
    mDxePlatformPpmPolicy.FunctionEnables.EnableCMP       = ICH_DEVICE_DISABLE;
    mDxePlatformPpmPolicy.FunctionEnables.TStatesEnable  = ICH_DEVICE_ENABLE;
    mDxePlatformPpmPolicy.FunctionEnables.EnableDynamicFsb=ICH_DEVICE_ENABLE;
    mDxePlatformPpmPolicy.FunctionEnables.EnableTurboMode= ICH_DEVICE_ENABLE;
    mDxePlatformPpmPolicy.FunctionEnables.EnableC4       = ICH_DEVICE_ENABLE;
    mDxePlatformPpmPolicy.FunctionEnables.EnableC6       = ICH_DEVICE_ENABLE;
  }


  //
  // Set boot performance mode based on setup option. If the ratio is greater than
  // an arbitrary max, boot in LFM so user can set up custom VID table.
  //
  if (SetupVariables.BootPState == 0) {
    mDxePlatformPpmPolicy.BootInLfm = 0;
    mDxePlatformPpmPolicy.FlexRatioVid = 0;
  } else if (SetupVariables.BootPState == 1){
    mDxePlatformPpmPolicy.BootInLfm = 1;
    mDxePlatformPpmPolicy.FlexRatioVid = 0;
  }
  mDxePlatformPpmPolicy.OsPolicy         =  SetupVariables.OsSelection;

  mDxePlatformPpmPolicy.PowerStateSwitchSmiNumber                     = POWER_STATE_SWITCH_SMI;
  mDxePlatformPpmPolicy.EnableCStateIoRedirectionSmiNumber            = ENABLE_C_STATE_IO_REDIRECTION_SMI;
  mDxePlatformPpmPolicy.DisableCStateIoRedirectionSmiNumber           = DISABLE_C_STATE_IO_REDIRECTION_SMI;
  mDxePlatformPpmPolicy.EnablePStateHardwareCoordinationSmiNumber     = ENABLE_P_STATE_HARDWARE_COORDINATION_SMI;
  mDxePlatformPpmPolicy.DisablePStateHardwareCoordinationSmiNumber    = DISABLE_P_STATE_HARDWARE_COORDINATION_SMI;
  mDxePlatformPpmPolicy.S3RestoreMsrSwSmiNumber                       = S3_RESTORE_MSR_SW_SMI;
  mDxePlatformPpmPolicy.EnableEnableC6ResidencySmiNumber              = ENABLE_C6_RESIDENCY_SMI;

  Handle = NULL;
  Status = gBS->InstallMultipleProtocolInterfaces (
                                                  &Handle,
                                                  &gPpmPlatformPolicyProtocolGuid,
                                                  &mDxePlatformPpmPolicy,
                                                  NULL
                                                  );

  ASSERT_EFI_ERROR (Status);

  return EFI_SUCCESS;
}
