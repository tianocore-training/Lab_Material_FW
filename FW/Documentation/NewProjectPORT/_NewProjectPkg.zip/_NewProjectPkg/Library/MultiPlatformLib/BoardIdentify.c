/*++
  This file contains an 'Intel Peripheral Driver' and is
  licensed for Intel CPUs and chipsets under the terms of your
  license agreement with Intel or your vendor.  This file may
  be modified by the user, subject to additional terms of the
  license agreement
--*/
/** @file
  Boards identification for multiplatform.

  Copyright (c) 2013, Intel Corporation. All rights reserved.<BR>
  This software and associated documentation (if any) is furnished
  under a license and may only be used or copied in accordance
  with the terms of the license. Except as permitted by such
  license, no part of this software or documentation may be
  reproduced, stored in a retrieval system, or transmitted in any
  form or by any means without the express written consent of
  Intel Corporation.

**/
#include <MultiPlatformLib.h>
//#include <PeiKscLib.h>

EFI_STATUS
GetBoardFabIds (
  IN CONST EFI_PEI_SERVICES     **PeiServices,
  OUT UINT16                    *BoardFabIds
  );

EFI_STATUS
EnableNGFF (
  IN CONST EFI_PEI_SERVICES     **PeiServices
  );

EFI_STATUS
EnableNGFF (
  IN CONST EFI_PEI_SERVICES     **PeiServices
  )
/*++
	BIOS send command and data to EC, let EC know onboard NGFF or onboard mPCIe Slot3 exist or not
	then EC will power on them or not.
	Send 66h = 0x27 Command
	Send 62h = 0x03 Data
	            Bit 0 = 1 ; card present for onboard NGFF
	            Bit 1 = 1 ; card present for onboard mPCIe Slot3
--*/
{
/* BUGBUG ZWEI4   EFI_STATUS			          Status = EFI_SUCCESS;
  EFI_PEI_READ_ONLY_VARIABLE2_PPI *PeiReadOnlyVarPpi = NULL;
  UINTN                           VarSize;
  SYSTEM_CONFIGURATION            SystemConfiguration;
  UINT8                           WlanCardPresence = 0;

  DEBUG ((EFI_D_INFO,  "Enable WLAN Cards as per Setup information\n"));
  //
  // Locate PEI Read Only Variable PPI.
  //

  Status = (**PeiServices).LocatePpi (
                             PeiServices,
                             &gEfiPeiReadOnlyVariable2PpiGuid,
                             0,
                             NULL,
                             &PeiReadOnlyVarPpi
                             );
  if (Status == EFI_SUCCESS) {
    VarSize = sizeof (SYSTEM_CONFIGURATION);
    Status = PeiReadOnlyVarPpi->GetVariable ( 
                                  PeiReadOnlyVarPpi, 
                                  PLATFORM_SETUP_VARIABLE_NAME, 
                                  &gEfiSetupVariableGuid,
                                  NULL,
                                  &VarSize,
                                  &SystemConfiguration
                                  );
    if (Status == EFI_SUCCESS) {
      if (SystemConfiguration.WlanNGFFCardPresence == 1) {
        WlanCardPresence |= 0x01;
      }
      if (SystemConfiguration.WlanUHPAMCardPresence == 1) {
        WlanCardPresence |= 0x02;
      }
    }
  }
  
  Status = SendKscCommand (KSC_C_NIC_PRESENCE);
  if(!EFI_ERROR(Status)) {
	  Status = SendKscData (WlanCardPresence); 
	  if(!EFI_ERROR(Status)) {
			Status = EFI_SUCCESS;
			DEBUG ((EFI_D_INFO,  "Update NIC WLAN Presence information to EC, value = %x\n", WlanCardPresence));
	  }
  }	
  return Status;*/
  return EFI_SUCCESS;
}

EFI_STATUS
GetBoardFabIds (
  IN CONST EFI_PEI_SERVICES     **PeiServices,
  OUT UINT16                    *BoardFabIds
  )
/*++

Routine Description:

  This function Issues EC command (0x0D) to EC to get board ID and FAB ID details and returns to the 
  calling function. Procedure to get Board ID & FAB ID is common to both Mobile and Desktop platforms.
  Bit position details
  when EC Command 0x0D is issue to EC
  Read value 1st byte = MSB [15:8]
  Read value 2nd byte = LSB [7:0]

  Bits [5:0] - Board ID (Range from 0x00 to 0x3F)

  Bit  6     - 0 = Mobile/ULT/Embedded; 
			 - 1= Desktop   
			   (Note: Not required consider this bit when Bit 7 is set) 
  Bit 7      - 0 = Mainstream 
             - 1 =  Entry Notebook & Desktop (Essential Notebook)

  Bit 8      - Generation (Tick / Tock)
               (Note: Not required consider this bit when Bit 7 is set)

  Bits 11:9  - FAB ID (Range from 0x00 to 0x07)

  Bits 15:12 - Reserved

Arguments:

  PeiServices               - General purpose services available to every PEIM.
  BoardFabIds               - Board ID & FabId ID as determined through the EC.

Returns:

  EFI_SUCCESS               The function completed successfully.
							BoardFabIds contains
							MSB - FAB ID (0x00 - 0x07)
							LSB - Board ID (0x00 - 0x3F)
  EFI_DEVICE_ERROR          KSC fails to respond.

--*/
{
 /* bugbug zwei4  EFI_STATUS			Status = EFI_SUCCESS;
  UINT8					DataMSB;
  UINT8					DataLSB;

  //
  // Return Unknown Board ID & Fab ID in case of error.
  //
  *BoardFabIds = 0xFFFF;

  //
  // Send Board ID command to EC
  //
  Status = SendKscCommand (0x0D);
  	if(!EFI_ERROR(Status)) {
		//
		// Read 1st Byte from EC (MSB)
		//
		Status = ReceiveKscData (&DataMSB);
		if(!EFI_ERROR(Status)) {
			//
			// Read 2nd Byte from EC (LSB)
			//
			Status = ReceiveKscData (&DataLSB);
			if(!EFI_ERROR(Status)) {
				if(DataLSB & BIT7) {	// If bit 7 is set, then it is ENBDT
					DataLSB &= 0x3F;
					DataMSB &= 0x0E;
					*BoardFabIds = (UINT16) ((DataMSB << 7) | DataLSB );	// bits [10:8] - FAB ID; bits [5:0] - Board ID
					Status = EFI_SUCCESS;
				}
			}
		}
	}


  return Status; */
  return EFI_SUCCESS;
}

