/*++
  This file contains an 'Intel Peripheral Driver' and is        
  licensed for Intel CPUs and chipsets under the terms of your  
  license agreement with Intel or your vendor.  This file may   
  be modified by the user, subject to additional terms of the   
  license agreement                                             
--*/
/*++

Copyright (c)  1999 - 2011 Intel Corporation. All rights reserved
This software and associated documentation (if any) is furnished
under a license and may only be used or copied in accordance
with the terms of the license. Except as permitted by such
license, no part of this software or documentation may be
reproduced, stored in a retrieval system, or transmitted in any
form or by any means without the express written consent of
Intel Corporation.


Module Name:

  I2CLib.c



--*/
#ifdef ECP_FLAG
#include "EdkIIGlueDxe.h"
#else
#include <Library/DebugLib.h>
#include <Library/TimerLib.h>
#endif
#include <PchRegs/PchRegsPcu.h> 
#include <PchRegs.h>
#include <PlatformBaseAddresses.h>
#include <PchRegs/PchRegsLpss.h> 
#ifdef ECP_FLAG
#include "I2CLib.h"
#else
#include <Library/I2CLib.h>
#endif
#include <Protocol/GlobalNvsArea.h>
#ifndef ECP_FLAG
#include <Library/UefiBootServicesTableLib.h>
#endif

EFI_STATUS ByteReadI2C(
  IN  UINT8 BusNo,
  IN  UINT8 SlaveAddress,
  IN  UINT8 Offset,
  IN  UINTN ReadBytes,
  OUT UINT8 *ReadBuffer
  )
{
  return EFI_SUCCESS;
}
