/*++
  This file contains an 'Intel Peripheral Driver' and is        
  licensed for Intel CPUs and chipsets under the terms of your  
  license agreement with Intel or your vendor.  This file may   
  be modified by the user, subject to additional terms of the   
  license agreement                                             
--*/
/** @file

  Copyright (c) 2004 - 2014, Intel Corporation. All rights reserved.<BR>
  This software and associated documentation (if any) is furnished
  under a license and may only be used or copied in accordance
  with the terms of the license. Except as permitted by such
  license, no part of this software or documentation may be
  reproduced, stored in a retrieval system, or transmitted in any
  form or by any means without the express written consent of
  Intel Corporation.

**/


#include <Uefi.h>
#include <Protocol/Spi.h>
#include <Library/PcdLib.h>
#include <Library/ShellLib.h>
#include <LIbrary/DebugLib.h>

#include <Library/UefiBootServicesTableLib.h>
#include <Library/UefiRuntimeServicesTableLib.h>
#include <Library/BaseLib.h>
#include <Library/MemoryAllocationLib.h>
#include <Library/UefiLib.h>
#include <Library/FileHandleLib.h>
#include <Library/BaseMemoryLib.h>
#include <Library/BaseCryptLib.h>

#include <Guid/Capsule.h>

#include <Protocol/SimpleFileSystem.h>
#include <Protocol/SeCOperation.h>
#include <Guid/Gpt.h>
#include <Guid/FileSystemInfo.h>

#include <Protocol/GraphicsOutput.h>
#include <Library/GenericBdsLib.h>


#define MAX_DIGEST_SIZE    64
#define _REMOVE_AFTER_PV_

#define IFWI_BINARY    L"\\IFWI.bin"
#define IFWI_BINARY1   L"\\IFWI1.bin"
#define IFWI_BINARY2   L"\\IFWI2.bin"
#define IFWI_BINARY3   L"\\IFWI3.bin"
#define IFWI_BINARY4   L"\\IFWI4.bin"
#define IFWI_BINARY5   L"\\spiBIOSImage.bin"
#define CAP_UPDATE_BINARY L"BIOSUpdate.FV"



typedef struct {
  CHAR16    *FileName;
  CHAR16    *String;
} FILE_NAME_TO_STRING;

FILE_NAME_TO_STRING mFlashFileNames[] = {
  { CAP_UPDATE_BINARY},
#ifndef _REMOVE_AFTER_PV_
  { IFWI_BINARY}, 
  { IFWI_BINARY1},
  { IFWI_BINARY2},
  { IFWI_BINARY3},
  { IFWI_BINARY4},
  { IFWI_BINARY5},
#endif
};

#define Capsule_Image  L"\\INTEL.bmp"

#pragma pack(1)

typedef struct {
  UINT8   Blue;
  UINT8   Green;
  UINT8   Red;
  UINT8   Reserved;
} BMP_COLOR_MAP;

typedef struct {
  CHAR8         CharB;
  CHAR8         CharM;
  UINT32        Size;
  UINT16        Reserved[2];
  UINT32        ImageOffset;
  UINT32        HeaderSize;
  UINT32        PixelWidth;
  UINT32        PixelHeight;
  UINT16        Planes;          ///< Must be 1
  UINT16        BitPerPixel;     ///< 1, 4, 8, or 24
  UINT32        CompressionType;
  UINT32        ImageSize;       ///< Compressed image size in bytes
  UINT32        XPixelsPerMeter;
  UINT32        YPixelsPerMeter;
  UINT32        NumberOfColors;
  UINT32        ImportantColors;
} BMP_IMAGE_HEADER;

typedef struct {
  UINT8    Version;
  UINT8    CheckSum;
  UINT8    ImageType;
  UINT8    Reserved;
  UINT32   VideoMode;
  UINT32   ImageOffsetX;
  UINT32   ImageOffsetY;
 } DISPLAY_CAPSULE_PAYLOAD;

#pragma pack()


FILE_NAME_TO_STRING mBitMapFileNames[] = {
  { Capsule_Image }, 
};

EFI_GUID SystemFirmwareGuid = { 0x3bbdb30d, 0xaa9b, 0x4915, { 0x95, 0x03, 0xe4, 0xb8, 0x2f, 0xb6, 0xb6, 0xe9 }};
EFI_GUID BiosCapsuleFromAfuGuid = { 0xCD193840, 0x2881, 0x9567, { 0x39, 0x28, 0x38, 0xc5, 0x97, 0x53, 0x49, 0x77 }};

#define SECTOR_SIZE_4KB      0x1000      // Common 4K Bytes sector size
//#define MAX_FWH_SIZE         0x00200000  // 8Mbit (Note that this can also be used for the 4Mbit )
#define IFWI_SIZE            (0x00800000)
#define IBB_SIZE             (0x20000)
#define BIOS_MANIFEST_SIZE   (0x400)
#define BIOS_MANIFEST_OFFSET (IFWI_SIZE - IBB_SIZE)
#define BIOS_STAGE_I_SIZE    (IBB_SIZE - 0x400)
#define BIOS_STAGE_I_OFFSET  (IFWI_SIZE - BIOS_STAGE_I_SIZE)

//
// Prefix Opcode Index on the host SPI controller
//
typedef enum {
  SPI_WREN,             // Prefix Opcode 0: Write Enable
  SPI_EWSR,             // Prefix Opcode 1: Enable Write Status Register
} PREFIX_OPCODE_INDEX;

//
// Opcode Menu Index on the host SPI controller
//
typedef enum {
  SPI_READ_ID,        // Opcode 0: READ ID, Read cycle with addressary
  SPI_READ,           // Opcode 1: READ, Read cycle with address
  SPI_RDSR,           // Opcode 2: Read Status Register, No address
  SPI_WRDI,           // Opcode 3: Write Disable, No address
  SPI_SERASE,         // Opcode 4: Sector Erase (4KB), Write cycle with address
  SPI_BERASE,         // Opcode 5: Block Erase (32KB), Write cycle with address
  SPI_PROG,           // Opcode 6: Byte Program, Write cycle with address
  SPI_WRSR,           // Opcode 7: Write Status Register, No address
} SPI_OPCODE_INDEX;

//
// Serial Flash Status Register definitions
//
#define SF_SR_BUSY        0x01      // Indicates if internal write operation is in progress
#define SF_SR_WEL         0x02      // Indicates if device is memory write enabled
#define SF_SR_BP0         0x04      // Block protection bit 0
#define SF_SR_BP1         0x08      // Block protection bit 1
#define SF_SR_BP2         0x10      // Block protection bit 2
#define SF_SR_BP3         0x20      // Block protection bit 3
#define SF_SR_WPE         0x3C      // Enable write protection on all blocks
#define SF_SR_AAI         0x40      // Auto Address Increment Programming status
#define SF_SR_BPL         0x80      // Block protection lock-down

typedef enum {
  IFWI_TYPE_CAPSULE_NO_HEADER,
  IFWI_TYPE_FULL_SPI_IMAGE,
  IFWI_TYPE_INVALID,
} IFWI_TYPE_INDEX;

EFI_SPI_PROTOCOL  *mSpiProtocol = NULL;

EFI_STATUS
AfuConvertBmpToGopBlt (
  IN     VOID      *BmpImage,
  IN     UINTN     BmpImageSize,
  IN OUT VOID      **GopBlt,
  IN OUT UINTN     *GopBltSize,
     OUT UINTN     *PixelHeight,
     OUT UINTN     *PixelWidth
  )
{
  UINT8                         *Image;
  UINT8                         *ImageHeader;
  BMP_IMAGE_HEADER              *BmpHeader;
  BMP_COLOR_MAP                 *BmpColorMap;
  EFI_GRAPHICS_OUTPUT_BLT_PIXEL *BltBuffer;
  EFI_GRAPHICS_OUTPUT_BLT_PIXEL *Blt;
  UINT64                        BltBufferSize;
  UINTN                         Index;
  UINTN                         Height;
  UINTN                         Width;
  UINTN                         ImageIndex;
  BOOLEAN                       IsAllocated;

  BmpHeader = (BMP_IMAGE_HEADER *) BmpImage;

  if (BmpHeader->CharB != 'B' || BmpHeader->CharM != 'M') {
    //Print(L"Invalid BMP header.\r\n");
    return EFI_UNSUPPORTED;
  }

  //
  // Doesn't support compress.
  //
  if (BmpHeader->CompressionType != 0) {
   // Print(L"Unsupported compress type.\r\n");
    return EFI_UNSUPPORTED;
  }

  //
  // Calculate Color Map offset in the image.
  //
  Image       = BmpImage;
  BmpColorMap = (BMP_COLOR_MAP *) (Image + sizeof (BMP_IMAGE_HEADER));

  //
  // Calculate graphics image data address in the image
  //
  Image         = ((UINT8 *) BmpImage) + BmpHeader->ImageOffset;
  ImageHeader   = Image;

  //
  // Calculate the BltBuffer needed size.
  //
  BltBufferSize = MultU64x32 ((UINT64) BmpHeader->PixelWidth, BmpHeader->PixelHeight);
  //
  // Ensure the BltBufferSize * sizeof (EFI_GRAPHICS_OUTPUT_BLT_PIXEL) doesn't overflow
  //
  if (BltBufferSize > DivU64x32 ((UINTN) ~0, sizeof (EFI_GRAPHICS_OUTPUT_BLT_PIXEL))) {
      //Print(L"Needed bltbuffer size overflow.\r\n");
      return EFI_UNSUPPORTED;
   }
  BltBufferSize = MultU64x32 (BltBufferSize, sizeof (EFI_GRAPHICS_OUTPUT_BLT_PIXEL));

  IsAllocated   = FALSE;
  if (*GopBlt == NULL) {
    //
    // GopBlt is not allocated by caller.
    //
    *GopBltSize = (UINTN) BltBufferSize;
    *GopBlt     = AllocatePool (*GopBltSize);
    IsAllocated = TRUE;
    if (*GopBlt == NULL) {
      //Print(L"Failed to allocate GopBlt buffer when NULL.\r\n");
      return EFI_OUT_OF_RESOURCES;
    }
  } else {
    //
    // GopBlt has been allocated by caller.
    //
    if (*GopBltSize < (UINTN) BltBufferSize) {
      *GopBltSize = (UINTN) BltBufferSize;
      //Print(L"GopBlt buffer alloc by caller, but buffer too small.\r\n");
      return EFI_BUFFER_TOO_SMALL;
    }
  }

  *PixelWidth   = BmpHeader->PixelWidth;
  *PixelHeight  = BmpHeader->PixelHeight;

  //
  // Convert image from BMP to Blt buffer format
  //
  BltBuffer = *GopBlt;
  for (Height = 0; Height < BmpHeader->PixelHeight; Height++) {
    Blt = &BltBuffer[(BmpHeader->PixelHeight - Height - 1) * BmpHeader->PixelWidth];
    for (Width = 0; Width < BmpHeader->PixelWidth; Width++, Image++, Blt++) {
      switch (BmpHeader->BitPerPixel) {
      case 1:
        //
        // Convert 1-bit (2 colors) BMP to 24-bit color
        //
        for (Index = 0; Index < 8 && Width < BmpHeader->PixelWidth; Index++) {
          Blt->Red    = BmpColorMap[((*Image) >> (7 - Index)) & 0x1].Red;
          Blt->Green  = BmpColorMap[((*Image) >> (7 - Index)) & 0x1].Green;
          Blt->Blue   = BmpColorMap[((*Image) >> (7 - Index)) & 0x1].Blue;
          Blt++;
          Width++;
        }

        Blt--;
        Width--;
        break;

      case 4:
        //
        // Convert 4-bit (16 colors) BMP Palette to 24-bit color
        //
        Index       = (*Image) >> 4;
        Blt->Red    = BmpColorMap[Index].Red;
        Blt->Green  = BmpColorMap[Index].Green;
        Blt->Blue   = BmpColorMap[Index].Blue;
        if (Width < (BmpHeader->PixelWidth - 1)) {
          Blt++;
          Width++;
          Index       = (*Image) & 0x0f;
          Blt->Red    = BmpColorMap[Index].Red;
          Blt->Green  = BmpColorMap[Index].Green;
          Blt->Blue   = BmpColorMap[Index].Blue;
        }
        break;

      case 8:
        //
        // Convert 8-bit (256 colors) BMP Palette to 24-bit color
        //
        Blt->Red    = BmpColorMap[*Image].Red;
        Blt->Green  = BmpColorMap[*Image].Green;
        Blt->Blue   = BmpColorMap[*Image].Blue;
        break;

      case 24:
        //
        // It is 24-bit BMP.
        //
        Blt->Blue   = *Image++;
        Blt->Green  = *Image++;
        Blt->Red    = *Image;
        break;
      
      case 32:
        //
        // It is 24-bit BMP.
        //
        Blt->Blue   = *Image++;
        Blt->Green  = *Image++;
        Blt->Red    = *Image++;
        break;


      default:
        //
        // Other bit format BMP is not supported.
        //
        if (IsAllocated) {
          FreePool (*GopBlt);
          *GopBlt = NULL;
        }
        //Print(L"Default BMP format not supported.\r\n");
        return EFI_UNSUPPORTED;
        break;
      };

    }

    ImageIndex = (UINTN) (Image - ImageHeader);
    if ((ImageIndex % 4) != 0) {
      //
      // Bmp Image starts each row on a 32-bit boundary!
      //
      Image = Image + (4 - (ImageIndex % 4));
    }
  }
  
  //Print(L"Exiting AfuGopBmpConvert \r\n");
  return EFI_SUCCESS;
}

EFI_STATUS
DisplayCapsuleImage (
 VOID
 )
{
  EFI_STATUS                            Status;
  EFI_HANDLE                            *HandleArray;
  UINTN                                 HandleArrayCount,Index;
  EFI_SIMPLE_FILE_SYSTEM_PROTOCOL       *Fs;
  EFI_FILE                              *Root,*FileHandle = NULL;
  VOID                                  *FileBuffer = NULL,*ImageBuffer = NULL;
  UINTN                                FileSize =0,ImageSize =0;
  UINT64                                TempFileSize=0;
  INTN                                  DestX = 0,DestY = 0;
  UINTN                                 BltSize = 0,Height = 0,Width = 0;
  EFI_GRAPHICS_OUTPUT_BLT_PIXEL         *Blt;
  EFI_GRAPHICS_OUTPUT_PROTOCOL          *GraphicsOutput;
  DISPLAY_CAPSULE_PAYLOAD               *DisplayCapsuleAttr = NULL;
  

  Status = gBS->LocateHandleBuffer (ByProtocol, &gEfiPartTypeSystemPartGuid, NULL, &HandleArrayCount, &HandleArray);
  if (EFI_ERROR (Status)) {
    return Status;
  }

  //
  // For each system partition...
  //
  for (Index = 0; Index < HandleArrayCount; Index++) {
    Status = gBS->HandleProtocol (HandleArray[Index], &gEfiSimpleFileSystemProtocolGuid, (VOID **)&Fs);
    if (EFI_ERROR (Status)) {
      continue;
    }
    Status = Fs->OpenVolume (Fs, &Root);
    if (EFI_ERROR (Status)) {
      continue;
    }
    Status = Root->Open (Root, &FileHandle, mBitMapFileNames[0].FileName, EFI_FILE_MODE_WRITE|EFI_FILE_MODE_READ, 0);
    if (EFI_ERROR (Status)) {
      continue;
    }
    Status = FileHandleGetSize (FileHandle, (UINT64*)&TempFileSize);
    if(EFI_ERROR(Status)) {
      return Status ;
    }
     
    FileSize = (UINT32) TempFileSize;

    FileBuffer = AllocateZeroPool(FileSize);
    if(FileBuffer == NULL) {
      return Status ;
    }

    Status = FileHandleRead (FileHandle, &FileSize, FileBuffer);
    if(EFI_ERROR(Status)) {
      FreePool (FileBuffer);
      return Status ;
    }

    Status = FileHandleDelete(FileHandle);
    if(EFI_ERROR(Status)) {
      FreePool (FileBuffer);
      return Status ;
    }
  DisplayCapsuleAttr = ( DISPLAY_CAPSULE_PAYLOAD *)FileBuffer;
  ImageBuffer = (VOID *)((UINTN)DisplayCapsuleAttr + sizeof (DISPLAY_CAPSULE_PAYLOAD));// pointing to start of image
  ImageSize = FileSize - sizeof (DISPLAY_CAPSULE_PAYLOAD);// getting image size

    Status = gBS->HandleProtocol (gST->ConsoleOutHandle, &gEfiGraphicsOutputProtocolGuid, (VOID **) &GraphicsOutput);
    
    if (EFI_ERROR (Status)) {
      return EFI_UNSUPPORTED;
    }
    
    if (GraphicsOutput != NULL) {
      GraphicsOutput->Mode->Mode = DisplayCapsuleAttr->VideoMode;
      DestX = DisplayCapsuleAttr->ImageOffsetX;
      DestY = DisplayCapsuleAttr->ImageOffsetY;
    }
 
    Blt = NULL;
    Status = AfuConvertBmpToGopBlt (
              ImageBuffer,
              ImageSize,
              (VOID **) &Blt,
              &BltSize,
              &Height,
              &Width
              );
    if (EFI_ERROR (Status)) {
      FreePool (FileBuffer);
      FileBuffer = NULL;
      return Status;
    }

    if (GraphicsOutput != NULL) {
        Status = GraphicsOutput->Blt (
                            GraphicsOutput,
                            Blt,
                            EfiBltBufferToVideo,
                            0,
                            0,
                            DestX,
                            DestY,
                            Width,
                            Height,
                            0
                            );
        if (EFI_ERROR (Status)) {
          FreePool (FileBuffer);
          FileBuffer = NULL;
          return Status;
        }
   }else {
      Status = EFI_UNSUPPORTED;
   }
   FreePool (FileBuffer);
   FileBuffer = NULL;

    if (Blt != NULL) {
      FreePool (Blt);
    }
 
  }//End of For
  return EFI_SUCCESS;

}

BOOLEAN
FlashReadCompare (
  IN  UINT32 BaseAddress,
  IN  UINT8 *Byte,
  IN  UINTN Length,
  IN  SPI_REGION_TYPE  SpiRegionType
)
{
  EFI_STATUS          Status = EFI_SUCCESS;
  UINT32              SpiAddress;
  UINT8               Buffer[SECTOR_SIZE_4KB];

  SpiAddress = (UINTN)(BaseAddress);
  
  while ( Length > 0 ) {
    Status = mSpiProtocol->Execute (
                  mSpiProtocol,
                  SPI_READ,
                  SPI_WREN,
                  TRUE,
                  TRUE,
                  FALSE,
                  SpiAddress,
                  SECTOR_SIZE_4KB,
                  Buffer,
                  SpiRegionType
                );
    if (EFI_ERROR (Status)) {
      Print(L"Read SPI ROM Failed [0x%08x]\n", SpiAddress); 
      return FALSE;
    }
    SpiAddress += SECTOR_SIZE_4KB;
    Length     -= SECTOR_SIZE_4KB;
    if (CompareMem(Buffer, Byte, SECTOR_SIZE_4KB)) {
      return FALSE;
    }
  }
  return TRUE;
}


EFI_STATUS
FlashErase (
  IN  UINT32  BaseAddress,
  IN  UINTN  NumBytes,
  IN  SPI_REGION_TYPE  SpiRegionType
  )
{
  EFI_STATUS          Status = EFI_SUCCESS;
  UINT32              SpiAddress;

  SpiAddress = (UINTN)(BaseAddress);
  while ( NumBytes > 0 ) {
    Status = mSpiProtocol->Execute (
                             mSpiProtocol,
                             SPI_SERASE,
                             SPI_WREN,
                             FALSE,
                             TRUE,
                             FALSE,
                             SpiAddress,
                             0,
                             NULL,
                             SpiRegionType
                             );
    if (EFI_ERROR (Status)) {
      break;
    }
    SpiAddress += SECTOR_SIZE_4KB;
    NumBytes   -= SECTOR_SIZE_4KB;
  }

  return Status;
}


EFI_STATUS
FlashWrite (
  IN  UINT32 DstBufferPtr,
  IN  UINT8 *Byte,
  IN  UINTN Length,
  IN  SPI_REGION_TYPE   SpiRegionType
  )
{
  EFI_STATUS                Status;
  UINT32                    NumBytes = (UINT32)Length;
  UINT8*                    pBuf8 = Byte;
  UINT32                    SpiAddress;

  SpiAddress = (UINTN)(DstBufferPtr);
  Status = mSpiProtocol->Execute (
                           mSpiProtocol,
                           SPI_PROG,
                           SPI_WREN,
                           TRUE,
                           TRUE,
                           TRUE,
                           SpiAddress,
                           NumBytes,
                           pBuf8,
                           SpiRegionType
                           );
  return Status;
}


EFI_STATUS BIOSVerify(
  IN  UINTN            FileSize,
  IN  UINT8            *FileBuffer,
  IN  SPI_REGION_TYPE  SpiRegionType
  )
{
 UINT32           DataIndex;
 BOOLEAN         Flag = TRUE;   

  for (DataIndex = 0; DataIndex < FileSize; DataIndex += SECTOR_SIZE_4KB) { 
    if(FlashReadCompare(DataIndex, FileBuffer + DataIndex, SECTOR_SIZE_4KB, SpiRegionType)) {
      Print(L"Verifying... %d%% Completed.  \r", (DataIndex * 100 / FileSize));  
      continue;      
    } 
    Print(L"Verifying... %d%% Completed   Error at [%08x].  \n", (DataIndex * 100 / FileSize), DataIndex);  
    Flag = FALSE;
  }
  Print(L"Flash Verify Complete. ");
  if(Flag) {
    Print(L"It's same...!!\n");
  } else {
    Print(L"It's different as show...!!\n");
  }
  return EFI_SUCCESS;
}


EFI_STATUS BIOSFlash(
  IN  UINTN              FileSize,
  IN  UINT8              *FileBuffer,
  IN  SPI_REGION_TYPE    SpiRegionType
  )
{
  UINT32  DataIndex;
  for (DataIndex = 0; DataIndex < FileSize; DataIndex += SECTOR_SIZE_4KB) { 
    if(FlashReadCompare(DataIndex, FileBuffer + DataIndex, SECTOR_SIZE_4KB, SpiRegionType)) {
      Print(L"Updating firmware... %3d%% Completed.  \r", (DataIndex * 100 / FileSize));  
      continue;      
    } 
    FlashErase(DataIndex, SECTOR_SIZE_4KB, SpiRegionType);
    Print(L"Updating firmware... %3d%% Completed.  \r", (DataIndex * 100 / FileSize));  
    FlashWrite(DataIndex, FileBuffer + DataIndex, SECTOR_SIZE_4KB, SpiRegionType);
  }
  
  return EFI_SUCCESS;  
}

EFI_STATUS Sha1_Hash(UINT8 *Digest, void * sha1buffer, UINT32 sha1Size){
  UINTN    CtxSize;
  VOID     *HashCtx;
  EFI_STATUS Status;
  ZeroMem (Digest, MAX_DIGEST_SIZE);
  CtxSize = Sha1GetContextSize ();
  HashCtx = AllocatePool (CtxSize);
  if(HashCtx == NULL) return EFI_OUT_OF_RESOURCES;
  DEBUG((EFI_D_INFO, "Sha1 Init...\r\n"));
  Status  = Sha1Init (HashCtx);   
  if (!Status) {
    Print (L"Sha1Init fail\r\n");
    goto _sha1_failed;
  }
  Status = Sha1Update (HashCtx, sha1buffer, sha1Size);
  if (!Status) {
    Print (L"Sha1Update fail\r\n");
    goto _sha1_failed;
  }
  DEBUG((EFI_D_INFO, "Sha1 Finalize... \r\n"));
  Status = Sha1Final (HashCtx, Digest);
  if (!Status) {
    Print(L"Sha1Final Fail\r\n");
    goto _sha1_failed;
  }
  FreePool(HashCtx);
  return EFI_SUCCESS; 
_sha1_failed:
  FreePool(HashCtx);
  return EFI_ABORTED;
   
}

EFI_STATUS Sha256_Hash(UINT8 *Digest, void * sha256buffer, UINT32 sha256Size){
  UINTN    CtxSize;
  VOID     *HashCtx;
  EFI_STATUS Status;
  ZeroMem (Digest, MAX_DIGEST_SIZE);
  CtxSize = Sha256GetContextSize ();
  HashCtx = AllocatePool (CtxSize);
  if(HashCtx == NULL) return EFI_OUT_OF_RESOURCES;
  DEBUG((EFI_D_INFO, "Sha256 Init...\r\n"));
  Status  = Sha256Init (HashCtx);   
  if (!Status) {
    Print (L"Sha256 Init fail\r\n");
    goto _sha256_failed;
  }
  DEBUG((EFI_D_INFO, "Sha256 Update...\r\n"));
  Status = Sha256Update (HashCtx, sha256buffer, sha256Size);
  if (!Status) {
    Print (L"Sha256 Update fail\r\n");
    goto _sha256_failed;
  }
  DEBUG((EFI_D_INFO, "Sha256 Finalize... \r\n"));
  Status = Sha256Final (HashCtx, Digest);
  if (!Status) {
    Print(L"Sha256 Final Fail\r\n");
    goto _sha256_failed;
  }
  FreePool(HashCtx);
  return EFI_SUCCESS;  
_sha256_failed:
  FreePool(HashCtx);
  return EFI_ABORTED;
}


EFI_STATUS ImageIntegrityVerify(void *FileBuffer, UINT32 FileSize) {  
  UINT8    Digest[MAX_DIGEST_SIZE];
  EFI_STATUS  Status;
  UINT32   i = 0,match = 0;
  UINT32   IFWISigBaseAddress = 0;
  UINT32   shaoffset = 0, shasize = 0;
  Status = EFI_SUCCESS;
//_verify_PLATFORM_ID:
//_verify_IFWI_: 
  IFWISigBaseAddress = PcdGet32(PcdIFWISigBaseAddress);
  if(!CompareMem((void *)((UINTN)FileBuffer + 0x100000), (void *)"IFWISHA1_01", AsciiStrLen("IFWISHA1_01"))) {
//for rollback compatibility    
    IFWISigBaseAddress = 0x100000;
  }
//
//At PcdIFWISigBaseAddress, there mayn't exist a valid signature.
//AsciiStrnCmp will always search the first null terminated character.
//
  if(!CompareMem((void *)((UINTN)FileBuffer + IFWISigBaseAddress), (void *)"IFWISHA1_01", AsciiStrLen("IFWISHA1_01"))) {
// 32 bytes of signature
// 32 bytes of sha1 hash of 1 st part(0x0~0x100000) + 32 bytes hash of 2nd part(0x100060 ~ 0x800000) 
    shaoffset = 0;
    shasize   = IFWISigBaseAddress;
    DEBUG((EFI_D_INFO, "IFWI Signature: IFWISHA1_01...\r\n"));
    DEBUG((EFI_D_INFO, "Verify the 1st part\r\n"));
    Sha1_Hash(Digest, (void *)((UINTN)FileBuffer + shaoffset), shasize);
    DEBUG((EFI_D_INFO, "Check Value...\r\n"));
    DEBUG((EFI_D_INFO, "Digest:\r\n"));
    for(i = 0; i < SHA1_DIGEST_SIZE ; i ++) {
      if( (i % 16) == 0 ) {
        DEBUG((EFI_D_INFO, "0x%02x: ", i));
      }
      DEBUG((EFI_D_INFO, "%02x ", Digest[i]));
      if( (i % 16) == 15) {
        DEBUG((EFI_D_INFO, "\r\n"));
      }
    }
    DEBUG((EFI_D_INFO, "\r\nHash in file:\r\n"));
    for(i = 0; i < SHA256_DIGEST_SIZE ; i ++) {
      if( (i % 16) == 0 ) {
        DEBUG((EFI_D_INFO, "0x%02x: ", i));
      }
      DEBUG((EFI_D_INFO, "%02x ", ((UINT8 *)((UINTN)FileBuffer + IFWISigBaseAddress + 0x20))[i]));
      if( (i % 16) == 15) {
        DEBUG((EFI_D_INFO, "\r\n"));
      }
    }
    match = 1;
    for(i = 0; i < SHA1_DIGEST_SIZE ; i++) {      
      if(((UINT8 *)((UINTN)FileBuffer + IFWISigBaseAddress + 0x20))[i] !=  Digest[SHA1_DIGEST_SIZE - i]) {
        match = 0;
        break;
      }
    }
    if( match == 0) {
      match = 1;
      for(i = 0; i < SHA1_DIGEST_SIZE ; i++) {      
        if(((UINT8 *)((UINTN)FileBuffer + IFWISigBaseAddress + 0x20))[i] !=  Digest[i]) {
          match = 0;
          break;
        }
      }
    } 
    if(match == 0) {
      Print(L"1st part verification failed\r\n");
      return EFI_ABORTED;
    }
    DEBUG((EFI_D_INFO, "1st part verify success\r\n"));

    shaoffset = IFWISigBaseAddress + 0x60;
    shasize   = IFWI_SIZE - shaoffset;
    DEBUG((EFI_D_INFO, "Verify the 2nd part\r\n"));
    Sha1_Hash(Digest, (void *)((UINTN)FileBuffer + shaoffset), shasize);
    DEBUG((EFI_D_INFO, "Check Value...\r\n"));
    DEBUG((EFI_D_INFO, "Digest:\r\n"));
    for(i = 0; i < SHA1_DIGEST_SIZE ; i ++) {
      if( (i % 16) == 0 ) {
        DEBUG((EFI_D_INFO, "0x%02x: ", i));
      }
      DEBUG((EFI_D_INFO, "%02x ", Digest[i]));
      if( (i % 16) == 15) {
        DEBUG((EFI_D_INFO, "\r\n"));
      }
    }
    DEBUG((EFI_D_INFO, "\r\nHash in file:\r\n"));
    for(i = 0; i < SHA256_DIGEST_SIZE ; i ++) {
      if( (i % 16) == 0 ) {
        DEBUG((EFI_D_INFO, "0x%02x: ", i));
      }
      DEBUG((EFI_D_INFO, "%02x ", ((UINT8 *)((UINTN)FileBuffer + IFWISigBaseAddress + 0x40))[i]));
      if( (i % 16) == 15) {
        DEBUG((EFI_D_INFO, "\r\n"));
      }
    }
    match = 1;
    for(i = 0; i < SHA1_DIGEST_SIZE ; i++) {      
      if(((UINT8 *)((UINTN)FileBuffer + IFWISigBaseAddress + 0x40))[i] !=  Digest[SHA1_DIGEST_SIZE - i]) {
        match = 0;
        break;
      }
    }
    if( match == 0) {
      match = 1;
      for(i = 0; i < SHA1_DIGEST_SIZE ; i++) {      
        if(((UINT8 *)((UINTN)FileBuffer + IFWISigBaseAddress + 0x40))[i] !=  Digest[i]) {
          match = 0;
          break;
        }
      }
    } 
    if(match == 0) {
      Print(L"2nd part verification failed\r\n");
      return EFI_ABORTED;
    }
    return EFI_SUCCESS;
  } else {
    Print(L"No valid IFWI signature found\r\n");
    return EFI_ABORTED;
  }
#if 0  
  DEBUG((EFI_D_INFO, "IFWI verify success\r\n"));  
  DEBUG((EFI_D_INFO, "Public key verify skipped, success\r\n"));
  DEBUG((EFI_D_INFO, "Manifest RSA Verify skipped, success\r\n"));
  DEBUG((EFI_D_INFO, "Verify BIOS Stage I\r\n"));   
  Status  = Sha256_Hash (Digest, (void *)((UINTN)FileBuffer + BIOS_STAGE_I_OFFSET), BIOS_STAGE_I_SIZE);
  if (EFI_ERROR(Status)) {
    Print (L"Sha256_Hash fail\r\n");
    return EFI_ABORTED;
  }

  DEBUG((EFI_D_INFO, "Check Value...\r\n"));
  DEBUG((EFI_D_INFO, "Digest:\r\n"));
  for(i = 0; i < SHA256_DIGEST_SIZE ; i ++) {
    if( (i % 16) == 0 ) {
      DEBUG((EFI_D_INFO, "0x%02x: ", i));
    }
    DEBUG((EFI_D_INFO, "%02x ", Digest[i]));
    if( (i % 16) == 15) {
      DEBUG((EFI_D_INFO, "\r\n"));
    }
  }
  DEBUG((EFI_D_INFO, "\r\nManifest hash:\r\n"));
  for(i = 0; i < SHA256_DIGEST_SIZE ; i ++) {
    if( (i % 16) == 0 ) {
      DEBUG((EFI_D_INFO, "0x%02x: ", i));
    }
    DEBUG((EFI_D_INFO, "%02x ", ((UINT8 *)((UINTN)FileBuffer + BIOS_MANIFEST_OFFSET + 20))[i]));
    if( (i % 16) == 15) {
      DEBUG((EFI_D_INFO, "\r\n"));
    }
  }
  match = 1;
  for(i = 0; i < SHA256_DIGEST_SIZE ; i ++) {
    if(((UINT8 *)((UINTN)FileBuffer + BIOS_MANIFEST_OFFSET + 20))[i] !=  Digest[SHA256_DIGEST_SIZE - i - 1]) {
      DEBUG((EFI_D_INFO, "Sha256 Digest compare fail1\r\n"));
      match = 0;
      break;;
    } 
  }
  if(match == 0) {
    match = 1;
    for(i = 0; i < SHA256_DIGEST_SIZE ; i ++) {
      if(((UINT8 *)((UINTN)FileBuffer + BIOS_MANIFEST_OFFSET + 20))[i] !=  Digest[i]) {
        DEBUG((EFI_D_INFO, "Sha256 Digest compare fail2\r\n"));
        match = 0;
        break;;
      } 
    }
  }
  return match == 0? EFI_ABORTED: EFI_SUCCESS;
#endif  
}


EFI_STATUS
GetValidIFWI(void **pBuffer, UINT64 *pSize)
{
  EFI_STATUS Status;
  EFI_SIMPLE_FILE_SYSTEM_PROTOCOL *Fs;
  EFI_FILE                        *Root;
  EFI_HANDLE                      *HandleArray;
  UINTN                            HandleArrayCount;
  UINT32                           Index, i;
  EFI_FILE                        *FileHandle;
  UINT64                           FileSize = 0, TmpFileSize = 0;
  VOID                            *FileBuffer  = NULL;
  EFI_CAPSULE_HEADER        *CapsuleHeader = NULL;
  EFI_GUID                  CapsuleGuid;
  EFI_CAPSULE_HEADER  *ech[1]; 
  EFI_PHYSICAL_ADDRESS sc = (EFI_PHYSICAL_ADDRESS)0;
  UINT8                    bAFUCapsule = 0;


  Status = gBS->LocateHandleBuffer(ByProtocol, &gEfiPartTypeSystemPartGuid, NULL, &HandleArrayCount, &HandleArray);
  if(EFI_ERROR(Status)) {
    DEBUG((EFI_D_ERROR, "AFU: LocateHandleBuffer Error, no valid partition found.\r\n"));
    return Status;
  }
  //
  //For each system partition, search existence of IFWI.bin
  //
  for(Index = 0; Index < HandleArrayCount; Index++) {
    Status = gBS->HandleProtocol(HandleArray[Index], &gEfiSimpleFileSystemProtocolGuid, (VOID**)&Fs);
    if(EFI_ERROR(Status)) {
      DEBUG((EFI_D_ERROR, "AFU: Open Handle protocol failed\r\n"));
      continue;
    }
    Status = Fs->OpenVolume(Fs, &Root);
    if(EFI_ERROR(Status)) {
      DEBUG((EFI_D_ERROR, "AFU: Open Volume Error.\r\n"));
      continue;
    }    
    for(i = 0; i < sizeof(mFlashFileNames) / sizeof (mFlashFileNames[0]); i++) {   
      DEBUG((EFI_D_INFO, "AFU: try file %s\r\n", mFlashFileNames[i].FileName));
      Status = Root->Open(Root, &FileHandle, mFlashFileNames[i].FileName, EFI_FILE_MODE_WRITE|EFI_FILE_MODE_READ, 0);
      if(EFI_ERROR(Status)) {
        DEBUG((EFI_D_INFO, "AFU: Open IFWI %s failed, try next one\r\n", mFlashFileNames[i].FileName));
        continue;
      } else {
       // Print(L"AFU: Test IFWI %s \r\n", mFlashFileNames[i].FileName);
      }
      Status = FileHandleGetSize(FileHandle, &FileSize);
      if(EFI_ERROR(Status)) {
        Print(L"AFU: GetSize failed.\r\n");
        continue;
      }
     // Print(L"FileSize is 0x%08x\r\n", FileSize);
      FileBuffer = AllocateZeroPool((UINTN)FileSize);
      if(FileBuffer == NULL) {
        Print(L"AFU: Failed to allocate memory\r\n");
        continue;
      }
      TmpFileSize = FileSize;
      Status = FileHandleRead(FileHandle, (UINTN*)&TmpFileSize, FileBuffer);
      if(EFI_ERROR(Status) || (UINT32)FileSize != (UINT32)TmpFileSize) {
        Print(L"AFU: File read failed.\r\n");
        FreePool(FileBuffer);
        FileBuffer = NULL;
        continue;
      }
      //
      //If current image is BIOSUpdate.FV, then we're in UpdateCapsule path.
      //
      if(i == 0){
        CapsuleGuid = SystemFirmwareGuid;
        CapsuleHeader = (EFI_CAPSULE_HEADER *)AllocateZeroPool((UINTN)FileSize + sizeof(EFI_CAPSULE_HEADER));
        CapsuleHeader->HeaderSize = sizeof(EFI_CAPSULE_HEADER);
        CapsuleHeader->CapsuleImageSize =(UINT32)((UINTN)( FileSize + CapsuleHeader->HeaderSize));
        CapsuleHeader->Flags = CAPSULE_FLAGS_INITIATE_RESET | CAPSULE_FLAGS_PERSIST_ACROSS_RESET;
        CapsuleHeader->CapsuleGuid = CapsuleGuid;
        CopyMem((void *)((UINTN)CapsuleHeader + CapsuleHeader->HeaderSize),FileBuffer, (UINTN)FileSize); 
        ech[0] = CapsuleHeader;
        //
        //Now delete the Capsule FV, and dispatch the capsule
        //
        Status = FileHandleDelete(FileHandle);
        if(EFI_ERROR(Status)){
            DEBUG((EFI_D_ERROR, "BIOS Capsule Update: Failed to delete the capsule FV.\r\n"));
            FreePool(CapsuleHeader);
            return Status;
        }

        EnableQuietBoot (PcdGetPtr(PcdLogoFile));

        DisplayCapsuleImage();

        bAFUCapsule = 1;
        Status = gRT->SetVariable(L"CapsuleFromAFU",
                                  &BiosCapsuleFromAfuGuid,
                                  EFI_VARIABLE_NON_VOLATILE | EFI_VARIABLE_RUNTIME_ACCESS | EFI_VARIABLE_BOOTSERVICE_ACCESS,
                                  sizeof(bAFUCapsule),
                                  &bAFUCapsule);

        if(EFI_ERROR(Status)){
            FreePool(CapsuleHeader);
            return Status;
        }

        BdsLibConnectAll();

        Status = gRT->UpdateCapsule(ech,1,sc);
        //
        //We should never reach here.
        //

        gRT->ResetSystem(EfiResetWarm, EFI_SUCCESS, 0, NULL);
        FreePool(CapsuleHeader);
        return Status;
      }

      if(ImageIntegrityVerify(FileBuffer, (UINT32)FileSize) == EFI_SUCCESS) {       
         break;        
      } else {
        FreePool(FileBuffer);
        continue;
      }        
    }
    if(i <  sizeof(mFlashFileNames) / sizeof (mFlashFileNames[0])) {
      Print(L"Find valid IFWI %s\r\n", mFlashFileNames[i].FileName);
      *pBuffer = FileBuffer;
      *pSize = FileSize;
      return EFI_SUCCESS;
    }
  }
  return EFI_ABORTED;
}

void CleanIFWI()
{
  EFI_STATUS Status;
  EFI_SIMPLE_FILE_SYSTEM_PROTOCOL *Fs;
  EFI_FILE                        *Root;
  EFI_HANDLE                      *HandleArray;
  UINTN                            HandleArrayCount;
  UINT32                           Index, i;
  EFI_FILE                        *FileHandle;
  Status = gBS->LocateHandleBuffer(ByProtocol, &gEfiPartTypeSystemPartGuid, NULL, &HandleArrayCount, &HandleArray);
  if(EFI_ERROR(Status)) {
    DEBUG((EFI_D_ERROR, "AFU: LocateHandleBuffer Error, no valid partition found.\r\n"));
    return ;
  }
  //
  //For each system partition, search existence of IFWI.bin
  //
  for(Index = 0; Index < HandleArrayCount; Index++) {
    Status = gBS->HandleProtocol(HandleArray[Index], &gEfiSimpleFileSystemProtocolGuid, (VOID**)&Fs);
    if(EFI_ERROR(Status)) {
      DEBUG((EFI_D_ERROR, "AFU: Open Handle protocol failed\r\n"));
      continue;
    }
    Status = Fs->OpenVolume(Fs, &Root);
    if(EFI_ERROR(Status)) {
      DEBUG((EFI_D_ERROR, "AFU: Open Volume Error.\r\n"));
      continue;
    }    
    for(i = 0; i < sizeof(mFlashFileNames) / sizeof (mFlashFileNames[0]); i++) {   
      DEBUG((EFI_D_INFO, "AFU: try to delete file %s\r\n", mFlashFileNames[i].FileName));
      Status = Root->Open(Root, &FileHandle, mFlashFileNames[i].FileName, EFI_FILE_MODE_WRITE|EFI_FILE_MODE_READ, 0);
      if(EFI_ERROR(Status)) {
        DEBUG((EFI_D_INFO, "AFU: Open %s failed, try next one\r\n", mFlashFileNames[i].FileName));
        continue;
      }
      Status = FileHandleDelete(FileHandle);
    }
  }
  return;
}
  
EFI_STATUS
IFWIUpdateHack(
)
{
  EFI_STATUS                      Status;  
  
  VOID                            *FileBuffer  = NULL;
  UINT64                          FileSize;
  SPI_REGION_TYPE                 SpiRegionType;

  UINT32                          SecEnabled = 1;
  UINT32                          SecOvrEnabled = 0;
  UINT32                          HmrpfoEnableRequired = 0;

  SEC_OPERATION_PROTOCOL          *SecOp;
  SEC_INFOMATION                  SecInfo;
  

  FileSize = 0;
  FileBuffer = NULL;
  HmrpfoEnableRequired = 0;   //indicate the update process that no hmrpfo enable operation is required.


  Status = gBS->LocateProtocol(
          &gEfiSeCOperationProtocolGuid,
          NULL,
          &SecOp);
  if(EFI_ERROR(Status)) {
    DEBUG((EFI_D_ERROR, "AFU: SecOperationProtocol couldn't be located\r\n"));
    return Status;
  }
  Status = SecOp->GetPlatformSeCInfo(&SecInfo);
  if(EFI_ERROR(Status)) {
    Print(L"AFU: GetPlatformSecInfo failed\n");
    return Status;
  }
  if( (SecInfo.SeCExist == 0) || (SecInfo.SeCEnable == 0)) {
    SecEnabled = 0;    
  } else if(SecInfo.SeCOpMode == 5) { //hmrfpo enabled.
    SecOvrEnabled = 1;
  } else {
    HmrpfoEnableRequired = 1;
  }    

  Status = GetValidIFWI(&FileBuffer, &FileSize);
  if(EFI_ERROR(Status)) {
    DEBUG((EFI_D_INFO, "No valid IFWI found, clean all the files and exit\r\n"));
    CleanIFWI();
    goto ErrorExit;
  }
 // Print(L"Find valid IFWI\r\n");
  
  if(FileSize == 0x800000) {
    SpiRegionType = EnumSpiRegionAll;
  } else {
    Print(L"AFU: image size is incorrect.\r\n");
    CleanIFWI();
    Status = EFI_ABORTED;
    goto ErrorExit;
  }
  
  //
  //If file read succeed and GRST is required, we cannot delete the file.
  //Enable hmrfpo. GRST will be issued and control never returns to IA
  //
  if(HmrpfoEnableRequired == 1) {
    Print(L"AFU: hmrfpo not enabled.. Enable hmrfpo and issue GRST\n");
    SecInfo.HmrfpoEnable = 1;
    //
    //GSRT will be issued once the setting to sec succeed.
  //
    Status = SecOp->SetPlatformSeCInfo(&SecInfo);
    if(EFI_ERROR(Status)) {
      Print(L"AFU: SetPlatformSecInfo failed\n");
      CleanIFWI();
      return Status;
    }
    gBS->Stall(10000000);
    //Shouldn't reach here.
    Print(L"\r\n\r\n\r\n!!!Shouldn't reach here\r\n\r\n\r\n");
    CleanIFWI();
    return Status;
  } 
  
  CleanIFWI();
  Status = gBS->LocateProtocol (
             &gEfiSpiProtocolGuid,
             NULL,
             (VOID **)&mSpiProtocol
           );
  if(EFI_ERROR(Status)) {
    Print(L"AFU: Failed to locate SPI protocol\r\n");
    goto ErrorExit;
  }  
  
  if(SecEnabled == 0 || SecOvrEnabled == 1) {
    Print(L"Start to update firmware\r\n");
    Status = BIOSFlash((UINTN)FileSize, (UINT8*)(FileBuffer), SpiRegionType);   
    Print(L"Flash Update Complete Status %r. Ready to reset...\n", Status);
    if(FileBuffer != NULL) {
      FreePool(FileBuffer);
    }
    if(EFI_ERROR(Status)) {
   //
   //TODO: At this stage the recovery flow is not yet defined for AFU. 
   //
      
    }    
    gRT->ResetSystem(EfiResetCold, EFI_SUCCESS, 0, NULL);
    CpuDeadLoop();
  } else {      
    Print(L"\r\n\r\nWe should never reach here\r\n");
    gRT->ResetSystem(EfiResetCold, EFI_SUCCESS, 0, NULL);
    CpuDeadLoop();
    return Status;  //We never return;
  }
ErrorExit:
  if (FileBuffer != NULL) {
    FreePool(FileBuffer);
  }
  return Status;
 }


