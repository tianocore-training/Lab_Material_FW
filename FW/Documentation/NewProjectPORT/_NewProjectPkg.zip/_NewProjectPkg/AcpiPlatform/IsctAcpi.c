/*++
  This file contains an 'Intel Peripheral Driver' and uniquely  
  identified as "Intel Reference Module" and is                 
  licensed for Intel CPUs and chipsets under the terms of your  
  license agreement with Intel or your vendor.  This file may   
  be modified by the user, subject to additional terms of the   
  license agreement                                             
--*/

/*++

Copyright (c)  2013 Intel Corporation. All rights reserved
This software and associated documentation (if any) is furnished
under a license and may only be used or copied in accordance
with the terms of the license. Except as permitted by such
license, no part of this software or documentation may be
reproduced, stored in a retrieval system, or transmitted in any
form or by any means without the express written consent of
Intel Corporation.

Module Name:

  IsctAcpi.c

Abstract:

  This Dxe driver will initialize ISCT Persistent Data Variable and also verify ISCT Store valid or not


--*/
#include "AcpiPlatform.h"
#include "SetupMode.h"
#include <Guid/SetupVariable.h>
#include <Guid/IsctPersistentData.h>
#include <Guid/EventGroup.h>
#include <Guid/AcpiTableStorage.h>
#include <Guid/ReservedNvsAcpiTableStorage.h>
#include <Protocol/ReservedNvsArea.h>
#include <Protocol/IgdOpRegion.h>
#include <Protocol/AcpiTable.h>
#include <Protocol/FirmwareVolume.h>
#include <Protocol/AcpiSupport.h>

#include "AcpiPlatformHooks.h"

ISCT_NVS_AREA_PROTOCOL mIsctNvsAreaProtocol;


VOID
IsctOnReadyToBoot (
  IN EFI_EVENT  Event,
  IN VOID       *Context
  );

extern EFI_STATUS LocateSupportProtocol (
  IN   EFI_GUID       *Protocol,
  OUT  VOID           **Instance,
  IN   UINT32         Type
  );

STATIC
EFI_STATUS
InitializeIsctAcpiTables (
  VOID
  )
/*++

Routine Description:

  Initialize ISCT ACPI tables

Arguments:

Returns:

  EFI_SUCCESS    Isct ACPI tables are initialized successfully
  EFI_NOT_FOUND  Isct ACPI tables not found

--*/
{
  EFI_STATUS                    Status;
  EFI_HANDLE                    *HandleBuffer;
  UINTN                         NumberOfHandles;
  EFI_FV_FILETYPE               FileType;
  UINT32                        FvStatus;
  EFI_FV_FILE_ATTRIBUTES        Attributes;
  UINTN                         Size;
  UINTN                         Index;
  EFI_FIRMWARE_VOLUME_PROTOCOL  *FwVol;
  EFI_ACPI_SUPPORT_PROTOCOL     *AcpiSupport;
  INTN                          Instance;
  EFI_ACPI_COMMON_HEADER        *CurrentTable;
  UINT8                         *CurrPtr;
  UINT8                         *EndPtr;
  UINT32                        *Signature;
  EFI_ACPI_DESCRIPTION_HEADER   *IsctAcpiTable;
  BOOLEAN                       LoadTable;
  UINTN                         TableHandle;
  EFI_ACPI_TABLE_VERSION        Version;
  EFI_ACPI_TABLE_PROTOCOL       *AcpiTable;

  FwVol         = NULL;
  IsctAcpiTable = NULL;

  Status = gBS->LocateProtocol (&gEfiAcpiTableProtocolGuid, NULL, &AcpiTable);
  DEBUG((EFI_D_INFO, "ISCT :gBS->LocateProtocol -> AcpiTable Status = %x\n", Status));  
  ASSERT_EFI_ERROR (Status);

  //
  // Locate protocol.
  // There is little chance we can't find an FV protocol
  //
  Status = gBS->LocateHandleBuffer (
                  ByProtocol,
                  &gEfiFirmwareVolumeProtocolGuid,
                  NULL,
                  &NumberOfHandles,
                  &HandleBuffer
                  );
  DEBUG((EFI_D_INFO, "ISCT :gBS->LocateHandleBuffer Status = %x\n", Status));  
  ASSERT_EFI_ERROR (Status);
  //
  // Looking for FV with ACPI storage file
  //
  for (Index = 0; Index < NumberOfHandles; Index++) {
    //
    // Get the protocol on this handle
    // This should not fail because of LocateHandleBuffer
    //
    Status = gBS->HandleProtocol (
                    HandleBuffer[Index],
                    &gEfiFirmwareVolumeProtocolGuid,
                    &FwVol
                    );
    DEBUG((EFI_D_INFO, "ISCT :gBS->HandleProtocol Status = %x\n", Status));  
    ASSERT_EFI_ERROR (Status);

    //
    // See if it has the ACPI storage file
    //
    Size      = 0;
    FvStatus  = 0;
    Status = FwVol->ReadFile (
                      FwVol,
                      &gReservedNvsAcpiTableStorageGuid,
                      NULL,
                      &Size,
                      &FileType,
                      &Attributes,
                      &FvStatus
                      );
    DEBUG((EFI_D_INFO, "ISCT :FwVol->ReadFile Status = %x\n", Status));  
    //
    // If we found it, then we are done
    //
    if (Status == EFI_SUCCESS) {
      break;
    }
  }
  //
  // Free any allocated buffers
  //
  FreePool (HandleBuffer);

  //
  // Sanity check that we found our data file
  //
  ASSERT (FwVol != NULL);
  if (FwVol == NULL) {
    return EFI_NOT_FOUND;
  }
  //
  // By default, a table belongs in all ACPI table versions published.
  //
  Version = EFI_ACPI_TABLE_VERSION_1_0B | EFI_ACPI_TABLE_VERSION_2_0 | EFI_ACPI_TABLE_VERSION_3_0;

  //
  // Find the AcpiSupport protocol
  //
  Status = LocateSupportProtocol (
            &gEfiAcpiSupportProtocolGuid,
            &AcpiSupport,
            FALSE
            );
  DEBUG((EFI_D_INFO, "ISCT :LocateSupportProtocol Status = %x\n", Status));  
  ASSERT_EFI_ERROR (Status);


  //
  // Our exit status is determined by the success of the previous operations
  // If the protocol was found, Instance already points to it.
  // Read tables from the storage file.
  //
  Instance      = 0;
  CurrentTable  = NULL;
  while (Status == EFI_SUCCESS) {
    Status = FwVol->ReadSection (
                      FwVol,
                      &gReservedNvsAcpiTableStorageGuid,
                      EFI_SECTION_RAW,
                      Instance,
                      &CurrentTable,
                      &Size,
                      &FvStatus
                      );
    DEBUG((EFI_D_INFO, "ISCT :FwVol->ReadSection Status = %x\n", Status));
  
    if (!EFI_ERROR (Status)) {
      LoadTable = FALSE;
      //
      // Check the table ID to modify the table
      //
      if (((EFI_ACPI_DESCRIPTION_HEADER *) CurrentTable)->OemTableId == EFI_SIGNATURE_64 ('I', 's', 'c', 't', 'T', 'a', 'b', 'l')) {
        IsctAcpiTable = (EFI_ACPI_DESCRIPTION_HEADER *) CurrentTable;
	      DEBUG((EFI_D_ERROR, "ISCT :Find out IsctTabl\n"));  

		//
        // Locate the SSDT package
        //
        CurrPtr = (UINT8 *) IsctAcpiTable;
        EndPtr  = CurrPtr + IsctAcpiTable->Length;

        for (; CurrPtr <= EndPtr; CurrPtr++) {
          Signature = (UINT32 *) (CurrPtr + 3);
          if (*Signature == EFI_SIGNATURE_32 ('I', 'S', 'C', 'T')) {
            LoadTable = TRUE;
            if((*(UINT32 *) (CurrPtr + 3 + sizeof (*Signature) + 2) == 0xFFFF0008)) {
            //
            // ISCT NVS Area address
            //
            *(UINT32 *) (CurrPtr + 3 + sizeof (*Signature) + 2) = (UINT32) (UINTN) mIsctNvsAreaProtocol.Area;       
            DEBUG((EFI_D_INFO, "ISCT :Modify OpRegion Address to %x\n", (*(UINT32 *) (CurrPtr + 3 + sizeof (*Signature) + 2))));           
            }

            if((*(UINT16 *) (CurrPtr + 3 + sizeof (*Signature) + 2 + sizeof (UINT32) + 1) == 0xAA58)) {
            //
            // ISCT NVS Area size
            //
            *(UINT16 *) (CurrPtr + 3 + sizeof (*Signature) + 2 + sizeof (UINT32) + 1) = sizeof (EFI_RESERVED_NVS_AREA);
            DEBUG((EFI_D_INFO, "ISCT :Modify OpRegion Size to %x\n", *(UINT16 *) (CurrPtr + 3 + sizeof (*Signature) + 2 + sizeof (UINT32) + 1)));
            }
            //
            // Add the table
            //
            if (LoadTable) {
			TableHandle = 0;
			Status = AcpiTable->InstallAcpiTable (
                                  AcpiTable,
                                  CurrentTable,
                                  CurrentTable->Length,
                                  &TableHandle
                                  );
		    DEBUG((EFI_D_INFO, "ISCT :Successfully installed ISCT-ACPI Table Status = %x\n", Status));
			return EFI_SUCCESS;
            }  //if Loadtable
          }  // if signature
        }  // for signature
      }
      //
      // Increment the instance
      //
      Instance++;
      CurrentTable = NULL;
    }	
  }		// while

  Status = AcpiSupport->PublishTables (
                          AcpiSupport,
                          (EFI_ACPI_TABLE_VERSION_1_0B | EFI_ACPI_TABLE_VERSION_2_0 | EFI_ACPI_TABLE_VERSION_3_0)
                          );
  DEBUG((EFI_D_INFO, "ISCT :AcpiSupport-PublishTables Status = %x\n", Status));
  ASSERT_EFI_ERROR (Status);
  return Status;
}


VOID
IsctOnReadyToBoot (
  IN EFI_EVENT  Event,
  IN VOID       *Context
  )
/*++

Routine Description:

  Install Isct ACPI tables only when Isct is enabled

Arguments:

  Event    - The event that triggered this notification function  
  Context  - Pointer to the notification functions context

Returns:

  None

--*/
{
  EFI_STATUS  Status;
  IGD_OPREGION_PROTOCOL         *IgdOpRegionProtocol;

  DEBUG ((EFI_D_INFO, "IsctOnReadyToBoot()\n"));

  Status = InitializeIsctAcpiTables ();
  DEBUG((EFI_D_INFO, "Initializes ISCT SSDT tables Status = %x\n", Status));  

  gBS->CloseEvent (Event);

  //
  // Notify the Graphics Driver that Isct is enabled
  //
  Status = gBS->LocateProtocol (
                &gIgdOpRegionProtocolGuid,
                NULL,
                &IgdOpRegionProtocol
                );
  if (Status == EFI_SUCCESS) {
    IgdOpRegionProtocol->OpRegion->Header.PCON |= 0x60;
    DEBUG((EFI_D_INFO, "IsctOnReadyToBoot() PCON = 0x%x\n", IgdOpRegionProtocol->OpRegion->Header.PCON));
  } else {
    DEBUG ((EFI_D_ERROR, "IsctOnReadyToBoot() Unable to locate IgdOpRegionProtocol"));
  }
}

EFI_STATUS
EFIAPI
IsctDxeEntryPoint (
  IN EFI_HANDLE         ImageHandle,
  IN EFI_SYSTEM_TABLE   *SystemTable
  )
/*++

Routine Description:

  ISCT DXE driver entry point function

Arguments:

  ImageHandle - Image handle for this driver image
  SystemTable - Pointer to the EFI System Table

Returns:

  EFI_OUT_OF_RESOURCES - no enough memory resource when installing reference code information protocol
  EFI_SUCCESS          - function completed successfully

--*/  
{
  EFI_STATUS                    Status;
  EFI_EVENT	                    mIsctEvent;	
  EFI_RESERVED_NVS_AREA         *IsctNvs;
  ISCT_PERSISTENT_DATA          *mIsctData;
  UINT8                         IsctEnabled;
  UINTN                         VarSize;
  SYSTEM_CONFIGURATION          mSystemConfiguration;

  DEBUG ((EFI_D_INFO, "IsctDxe: Entry Point...\n"));

  VarSize = sizeof(SYSTEM_CONFIGURATION);
  Status = gRT->GetVariable(
    NORMAL_SETUP_NAME,
    &gEfiNormalSetupGuid,
    NULL,
    &VarSize,
    &mSystemConfiguration
  );

  DEBUG ((EFI_D_INFO, "ISCT: Get Variable Status = %x\n", Status));
  ASSERT_EFI_ERROR (Status);
  
  IsctEnabled = mSystemConfiguration.IsctConfiguration;

  if(IsctEnabled == 0) {
    DEBUG ((EFI_D_INFO, "ISCT is Disabled \n"));    
  }

  if (EFI_ERROR (Status)) {
    ASSERT_EFI_ERROR (Status);
    return Status;
  }


  // Allocate pools and initialize for ISCT Global NVS Area

  Status = gBS->AllocatePool (EfiReservedMemoryType, sizeof (EFI_RESERVED_NVS_AREA), &mIsctNvsAreaProtocol.Area);
  ASSERT_EFI_ERROR (Status);
  gBS->SetMem (mIsctNvsAreaProtocol.Area, sizeof (EFI_RESERVED_NVS_AREA), 0);
  DEBUG((EFI_D_ERROR, "mIsctNvsAreaProtocol.Area is at 0x%X\n", mIsctNvsAreaProtocol.Area));


  Status = gBS->AllocatePool (EfiReservedMemoryType, sizeof (ISCT_PERSISTENT_DATA), &mIsctNvsAreaProtocol.IsctData);
  ASSERT_EFI_ERROR (Status);
  gBS->SetMem (mIsctNvsAreaProtocol.IsctData, sizeof (ISCT_PERSISTENT_DATA), 0);
  DEBUG((EFI_D_ERROR, "mIsctNvsAreaProtocol.IsctData is at 0x%X\n", mIsctNvsAreaProtocol.IsctData));

  IsctNvs = mIsctNvsAreaProtocol.Area;

  IsctNvs->IsctNvsPtr = (UINT32) (UINTN) IsctNvs;

  IsctNvs->IsctEnabled = mSystemConfiguration.IsctConfiguration;	

  //
  // Assign IsctData pointer to GlobalNvsArea
  //
  mIsctData = mIsctNvsAreaProtocol.IsctData;  
  mIsctData->IsctNvsPtr = (UINT32) (UINTN) IsctNvs;

  //
  // Install ISCT Global NVS protocol
  //
  Status = gBS->InstallMultipleProtocolInterfaces (
                  &ImageHandle,
                  &gEfiReservedNvsAreaProtocolGuid,
                  &mIsctNvsAreaProtocol,
                  NULL
                  );
  DEBUG((EFI_D_INFO, "Install IsctNvsAreaProtocolGuid Status = 0x%x\n", Status));

  if (EFI_ERROR (Status)) {
    DEBUG ((EFI_D_ERROR, "Error to install ISCT_NVS_AREA_PROTOCOL"));
    ASSERT_EFI_ERROR (Status);
    return Status;
  }                  

  //
  // Save ISCT Data to Variable
  //
  Status = gRT->SetVariable (
                  ISCT_PERSISTENT_DATA_NAME,
                  &gIsctPersistentDataGuid,
                  EFI_VARIABLE_NON_VOLATILE | EFI_VARIABLE_BOOTSERVICE_ACCESS | EFI_VARIABLE_RUNTIME_ACCESS,
                  sizeof (ISCT_PERSISTENT_DATA),
                  mIsctData
                  );
  DEBUG((EFI_D_INFO, "ISCT DXE: Save ISCT Data to Variable Status = %x\n", Status)); 
  if (EFI_ERROR (Status)) {                   
    ASSERT_EFI_ERROR (Status);
    return Status;
  }   

    
  Status = gBS->CreateEventEx (
					  EVT_NOTIFY_SIGNAL,
					  TPL_NOTIFY,
					  IsctOnReadyToBoot,
					  NULL,
					  &gEfiEventReadyToBootGuid,
					  &mIsctEvent
					  );

  DEBUG((EFI_D_INFO, "Create ReadyToBoot event for ISCT Status = %x\n", Status));  
  if (EFI_ERROR (Status)) {                   
    ASSERT_EFI_ERROR (Status);
    return Status;
  }   

  DEBUG ((EFI_D_INFO, "(IsctDxe) entry End...\n"));
  
  return EFI_SUCCESS;
}