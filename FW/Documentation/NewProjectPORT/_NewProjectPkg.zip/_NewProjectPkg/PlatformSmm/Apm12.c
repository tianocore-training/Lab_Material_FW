/*++
  This file contains an 'Intel Peripheral Driver' and is        
  licensed for Intel CPUs and chipsets under the terms of your  
  license agreement with Intel or your vendor.  This file may   
  be modified by the user, subject to additional terms of the   
  license agreement                                             
--*/
/** @file

  Copyright (c) 2004 - 2014, Intel Corporation. All rights reserved.<BR>
  This software and associated documentation (if any) is furnished
  under a license and may only be used or copied in accordance
  with the terms of the license. Except as permitted by such
  license, no part of this software or documentation may be
  reproduced, stored in a retrieval system, or transmitted in any
  form or by any means without the express written consent of
  Intel Corporation.


Module Name:


    Apm12.c
    
Abstract:

    SMM APM handler Driver implementation file 

 

--*/ 

#include "SmmPlatform.h"


extern  EFI_SMM_SYSTEM_TABLE                    *mSmst;

//
// APM 1.2 State variables
//
extern  UINT8                                   mAPMInterfaceConnectState;
extern  BOOLEAN                                 mAPMEnabledState;
extern  BOOLEAN                                 mAPMEngagedState;


VOID
ApmInstallationCheck ()
/*++

Routine Description:
  This call allows the APM Driver (caller) to determine if the system's
  BIOS supports the APM functionality and if so, which version of the
  specification it supports.

Arguments:
      
  AH  =  53H  APM   
  AL  =  00H  Installation Check
  BX  =  Power device ID
    0000H  APM BIOS
    All other values reserved


Returns:
  Carry  =  0  APM is supported by BIOS
  AH  =  01  APM major version number (in BCD format)
  AL  =  02  APM minor version number (in BCD format)
  BH  =  ASCII "P" character
  BL  =  ASCII "M" character
  CX  =  APM flags
      bit 0 = 1 16-bit protected mode interface supported 
                (required in APM 1.2)
      bit 1 = 1  32-bit protected mode interface supported
                 (required in APM 1.2)
      bit 2 = 1 CPU Idle call slows processor clock speed.  This bit set
                indicates that the APM Driver must call the CPU Busy 
                function to ensure that the system is restored to normal
                processing clock speed after calling the CPU Idle
                function to slow the processor clock speed.
      bit 2 = 0 CPU Idle call does not slow the processor  clock speed
                or CPU Idle call stops the clock.  This bit clear
                indicates that the APM Driver does not 
      need to call the CPU Busy function.
      bit 3 = 1  APM BIOS Power Management disabled
      bit 4 = 1  APM BIOS Power Management disengaged
      Other bits  Reserved (must be set to 0)
  If function unsuccessful:
  Carry  =  1  
  AH  =  Error code
  09H  Unrecognized device ID
  86H  APM not present
Supported modes
  Real mode


--*/
{
  //If BX != 0x0000 then return error = APM_UNRECOGNIZED_DEVICE_ID
  if (((mSmst->CpuSaveState->Ia32SaveState.EBX) & 0x0000FFFF) != 0x0000) {
    (mSmst->CpuSaveState->Ia32SaveState.EAX) = (((mSmst->CpuSaveState->Ia32SaveState.EAX) & 0xFFFF00FF) | APM_UNRECOGNIZED_DEVICE_ID);
  return;
  }
  //return APM flags in CX
  (mSmst->CpuSaveState->Ia32SaveState.ECX) = (((mSmst->CpuSaveState->Ia32SaveState.ECX) & 0xFFFF0000) | APM_FLAG_16BIT_PROTECTED_SUPPORT | APM_FLAG_32BIT_PROTECTED_SUPPORT);
  if (mAPMEnabledState == FALSE) {
    (mSmst->CpuSaveState->Ia32SaveState.ECX) = ((mSmst->CpuSaveState->Ia32SaveState.ECX) | APM_FLAG_DISABLED);
  }
  if (mAPMEngagedState == FALSE) {
    (mSmst->CpuSaveState->Ia32SaveState.ECX) = ((mSmst->CpuSaveState->Ia32SaveState.ECX) | APM_FLAG_DISENGAGED);
  }
  return;
}

VOID
ApmRealModeInterfaceConnect ()
/*++

Routine Description:
  This call establishes the cooperative interface between the APM
  Driver (caller) and the APM BIOS.  The APM BIOS provides
  OEM-defined power management functionality before the interface
  is established.
  Once the interface is established, the APM BIOS and the APM Driver
  coordinate power management activities.  The APM BIOS rejects an
  interface connect request if any real or protected mode connection
  already exists.


Arguments:
  AH  =  53H  APM  
  AL  =  01H  Real mode interface connect
  BX  =  Power device ID
    0000H  APM BIOS
    All other values reserved
Returns:      
  If function successful:
  Carry  =  0
  If function unsuccessful:
  Carry  =  1
  AH  =  Error code
      02H  Real mode interface connection already established
      05H  16-bit protected mode interface already established
      07H  32-bit protected mode interface already established
      09H  Unrecognized device ID
      86H  APM not present
Supported modes
  Real mode

--*/
{
  //If BX != 0x0000 then return error = APM_UNRECOGNIZED_DEVICE_ID
  if (((mSmst->CpuSaveState->Ia32SaveState.EBX) & 0x0000FFFF) != 0x0000) {
    (mSmst->CpuSaveState->Ia32SaveState.EAX) = (((mSmst->CpuSaveState->Ia32SaveState.EAX) & 0xFFFF00FF) | APM_UNRECOGNIZED_DEVICE_ID);      
  return;
  }
  //If APM not connected return AH=0 for success else return error code
  if (mAPMInterfaceConnectState==APM_NOT_CONNECTED) {
    (mSmst->CpuSaveState->Ia32SaveState.EAX) = ((mSmst->CpuSaveState->Ia32SaveState.EAX) & 0xFFFF00FF);
  mAPMInterfaceConnectState=APM_REAL_MODE;
  } else {
  (mSmst->CpuSaveState->Ia32SaveState.EAX) = (((mSmst->CpuSaveState->Ia32SaveState.EAX) & 0xFFFF00FF) | mAPMInterfaceConnectState);      
  }
  return;
}

VOID
Apm16BitProtectedModeInterfaceConnect ()
/*++

Routine Description:
  This call initializes the 16-bit protected mode interface between the
  APM Driver (caller) and the APM BIOS.  This interface allows a
  protected mode caller to invoke the APM BIOS functions without
  first switching into real or virtual-86 mode.  This function must be
  invoked in real mode.

Arguments:          
  AH  =  53H  APM  
  AL  =  02H  Protected mode 16-bit interface connect
  BX  =  Power device ID
    0000H APM BIOS
    All other values reserved
Returns:          
  If function successful:
  Carry  =  0    
  AX  =  APM 16-bit code segment (real mode segment base address)
  BX  =  Offset of entry point into the APM BIOS
  CX  =  APM 16-bit data segment (real mode segment base address)
  SI  =  APM BIOS code segment length
  DI  =  APM BIOS data segment length
  If function unsuccessful:
  Carry  =  1    
  AH  =  Error code  
      02H  Real mode interface connection already established
      05H  16-bit protected mode interface connection already established
      06H  16-bit protected mode interface not supported
      07H  32-bit protected mode interface connection already established
      09H  Unrecognized device ID 
      86H  APM not present
Supported modes
  Real mode

--*/
{
  //If BX != 0x0000 then return error = APM_UNRECOGNIZED_DEVICE_ID
  if ((mSmst->CpuSaveState->Ia32SaveState.EBX & 0x0000FFFF) != 0x0000) {
    (mSmst->CpuSaveState->Ia32SaveState.EAX) = (((mSmst->CpuSaveState->Ia32SaveState.EAX) & 0xFFFF00FF) | APM_UNRECOGNIZED_DEVICE_ID);      
  return;
  }
  //If APM not connected return AH=0 for success else return error code
  if (mAPMInterfaceConnectState==APM_NOT_CONNECTED) {
  (mSmst->CpuSaveState->Ia32SaveState.EAX) = ((mSmst->CpuSaveState->Ia32SaveState.EAX) & 0xFFFF00FF);      
  mAPMInterfaceConnectState=APM_16BIT_PROTECTED;
  } else {
  (mSmst->CpuSaveState->Ia32SaveState.EAX) = (((mSmst->CpuSaveState->Ia32SaveState.EAX) & 0xFFFF00FF) | mAPMInterfaceConnectState);      
  }
  return;
}

VOID
Apm32BitProtectedModeInterfaceConnect ()
/*++

Routine Description:
  This call initializes the 32-bit protected mode interface between the
  APM Driver (caller) and the APM BIOS.  This interface allows a
  protected mode APM Driver to invoke the APM BIOS functions without
  the need to first switch into real or virtual-86 mode.  This function
  must be invoked in real mode.
Arguments:          
  AH  =  53H  APM  
  AL  =  03H  Protected mode 32-bit interface connect
  BX  =  Power device ID
      0000H  APM BIOS  
    All other values are reserved
Returns:          
  If function successful:
  Carry  =  0    
  AX  =  PM 32-bit code segment (real mode segment base address)
  EBX  =  Offset of the entry point into the APM BIOS
  CX  =  APM 16-bit code segment (real mode segment base address)
  DX  =  APM data segment (real mode segment base address)
  ESI  =  APM BIOS 32-bit code segment length (low word of ESI)
        APM BIOS 16-bit code segment length (high word of ESI)
  DI  =  APM BIOS data segment length
  If function unsuccessful:
  Carry  =  1    
  AH  =  Error code  
      02H  Real mode interface connection already established
      05H  16-bit protected mode interface connection already 
           established
      07H  32-bit protected mode interface connection already 
           established
      08H  32-bit protected mode interface not supported
      09H  Unrecognized device ID
      86H  APM not present
Supported modes
  Real mode
  
--*/
{
  //If BX != 0x0000 then return error = APM_UNRECOGNIZED_DEVICE_ID
  if (((mSmst->CpuSaveState->Ia32SaveState.EBX) & 0x0000FFFF) != 0x0000) {
    (mSmst->CpuSaveState->Ia32SaveState.EAX) = (((mSmst->CpuSaveState->Ia32SaveState.EAX) & 0xFFFF00FF) | APM_UNRECOGNIZED_DEVICE_ID);      
  return;
  }
  //If APM not connected return AH=0 for success else return error code
  if (mAPMInterfaceConnectState==APM_NOT_CONNECTED) {
  (mSmst->CpuSaveState->Ia32SaveState.EAX) = ((mSmst->CpuSaveState->Ia32SaveState.EAX) & 0xFFFF00FF);      
  mAPMInterfaceConnectState=APM_32BIT_PROTECTED;
  } else {
  (mSmst->CpuSaveState->Ia32SaveState.EAX) = (((mSmst->CpuSaveState->Ia32SaveState.EAX) & 0xFFFF00FF) | mAPMInterfaceConnectState);      
  }
  return;
}

VOID
ApmInterfaceDisconnect ()
/*++

Routine Description:
  This call breaks the cooperative connection between the APM BIOS and
  the APM Driver (caller), and returns control of the power management
  policy to the APM BIOS.  Power management parameter values
  (timer values, enable/disable settings, etc.) in effect at the time
  of the disconnect remain in effect.

Call With          
  AH  =  53H  APM  
  AL  =  04H  Interface disconnect
  BX  =  Power device ID
      0000H   APM BIOS
    All other values reserved
  
Returns          
  If function successful:
  Carry  =  0    
  If function unsuccessful:
  Carry  =  1    
  AH  =  Error code  
      03H  Interface not connected
      09H  Unrecognized device ID
Supported modes
  Real mode
  Protected mode (16-bit and 32-bit)

--*/
{
  //If BX != 0x0000 then return error = APM_UNRECOGNIZED_DEVICE_ID
  if (((mSmst->CpuSaveState->Ia32SaveState.EBX) & 0x0000FFFF) != 0) {
    (mSmst->CpuSaveState->Ia32SaveState.EAX) = (((mSmst->CpuSaveState->Ia32SaveState.EAX) & 0xFFFF00FF) | APM_UNRECOGNIZED_DEVICE_ID);      
  return;
  }
  //If APM not connected, return error code, else AH=0 for success
  if (mAPMInterfaceConnectState==APM_NOT_CONNECTED) {
  (mSmst->CpuSaveState->Ia32SaveState.EAX) = (((mSmst->CpuSaveState->Ia32SaveState.EAX) & 0xFFFF00FF) | mAPMInterfaceConnectState);      
  } else {
  (mSmst->CpuSaveState->Ia32SaveState.EAX) = ((mSmst->CpuSaveState->Ia32SaveState.EAX) & 0xFFFF00FF);
  mAPMInterfaceConnectState=APM_NOT_CONNECTED;
  }
  return;
}

VOID
ApmCpuIdle ()
/*++

Routine Description:
  The APM Driver uses this call to tell APM BIOS that the system is
  idle.  The APM BIOS suspends the system until the next system event
  (typically an interrupt) occurs.  This function allows the APM BIOS
  to take some implementation-specific power saving action, such as a
  CPU HLT instruction or stopping the CPU clock.
  When the APM Driver regains control from the APM BIOS idle routine,
  it should determine if there is any processing to be performed, and
  reissue the CPU Idle call if not.  If the APM Driver is a
  multitasking supervisor, it may be necessary for it to dispatch its
  applications, allowing them to check for activity that they should
  now perform.

Arguments:          
  AH  =  53H  APM  
  AL  =  05H  CPU Idle
Returns          
  If function successful:
  Carry  =  0    
  If function unsuccessful:
  Carry  =  1    
  AH  =  Error code  
      03H  Interface not connected
  0BH  Interface not engaged
Supported modes
  Real mode
  Protected mode (16-bit and 32-bit)

--*/
{
  //If APM not connected or engaged, return error code, else AH=0 for success
  if (mAPMInterfaceConnectState==APM_NOT_CONNECTED) {
    (mSmst->CpuSaveState->Ia32SaveState.EAX) = (((mSmst->CpuSaveState->Ia32SaveState.EAX) & 0xFFFF00FF) | mAPMInterfaceConnectState);      
  } else {
    if (mAPMEngagedState == FALSE) {
    (mSmst->CpuSaveState->Ia32SaveState.EAX) = (((mSmst->CpuSaveState->Ia32SaveState.EAX) & 0xFFFF00FF) | APM_FLAG_DISENGAGED);      
    } else {
    (mSmst->CpuSaveState->Ia32SaveState.EAX) = ((mSmst->CpuSaveState->Ia32SaveState.EAX) & 0xFFFF00FF);      
    }
  }
  return;
}

VOID
ApmCpuBusy ()
/*++

Routine Description:
  This call informs the APM BIOS that the APM Driver has determined
  that the system is now busy.  The APM BIOS restores the CPU clock
  rate to full speed.
  This routine need only be called if the CPU Idle function was
  previously called, resulting in slowing of the CPU clock rate.  To
  determine if an APM BIOS slows the clock rate during a CPU Idle call,
  check bit 2 of the CX register returned from the APM Installation
  Check call.
  Calling CPU Busy when the system is already operating at full speed is
  discouraged due to the unnecessary call overhead, but the operation is
  allowed and has no unexpected side effects.
Call With          
  AH  =  53H  APM  
  AL  =  06H  CPU Busy
Returns          
  If function successful:
  Carry  =  0    
  If function unsuccessful:
  Carry  =  1    
  AH  =  Error code  
      03H  Interface not connected
  0BH  Interface not engaged
Supported modes
  Real mode
  Protected mode (16-bit and 32-bit)

--*/
{
  //If APM not connected or engaged, return error code, else AH=0 for success
  if (mAPMInterfaceConnectState==APM_NOT_CONNECTED) {
    (mSmst->CpuSaveState->Ia32SaveState.EAX) = (((mSmst->CpuSaveState->Ia32SaveState.EAX) & 0xFFFF00FF) | mAPMInterfaceConnectState);      
  } else {
    if (mAPMEngagedState == FALSE) {
    (mSmst->CpuSaveState->Ia32SaveState.EAX) = (((mSmst->CpuSaveState->Ia32SaveState.EAX) & 0xFFFF00FF) | APM_FLAG_DISENGAGED);      
  } else {
    (mSmst->CpuSaveState->Ia32SaveState.EAX) = ((mSmst->CpuSaveState->Ia32SaveState.EAX) & 0xFFFF00FF);      
  }
  }
  return;
}

VOID
ApmSetPowerState (
  IN  EFI_HANDLE                    DispatchHandle
  )
/*++

Routine Description:
This call sets the system or device specified in the power device ID
into the requested power state.

Arguments:          
  AH  =  53H  APM  
  AL  =  07H  Set Power State
  BX  =  Power device ID  
    0001H  All devices power managed by the APM BIOS  
    01XXH  Display  
    02XXH  Secondary Storage  
    03XXH  Parallel Ports  
    04XXH  Serial Ports  
    05XXH Network Adapters  
    06XXH PCMCIA Sockets  
    E000H - EFFFH  OEM-defined Power Device IDs  
    All other values reserved  
          where:  
    XX H = Unit Number (0 based)  
    Unit Number of FF H means all devices in this class  
  CX  =  Power state  
      *0000H  APM Enabled  
      0001H  Standby  
      0002H  Suspend  
      0003H  Off  
      **0004H  Last Request Processing Notification  
      **0005H  Last Request Rejected  
      0006H-001FH  Reserved system states  
      0020H-003FH  OEM-defined system states  
      0040H-007FH  OEM-defined device states  
      0080H-FFFFH  Reserved device states  
      * Not supported for Power Device ID 0001H    
      ** Only supported for Power Device ID 0001H  
        
Returns:        
  If function successful:
  Carry  =  0  
  If function unsuccessful:
  Carry  =  1  
  AH  =  Error code
      01H  Power management functionality disabled
      03H  Interface not connected
      09H  Unrecognized device ID
      0AH  Parameter value out of range
  0BH  Interface not engaged
      60H  Unable to enter requested state
Supported modes:
  Real mode
  Protected mode (16-bit and 32-bit)

--*/
{
  //If BX != 0x0001 then return error = APM_UNRECOGNIZED_DEVICE_ID
  if (((mSmst->CpuSaveState->Ia32SaveState.EBX) & 0x0000FFFF) != 0x0001) {
  (mSmst->CpuSaveState->Ia32SaveState.EAX) = (((mSmst->CpuSaveState->Ia32SaveState.EAX) & 0xFFFF00FF) | APM_UNRECOGNIZED_DEVICE_ID);      
  return;
  }
  //If APM not connected, disabled or disengaged, return error code, else AH=0 for success
  if (mAPMInterfaceConnectState==APM_NOT_CONNECTED) {
    (mSmst->CpuSaveState->Ia32SaveState.EAX) = (((mSmst->CpuSaveState->Ia32SaveState.EAX) & 0xFFFF00FF) | mAPMInterfaceConnectState);      
  } else {
  if (mAPMEnabledState == FALSE) {
    (mSmst->CpuSaveState->Ia32SaveState.EAX) = (((mSmst->CpuSaveState->Ia32SaveState.EAX) & 0xFFFF00FF) | APM_FLAG_DISABLED);      
  } else {
    if (mAPMEngagedState == FALSE) {
    (mSmst->CpuSaveState->Ia32SaveState.EAX) = (((mSmst->CpuSaveState->Ia32SaveState.EAX) & 0xFFFF00FF) | APM_FLAG_DISENGAGED);      
    } else {
    if (((mSmst->CpuSaveState->Ia32SaveState.ECX) & 0x0000FFFF) == APM_SET_POWER_STATE_OFF) {
          PowerButtonCallback(DispatchHandle,0);
      (mSmst->CpuSaveState->Ia32SaveState.EAX) = ((mSmst->CpuSaveState->Ia32SaveState.EAX) & 0xFFFF00FF);
    } else {
      (mSmst->CpuSaveState->Ia32SaveState.EAX) = (((mSmst->CpuSaveState->Ia32SaveState.EAX) & 0xFFFF00FF) | 0x60);
    }
    }
  }
  }
  return;
}

VOID
ApmEnableDisablePowerManagement ()
/*++

Routine Description:
  This call enables or disables all APM BIOS automatic power management.
  When disabled, the APM BIOS does not automatically power manage
  devices, enter the Standby State, enter the Suspend State, or take
  power saving steps in response to CPU Idle calls. 

Arguments:          
  AH  =  53H  APM  
  AL  =  08H  Enable/disable power management
  BX  =  Power device ID  
    0001H  All devices power managed by the APM BIOS  
    *FFFFH  All devices power managed by the APM BIOS  
    All other values reserved  
    * Must be implemented for compatibility with APM 1.0  
  CX  =  Function code
    0000H  Disable power management  
    0001H  Enable power management  

Returns          
  If function successful:
  Carry  =  0    
  If function unsuccessful:
  Carry  =  1    
  AH  =  Error code  
      
      03H  Interface not connected
      09H  Unrecognized device ID
      0AH  Parameter value out or range (function code)
      0BH  Interface not engaged
Supported modes:
  Real mode
  Protected mode (16-bit and 32-bit)

--*/
{
  //If BX != 0 then return error = APM_UNRECOGNIZED_DEVICE_ID
  if ((((mSmst->CpuSaveState->Ia32SaveState.EBX) & 0x0000FFFF) != 0x0001) || (((mSmst->CpuSaveState->Ia32SaveState.EBX) & 0x0000FFFF) != 0xFFFF)) {
  (mSmst->CpuSaveState->Ia32SaveState.EAX) = (((mSmst->CpuSaveState->Ia32SaveState.EAX) & 0xFFFF00FF) | APM_UNRECOGNIZED_DEVICE_ID);      
  return;
  }
  //If APM not connected, or disengaged and APM driver attempts to Disable, return error code, else AH=0 for success
  if (mAPMInterfaceConnectState==APM_NOT_CONNECTED) {
    (mSmst->CpuSaveState->Ia32SaveState.EAX) = (((mSmst->CpuSaveState->Ia32SaveState.EAX) & 0xFFFF00FF) | mAPMInterfaceConnectState);      
  } else {
  //If APM is currently Disengaged and APM driver trying to Disable return error code
    if ((mAPMEngagedState == FALSE) && (((mSmst->CpuSaveState->Ia32SaveState.ECX) & 0x0000FFFF) == 0x0000)){
    (mSmst->CpuSaveState->Ia32SaveState.EAX) = (((mSmst->CpuSaveState->Ia32SaveState.EAX) & 0xFFFF00FF) | APM_FLAG_DISENGAGED);      
  } else {
    //else set AH=0 for success and set mAPMEnabledState appropriately
    (mSmst->CpuSaveState->Ia32SaveState.EAX) = ((mSmst->CpuSaveState->Ia32SaveState.EAX) & 0xFFFF00FF);
    if (((mSmst->CpuSaveState->Ia32SaveState.ECX) & 0x0000FFFF) == 0x0000) {
      mAPMEnabledState= FALSE;
    } else {
      mAPMEnabledState= TRUE;
    }
    }
  }
  return;
}

VOID
ApmRestoreApmBiosPowerOnDefaults ()
/*++

Routine Description:
  This call reinitializes all power-on defaults.

Call With        
  AH  =  53H  APM
  AL  =  09H  Restore Power-On Defaults
  BX  =  Power device ID
      0001H   All devices power managed by the APM BIOS
      *FFFFH  All devices power managed by the APM BIOS
      All other values reserved
      * Must be implemented for compatibility with APM 1.0
Returns:        
  If function successful:
  Carry  =  0  
  If function unsuccessful:
  Carry  =  1  
  AH  =  Error code
      03H  Interface not connected
      09H  Unrecognized device ID
  0BH  Interface not engaged
Supported modes:
  Real mode
  Protected mode (16-bit and 32-bit)
  
--*/
{
  //If BX != 0x0001 or 0XFFFF then return error = APM_UNRECOGNIZED_DEVICE_ID
  if ((((mSmst->CpuSaveState->Ia32SaveState.EBX) & 0x0000FFFF) != 0x0001) || (((mSmst->CpuSaveState->Ia32SaveState.EBX) & 0x0000FFFF) != 0xFFFF)) {
  (mSmst->CpuSaveState->Ia32SaveState.EAX) = (((mSmst->CpuSaveState->Ia32SaveState.EAX) & 0xFFFF00FF) | APM_UNRECOGNIZED_DEVICE_ID);      
  return;
  }
  //If APM not connected, or disengaged, return error code, else AH=0 for success
  if (mAPMInterfaceConnectState==APM_NOT_CONNECTED) {
    (mSmst->CpuSaveState->Ia32SaveState.EAX) = (((mSmst->CpuSaveState->Ia32SaveState.EAX) & 0xFFFF00FF) | mAPMInterfaceConnectState);      
  } else {
    if (mAPMEngagedState == FALSE) {
    (mSmst->CpuSaveState->Ia32SaveState.EAX) = (((mSmst->CpuSaveState->Ia32SaveState.EAX) & 0xFFFF00FF) | APM_FLAG_DISENGAGED);      
  } else {
    (mSmst->CpuSaveState->Ia32SaveState.EAX) = ((mSmst->CpuSaveState->Ia32SaveState.EAX) & 0xFFFF00FF);
    }
  }
  return;
}

VOID
ApmGetPowerStatus ()
/*++

Routine Description:
  This call returns the system current power status.

Arguments:        
  AH  =  53H  APM
  AL  =  0AH  Get Power Status
  BX  =  Power device ID
        0001H  APM BIOS, or
        80XXH  Specific Battery Unit Number
        where:
          XX = Battery Unit Number (1 based)
          All other values reserved
Returns:      
  If function successful:
  Carry  =  0
  BH  =  AC line status
      00H  Off-line
      01H  On-line
      02H  On backup power
      FFH = Unknown
      All other values reserved
  BL  =  Battery status
      00H  High
      01H  Low
      02H  Critical
      03H  Charging
      FFH = Unknown
      All other values reserved
  CH  =  Battery flag
      bit 0 = 1  High
      bit 1 = 1  Low
      bit 2 = 1  Critical
      bit 3 = 1  Charging
      bit 4 = 1  Selected battery not present
      bit 7 = 1  No system battery
      All other bits reserved (must be set to 0)
        FFH = Unknown
        All other values reserved
  CL  =  Remaining battery life - percentage of charge
      0-100 = Percentage of full charge
      FFH = Unknown
      All other values reserved
  DX  =  Remaining battery life - time units
      Bit 15 = 0  Time units are seconds
                     1  Time units are minutes
      Bits 14-0  = Number of seconds or minutes 
               0-7FFFH  Valid number of seconds
               0-7FFEH  Valid number of minutes
      FFFFH = Unknown
  If BH (Power Device ID/Device Class) = 80H on entry, then return:
  SI  =  Number of battery units currently installed in the machine (0 to n). Must be <= the maximum number of battery units supported by this machine (returned in BX by the Get Capabilities function.)  There is no "unknown" return value for this parameter. 
  If function unsuccessful:
  Carry  =  1
  AH  =  Error code
      09H  Unrecognized device ID
      0AH  Parameter value out of range
      86H  APM not present

Supported modes:
  Real mode
  Protected mode (16-bit and 32-bit)

--*/
{
  //If BX != 0x0001 or 0XFFFF then return error = APM_UNRECOGNIZED_DEVICE_ID
  if ((((mSmst->CpuSaveState->Ia32SaveState.EBX) & 0x0000FFFF) != 0x0001) || (((mSmst->CpuSaveState->Ia32SaveState.EBX) & 0x0000FF00) != 0x8000)) {
    (mSmst->CpuSaveState->Ia32SaveState.EAX) = (((mSmst->CpuSaveState->Ia32SaveState.EAX) & 0xFFFF00FF) | APM_UNRECOGNIZED_DEVICE_ID);      
    return;
  }
  //If APM not connected, or disengaged, return error code, else AH=0 for success
  if (mAPMInterfaceConnectState==APM_NOT_CONNECTED) {
    (mSmst->CpuSaveState->Ia32SaveState.EAX) = (((mSmst->CpuSaveState->Ia32SaveState.EAX) & 0xFFFF00FF) | mAPMInterfaceConnectState);      
  } else {
    if (mAPMEngagedState == FALSE) {
    (mSmst->CpuSaveState->Ia32SaveState.EAX) = (((mSmst->CpuSaveState->Ia32SaveState.EAX) & 0xFFFF00FF) | APM_FLAG_DISENGAGED);      
    } else {
    (mSmst->CpuSaveState->Ia32SaveState.EAX) = ((mSmst->CpuSaveState->Ia32SaveState.EAX) & 0xFFFF00FF);
    // If BH(Power Device ID/Device Class) = 80h then return Number of battery units installed = 0 else return UNKNOWN statuses
    if (((mSmst->CpuSaveState->Ia32SaveState.EBX) & 0x0000FF00) == 0x8000) {
      (mSmst->CpuSaveState->Ia32SaveState.ESI) = ((mSmst->CpuSaveState->Ia32SaveState.ESI) & 0xFFFF0000);
    } else {
      (mSmst->CpuSaveState->Ia32SaveState.EBX) = (((mSmst->CpuSaveState->Ia32SaveState.EBX) & 0xFFFF0000) | APM_AC_LINE_STATUS_UNKNOWN | APM_BATTERY_STATUS_UNKNOWN);      
      (mSmst->CpuSaveState->Ia32SaveState.ECX) = (((mSmst->CpuSaveState->Ia32SaveState.ECX) & 0xFFFF0000) | APM_BATTERY_FLAG_UNKNOWN | APM_BATTERY_LIFE_PERCENTAGE_UNKNOWN);      
      (mSmst->CpuSaveState->Ia32SaveState.EDX) = (((mSmst->CpuSaveState->Ia32SaveState.EDX) & 0xFFFF0000) | APM_BATTERY_LIFE_TIME_UNITS_UNKNOWN);      
    }
    }
  }
  return;
}

VOID
ApmGetPmEvent ()
/*++

Routine Description:
  Get PM Event returns the next pending PM event, or indicates if no PM
  events are pending.  This function should be called until there are
  no more pending PM events, that is, an error is returned.  Then, the
  APM Driver will poll for new events at least once per second.
  Events apply to the APM System or to a device.

Arguments:          
  AH  =  53H  APM  
  AL  =  0BH  Get PM Event
Returns:          
  If function successful:
  Carry  =  0    
  BX  =  PM event code
  CX  =  PM event information
When BX = 0003H or 0004H (Normal Resume System Notification or Critical Resume System Notification):
Bit 0 = 0   PCMCIA socket was powered on in the Suspend state
Bit 0 = 1   PCMCIA socket was powered off in the Suspend state 
All other bits reserved (must be set to 0)
  If function unsuccessful:
  Carry  =  1    
  AH  =  Error code  
      03H  Interface not connected
  0BH  Interface not engaged
      80H  No power management events pending
Supported modes:
  Real mode
  Protected mode (16-bit and 32-bit)

--*/
{
  //If APM not connected, or disengaged, return error code, else AH=APM_NO_POWER_MANAGEMENT_EVENTS_PENDING
  if (mAPMInterfaceConnectState==APM_NOT_CONNECTED) {
    (mSmst->CpuSaveState->Ia32SaveState.EAX) = (((mSmst->CpuSaveState->Ia32SaveState.EAX) & 0xFFFF00FF) | mAPMInterfaceConnectState);      
  } else {
    if (mAPMEngagedState == FALSE) {
      (mSmst->CpuSaveState->Ia32SaveState.EAX) = (((mSmst->CpuSaveState->Ia32SaveState.EAX) & 0xFFFF00FF) | APM_FLAG_DISENGAGED);      
  } else {
    (mSmst->CpuSaveState->Ia32SaveState.EAX) = (((mSmst->CpuSaveState->Ia32SaveState.EAX) & 0xFFFF00FF) | APM_NO_POWER_MANAGEMENT_EVENTS_PENDING);      
  }
  }
  return;
}

VOID
ApmGetPowerState ()
/*++

Routine Description:
This call returns the device power state when a specific device ID is
used.  The power state value returned when the Power device ID
specified indicates "all devices power managed by the APM BIOS" or
"all devices in a class" is defined only when that Power device ID has
been used in a call to Set Power State.  In the case where the Power
device ID (class value) has not been used in a call to Set Power State,
the function will be unsuccessful, and will return error code 9
(Unrecognized device ID).

Arguments:
  AH  =  53H  APM  
  AL  =  0CH  Get Power State
  BX  =  Power device ID
    0001H  All devices power managed by the APM BIOS  
    01XXH  Display  
    02XXH  Secondary Storage  
    03XXH  Parallel Ports  
    04XXH  Serial Ports  
    05XXH Network Adapters  
    06XXH PCMCIA Sockets  
    E000H - EFFFH  OEM-defined Power Device IDs  
    All other values reserved  
          where:  
    XX H = Unit Number (0 based)  
    Unit Number of FF H means all devices in this class.
  
Returns:        
  If function successful:
  Carry  =  0  
  CX  =  Power state  
      0000H  APM Enabled
      0001H  Standby
      0002H  Suspend
      0003H  Off
      0004H-001FH  Reserved system states
      0020H-003FH  OEM-defined system states
      0040H-007FH  OEM-defined device states
      0080H-FFFFH  Reserved device states
  If function unsuccessful:
  Carry  =  1  
  AH  =  Error code  
      01H  Power management functionality disabled
      09H  Unrecognized device ID
  86H  APM not present

Supported modes:
  Real mode
  Protected mode (16-bit and 32-bit)

--*/
{
  //If BX != 0x0001 then return error = APM_UNRECOGNIZED_DEVICE_ID
  if (((mSmst->CpuSaveState->Ia32SaveState.EBX) & 0x0000FFFF) != 0x0001) {
  (mSmst->CpuSaveState->Ia32SaveState.EAX) = (((mSmst->CpuSaveState->Ia32SaveState.EAX) & 0xFFFF00FF) | APM_UNRECOGNIZED_DEVICE_ID);      
  return;
  }
  //If APM disabled, return error code, else AH=0 for success and CX=0 for APM Enabled
  if (mAPMEnabledState == FALSE) {
    (mSmst->CpuSaveState->Ia32SaveState.EAX) = (((mSmst->CpuSaveState->Ia32SaveState.EAX) & 0xFFFF00FF) | APM_FLAG_DISABLED);      
  } else {
    (mSmst->CpuSaveState->Ia32SaveState.EAX) = ((mSmst->CpuSaveState->Ia32SaveState.EAX) & 0xFFFF00FF);
    (mSmst->CpuSaveState->Ia32SaveState.ECX) = ((mSmst->CpuSaveState->Ia32SaveState.ECX) & 0xFFFF0000);
  }
  return;
}

VOID
ApmEnableDisableDevicePowerManagement ()
/*++

Routine Description:
  This call enables or disables APM BIOS automatic power management for
  a specified device.  When disabled, the APM BIOS does not
  automatically power manage the device.
  Upon system reset, any supported device's enabled/disabled status
  should initially be enabled.  These devices can also be returned to
  their initial states by using the Restore APM BIOS Power-On Defaults
  function.

Call With          
  AH  =  53H  APM  
  AL  =  0DH  Enable/disable device power management
  BX  =  Power device ID  
    0001H  All devices power managed by the APM BIOS  
    01XXH  Display  
    02XXH  Secondary Storage  
    03XXH  Parallel Ports  
    04XXH  Serial Ports  
    05XXH Network Adapters  
    06XXH PCMCIA Sockets  
    E000H - EFFFH  OEM-defined Power Device IDs  
    All other values reserved  
          where:  
    XX H = Unit Number (0 based)  
    Unit Number of FF H means all devices in this class.
  
  CX  =  Function code
    0000H  Disable power management  
    0001H  Enable power management  
Returns:          
  If function successful:
  Carry  =  0    
  If function unsuccessful:
  Carry  =  1    
  AH  =  Error code  
      01H  Power management functionality disabled
      03H  Interface not connected
      09H  Unrecognized device ID
      0AH  Parameter value out or range (function code)
0BH  Interface not engaged
Supported modes:
  Real mode
  Protected mode (16-bit and 32-bit)

--*/
{
  //If BX != 0x0001 then return error = APM_UNRECOGNIZED_DEVICE_ID
  if (((mSmst->CpuSaveState->Ia32SaveState.EBX) & 0x0000FFFF) != 0x0001) {
  (mSmst->CpuSaveState->Ia32SaveState.EAX) = (((mSmst->CpuSaveState->Ia32SaveState.EAX) & 0xFFFF00FF) | APM_UNRECOGNIZED_DEVICE_ID);      
  return;
  }
  //If APM not connected, disabled or disengaged, return error code, else AH=0 for success
  if (mAPMInterfaceConnectState==APM_NOT_CONNECTED) {
    (mSmst->CpuSaveState->Ia32SaveState.EAX) = (((mSmst->CpuSaveState->Ia32SaveState.EAX) & 0xFFFF00FF) | mAPMInterfaceConnectState);      
  } else {
  if (mAPMEnabledState == FALSE) {
    (mSmst->CpuSaveState->Ia32SaveState.EAX) = (((mSmst->CpuSaveState->Ia32SaveState.EAX) & 0xFFFF00FF) | APM_FLAG_DISABLED);      
  } else {
    if (mAPMEngagedState == FALSE) {
    (mSmst->CpuSaveState->Ia32SaveState.EAX) = (((mSmst->CpuSaveState->Ia32SaveState.EAX) & 0xFFFF00FF) | APM_FLAG_DISENGAGED);      
    } else {
    (mSmst->CpuSaveState->Ia32SaveState.EAX) = ((mSmst->CpuSaveState->Ia32SaveState.EAX) & 0xFFFF00FF);
    }
  }
  }
  return;
}

VOID
ApmDriverVersion ()
/*++

Routine Description:
  The APM Driver uses this call to indicate its level of APM support to
  the APM BIOS.  The APM BIOS returns the APM connection version number.

Arguments:          
  AH  =  53H  APM   
  AL  =  0EH  APM Driver Version  
  BX  =  0000H  APM BIOS  

  CH  =  APM Driver major version number (in BCD format)  

  CL  =  APM Driver minor version number (in BCD format)  
Returns:  
  If function successful:
  Carry  =  0  
  AH  =  APM Connection major version number (in BCD format)
  AL  =  APM Connection minor version number (in BCD format)
  If function unsuccessful:
  Carry  =  1  
  AH  =  Error code
        03H  Interface not connected
        09H  Unrecognized device ID
        0BH  Interface not engaged
Supported modes:
  Real mode
  Protected mode (16-bit and 32-bit)

Arguments:

Returns:

--*/
{
  //If BX != 0x0000 then return error = APM_UNRECOGNIZED_DEVICE_ID
  if (((mSmst->CpuSaveState->Ia32SaveState.EBX) & 0x0000FFFF) != 0x0000) {
  (mSmst->CpuSaveState->Ia32SaveState.EAX) = (((mSmst->CpuSaveState->Ia32SaveState.EAX) & 0xFFFF00FF) | APM_UNRECOGNIZED_DEVICE_ID);      
  return;
  }
  //If APM not connected or engaged, return error code, else AH=0 for success
  if (mAPMInterfaceConnectState==APM_NOT_CONNECTED) {
    (mSmst->CpuSaveState->Ia32SaveState.EAX) = (((mSmst->CpuSaveState->Ia32SaveState.EAX) & 0xFFFF00FF) | mAPMInterfaceConnectState);      
  } else {
    if (mAPMEngagedState == FALSE) {
    (mSmst->CpuSaveState->Ia32SaveState.EAX) = (((mSmst->CpuSaveState->Ia32SaveState.EAX) & 0xFFFF00FF) | APM_FLAG_DISENGAGED);      
    } else {
    (mSmst->CpuSaveState->Ia32SaveState.EAX) = ((mSmst->CpuSaveState->Ia32SaveState.EAX) & 0xFFFF00FF);      
    }
  }
  return;
}

VOID
ApmEngageDisengagePowerManagement ()
/*++

Routine Description:
  This call engages or disengages cooperative power management of the
  system or device.  When disengaged, the APM BIOS automatically power
  manages the system or device. 
  Any supported device's engaged/disengaged status should initially be
  set to disengaged upon system reset, or by using the Restore APM BIOS
  Power-On Defaults function.  The system as a whole should be engaged.

Call With          
  AH  =  53H  APM  
  AL  =  0FH  Engage/disengage power management
  BX  =  Power device ID  
    0001H  All devices power managed by the APM BIOS  
    01XXH  Display  
    02XXH  Secondary Storage  
    03XXH  Parallel Ports  
    04XXH  Serial Ports  
    05XXH Network Adapters  
    06XXH PCMCIA Sockets  
    E000H - EFFFH  OEM-defined Power Device IDs  
    All other values reserved  
          where:  
    XX H = Unit Number (0 based)  
    Unit Number of FF H means all devices in this class.  
  CX  =  Function code
    0000H  Disengage power management  
    0001H  Engage power management  

Returns:          
  If function successful:
  Carry  =  0    
  If function unsuccessful:
  Carry  =  1    
  AH  =  Error code  
      01H  Power management functionality disabled
      03H  Interface not connected
      09H  Unrecognized device ID
      0AH  Parameter value out or range (function code)
Supported modes:
  Real mode
  Protected mode (16-bit and 32-bit)

--*/
{
  //If BX != 0x0001 then return error = APM_UNRECOGNIZED_DEVICE_ID
  if (((mSmst->CpuSaveState->Ia32SaveState.EBX) & 0x0000FFFF) != 0x0001) {
  (mSmst->CpuSaveState->Ia32SaveState.EAX) = (((mSmst->CpuSaveState->Ia32SaveState.EAX) & 0xFFFF00FF) | APM_UNRECOGNIZED_DEVICE_ID);      
  return;
  }
  //If APM not connected or APM is currently Disabled and APM driver trying to Disengage,
  // return error code, else AH=0 for success
  if (mAPMInterfaceConnectState==APM_NOT_CONNECTED) {
    (mSmst->CpuSaveState->Ia32SaveState.EAX) = (((mSmst->CpuSaveState->Ia32SaveState.EAX) & 0xFFFF00FF) | mAPMInterfaceConnectState);      
  } else {
  //If APM is currently Disabled and APM driver trying to Disengage return error code
    if ((mAPMEnabledState == FALSE) && (((mSmst->CpuSaveState->Ia32SaveState.ECX) & 0x0000FFFF) == 0x0000)){
    (mSmst->CpuSaveState->Ia32SaveState.EAX) = (((mSmst->CpuSaveState->Ia32SaveState.EAX) & 0xFFFF00FF) | APM_FLAG_DISABLED);      
  } else {
    //else return AH=0 for success and set mAPMEngagedState appropriately
    (mSmst->CpuSaveState->Ia32SaveState.EAX) = ((mSmst->CpuSaveState->Ia32SaveState.EAX) & 0xFFFF00FF);
    if (((mSmst->CpuSaveState->Ia32SaveState.ECX) & 0x0000FFFF) == 0x0000) {
      mAPMEngagedState= FALSE;
    } else {
      mAPMEngagedState= TRUE;
    }
    }
  }
  return;
}

VOID
ApmGetCapabilities ()
/*++

Routine Description:
This call returns the features which this particular APM 1.2 BIOS
implementation supports.

Arguments:          
  AH  =  53H  APM   
  AL  =  10H  Get Capabilities  
  BX  =  Power device ID  
      0000H  APM BIOS  
      All other values reserved  
Returns:  
  If function successful:
  Carry  =  0  APM is supported by BIOS
  BL  =  Number of battery units this machine supports. A value of 0 indicates this machine does not have any system batteries.  Most systems will return 0, 1, or 2.
  CX  =  Capability flags
      Bit 0 = 1  System can enter global standby state. Indicates BIOS will post standby and standby-resume events.
      Bit 1 = 1  System can enter global suspend state. Indicates BIOS will post suspend and suspend-resume events.
      Bit 2 = 1  Resume timer will wake up from standby.
      Bit 3 = 1  Resume timer will wake up from suspend.
      Bit 4 = 1  Resume on ring indicator (internal COM or modem) will wake up from standby.
      Bit 5 = 1  Resume on ring indicator (internal COM or modem) will wake up from suspend.
      Bit 6 = 1  PCMCIA Ring indicator will wake up from standby.
      Bit 7 = 1  PCMCIA Ring indicator will wake up from suspend.
      Other bits  Reserved (must be set to 0)
  If function unsuccessful:
  Carry  =  1  
  AH  =  Error code
        09H  Unrecognized device ID
        86H  APM not present
Supported modes:
  Real mode
  Protected mode (16-bit and 32-bit)
Comments

--*/
{
  //If BX != 0x0000 then return error = APM_UNRECOGNIZED_DEVICE_ID  else return AH=0 for successful and
  //CX=0 for compatability flags
  if (((mSmst->CpuSaveState->Ia32SaveState.EBX) & 0x0000FFFF) != 0x0000) {
  (mSmst->CpuSaveState->Ia32SaveState.EAX) = (((mSmst->CpuSaveState->Ia32SaveState.EAX) & 0xFFFF00FF) | APM_UNRECOGNIZED_DEVICE_ID);      
  } else {
    (mSmst->CpuSaveState->Ia32SaveState.EAX) = ((mSmst->CpuSaveState->Ia32SaveState.EAX) & 0xFFFF00FF);
  (mSmst->CpuSaveState->Ia32SaveState.ECX) = ((mSmst->CpuSaveState->Ia32SaveState.ECX) & 0xFFFF0000);
  }
  return;
}

VOID
ApmGetSetDisableResumeTimer ()
/*++

Routine Description:
  This call gets, sets, or disables the system resume timer.

Arguments:        
  AH  =  53H  
  AL  =  11H
  BX  =  Power device ID
          0000H APM BIOS
          All other values reserved  
  CL  =  Function code
          00H  Disable Resume Timer
          01H  Get Resume Timer
          02H  Set Resume Timer
  If CL = 02H:  (Set resume timer values)  
  CH  =  Seconds (0 to 59) (in BCD format)
  DH  =  Hours (0 to 23) (in BCD format)
  DL  =  Minutes (0 to 59) (in BCD format)
  SI  =  Month (high byte, 1 to 12  in BCD), Day (low byte, 1 to 31 in BCD)
  DI  =  Year (1995 to ... in BCD format)
      
Returns:      
  If function successful:
  Carry  =  0
  if CL = 01H  (Get resume timer values)  
  CH  =  Seconds (0 to 59) (in BCD format)
  DH  =  Hours (0 to 23) (in BCD format)
  DL  =  Minutes (0 to 59) (in BCD format)
  SI  =  Month (high byte, 1 to 12 in BCD), Day (low byte, 1 to 31 in BCD)
  DI  =  Year (1995 to ... in BCD format)
  If function unsuccessful:
  Carry  =  1
  AH  =  Error code
      03H  Interface not connected
      09H  Unrecognized device ID
      0AH  Parameter value out of range
0BH  Interface not engaged
0CH  Function not supported
0DH  Resume timer disabled (valid for get resume timer value only)
      
Supported modes
  Real mode
  Protected mode (16-bit and 32-bit)

--*/
{
  //If BX != 0x0000 then return error = APM_UNRECOGNIZED_DEVICE_ID  else return AH=0x0C for not supported
  if (((mSmst->CpuSaveState->Ia32SaveState.EBX) & 0x0000FFFF) != 0x0000) {
    (mSmst->CpuSaveState->Ia32SaveState.EAX) = (((mSmst->CpuSaveState->Ia32SaveState.EAX) & 0xFFFF00FF) | APM_UNRECOGNIZED_DEVICE_ID);      
  } else {
    (mSmst->CpuSaveState->Ia32SaveState.EAX) = (((mSmst->CpuSaveState->Ia32SaveState.EAX) & 0xFFFF00FF) | APM_FUNCTION_NOT_SUPPORTED);      
  }
  return;
}

VOID
ApmEnableDisableResumeOnRingIndicator ()
/*++

Routine Description:
  This call enables or disables the system's resume on ring indicator
  functionality.

Arguments:      
  AH  =  53H  APM
  AL  =  12H  Enable/Disable Resume on Ring Indicator
  BX  =  Power device ID
          0000H APM BIOS
          All other values reserved  
  CX  =  Function code
          0000H  Disable Resume on Ring Indicator
          0001H  Enable Resume on Ring Indicator
          0002H  Get Enabled/Disabled status
          All other values are reserved
      
Returns:      
  If function successful:
  Carry  =  0
  CX  =  Enabled/Disabled status
      0000H Disabled
      0001H Enabled
  If function unsuccessful:
  Carry  =  1
  AH  =  Error code
      03H  Interface not connected
      09H  Unrecognized device ID
      0AH  Parameter value out of range
      0BH  Interface not engaged
      0CH  Function not supported 
Supported modes
  Real mode
  Protected mode (16-bit and 32-bit)

--*/
{
  //If BX != 0x0000 then return error = APM_UNRECOGNIZED_DEVICE_ID  else return error = APM_FUNCTION_NOT_SUPPORTED
  if (((mSmst->CpuSaveState->Ia32SaveState.EBX) & 0x0000FFFF) != 0x0000) {
    (mSmst->CpuSaveState->Ia32SaveState.EAX) = (((mSmst->CpuSaveState->Ia32SaveState.EAX) & 0xFFFF00FF) | APM_UNRECOGNIZED_DEVICE_ID);      
  } else {
    (mSmst->CpuSaveState->Ia32SaveState.EAX) = (((mSmst->CpuSaveState->Ia32SaveState.EAX) & 0xFFFF00FF) | APM_FUNCTION_NOT_SUPPORTED);      
  }
  return;
}

VOID
ApmEnableDisableTimerBasedRequests ()
/*++

Routine Description:
  This call enables or disables the APM BIOS's generation of global
  Standby and global Suspend requests based on inactivity timers.

Call With        
  AH  =  53H  APM
  AL  =  13H  Enable/Disable Timer Based Requests
  BX  =  Power device ID
          0000H APM BIOS
          All other values reserved  
  CX  =  Function code
          0000H  Disable Timer Based Requests
          0001H  Enable Timer Based Requests
          0002H  Get Enabled/Disabled status
          All other values are reserved
      
Returns:      
  If function successful:
  Carry  =  0
  CX  =  Enabled/Disabled status
      0000H Disabled
      0001H Enabled
  If function unsuccessful:
  Carry  =  1
  AH  =  Error code
      03H  Interface not connected
      09H  Unrecognized device ID
      0AH  Parameter value out of range
      0BH  Interface not engaged
Supported modes:
  Real mode
  Protected mode (16-bit and 32-bit)

--*/
{
  //If BX != 0x0000 then return error = APM_UNRECOGNIZED_DEVICE_ID
  if (((mSmst->CpuSaveState->Ia32SaveState.EBX) & 0x0000FFFF) != 0x0000) {
  (mSmst->CpuSaveState->Ia32SaveState.EAX) = (((mSmst->CpuSaveState->Ia32SaveState.EAX) & 0xFFFF00FF) | APM_UNRECOGNIZED_DEVICE_ID);      
  return;
  }
  //If APM not connected, or disengaged, return error code else return successful, AH=0
  if (mAPMInterfaceConnectState==APM_NOT_CONNECTED) {
    (mSmst->CpuSaveState->Ia32SaveState.EAX) = (((mSmst->CpuSaveState->Ia32SaveState.EAX) & 0xFFFF00FF) | mAPMInterfaceConnectState);      
  } else {
    if (mAPMEngagedState == FALSE) {
      (mSmst->CpuSaveState->Ia32SaveState.EAX) = (((mSmst->CpuSaveState->Ia32SaveState.EAX) & 0xFFFF00FF) | APM_FLAG_DISENGAGED);      
  } else {
    (mSmst->CpuSaveState->Ia32SaveState.EAX) = ((mSmst->CpuSaveState->Ia32SaveState.EAX) & 0xFFFF00FF);      
    //If CX=0 on entry return CX =0
    if (((mSmst->CpuSaveState->Ia32SaveState.ECX) & 0x0000FFFF) == 0x0000) {
      return;
    }
    //If CX=1 on entry return CX =1
    if (((mSmst->CpuSaveState->Ia32SaveState.ECX) & 0x0000FFFF) == 0x0000) {
      return;
    } else {
      //else return CX =0
      (mSmst->CpuSaveState->Ia32SaveState.ECX) = ((mSmst->CpuSaveState->Ia32SaveState.ECX) & 0xFFFF0000);
    }
  }
  }
  return;
}

VOID
ApmOemDefinedFunctions ()
/*++

Routine Description:

Arguments:

Returns:

--*/
{
  return;
}

VOID
Apm12Callback (
  IN  EFI_HANDLE                    DispatchHandle,
  IN  EFI_SMM_SW_DISPATCH_CONTEXT   *DispatchContext
  )
/*++

Routine Description:

  When an Apm 1.2 function is requested, this routine dispatches it.

Arguments:

Returns:

  None

--*/
{
  UINT8             FunctionNumber;
  //
  // Check which function was requested and dispatch it.
  //

  FunctionNumber =  (UINT8)(((mSmst->CpuSaveState->Ia32SaveState.EAX) >> 16) & 0x00FF);
  switch (FunctionNumber)  {

  case APM_INSTALLATION_CHECK:
  ApmInstallationCheck();
  break;

  case APM_REAL_MODE_INTERFACE_CONNECT:
  ApmRealModeInterfaceConnect();
  break;

  case APM_16_BIT_PROTECTED_MODE_INTERFACE_CONNECT:
  Apm16BitProtectedModeInterfaceConnect();
  break;

  case APM_32_BIT_PROTECTED_MODE_INTERFACE_CONNECT:
  Apm32BitProtectedModeInterfaceConnect();
  break;

  case APM_INTERFACE_DISCONNECT:
  ApmInterfaceDisconnect();
  break;

  case APM_CPU_IDLE:
  ApmCpuIdle();
  break;

  case APM_CPU_BUSY:
  ApmCpuBusy();
  break;

  case APM_SET_POWER_STATE:
  ApmSetPowerState(DispatchHandle);
  break;

  case APM_ENABLE_DISABLE_POWER_MANAGEMENT:
  ApmEnableDisablePowerManagement();
  break;

  case APM_RESTORE_APM_BIOS_POWER_ON_DEFAULTS:
  ApmRestoreApmBiosPowerOnDefaults();
  break;

  case APM_GET_POWER_STATUS:
  ApmGetPowerStatus();
  break;

  case APM_GET_PM_EVENT:
  ApmGetPmEvent();
  break;

  case APM_GET_POWER_STATE:
  ApmGetPowerState();
  break;

  case APM_ENABLE_DISABLE_DEVICE_POWER_MANAGEMENT:
  ApmEnableDisableDevicePowerManagement();
  break;

  case APM_DRIVER_VERSION:
  ApmDriverVersion();
  break;

  case APM_ENGAGE_DISENGAGE_POWER_MANAGEMENT:
  ApmEngageDisengagePowerManagement();
  break;

  case APM_GET_CAPABILITIES:
  ApmGetCapabilities();
  break;

  case APM_GET_SET_DISABLE_RESUME_TIMER:
  ApmGetSetDisableResumeTimer();
  break;

  case APM_ENABLE_DISABLE_RESUME_ON_RING_INDICATOR:
  ApmEnableDisableResumeOnRingIndicator();
  break;

  case APM_ENABLE_DISABLE_TIMER_BASED_REQUESTS:
  ApmEnableDisableTimerBasedRequests();
  break;

  case APM_OEM_DEFINED_FUNCTIONS:
  ApmOemDefinedFunctions();
  break;

  default:
  break;  
  }


  return;
}


