/*++
  This file contains an 'Intel Peripheral Driver' and is        
  licensed for Intel CPUs and chipsets under the terms of your  
  license agreement with Intel or your vendor.  This file may   
  be modified by the user, subject to additional terms of the   
  license agreement                                             
--*/
/** @file

  Copyright (c) 2004 - 2014, Intel Corporation. All rights reserved.<BR>
  This software and associated documentation (if any) is furnished
  under a license and may only be used or copied in accordance
  with the terms of the license. Except as permitted by such
  license, no part of this software or documentation may be
  reproduced, stored in a retrieval system, or transmitted in any
  form or by any means without the express written consent of
  Intel Corporation.


Module Name:


    SmmRtc.c

Abstract:

    This is a generic template for a child of the IchSmm driver.

Revision History

--*/
#include "SmmPlatform.h"

#define RTC_ADDRESS_SECONDS          0   // R/W  Range 0..59
#define RTC_ADDRESS_MINUTES          2   // R/W  Range 0..59
#define RTC_ADDRESS_HOURS            4   // R/W  Range 1..12 or 0..23 Bit 7 is AM/PM
#define RTC_ADDRESS_DAY_OF_THE_MONTH 7   // R/W  Range 1..31
#define RTC_ADDRESS_MONTH            8   // R/W  Range 1..12
#define RTC_ADDRESS_YEAR             9   // R/W  Range 0..99
//#define RTC_ADDRESS_CENTURY          50  // R/W  Range 19..20 Bit 8 is R/W


//
// Dallas DS12C887 Real Time Clock
//
#define RTC_ADDRESS_SECONDS           0   // R/W  Range 0..59
#define RTC_ADDRESS_SECONDS_ALARM     1   // R/W  Range 0..59
#define RTC_ADDRESS_MINUTES           2   // R/W  Range 0..59
#define RTC_ADDRESS_MINUTES_ALARM     3   // R/W  Range 0..59
#define RTC_ADDRESS_HOURS             4   // R/W  Range 1..12 or 0..23 Bit 7 is AM/PM
#define RTC_ADDRESS_HOURS_ALARM       5   // R/W  Range 1..12 or 0..23 Bit 7 is AM/PM
#define RTC_ADDRESS_DAY_OF_THE_WEEK   6   // R/W  Range 1..7
#define RTC_ADDRESS_DAY_OF_THE_MONTH  7   // R/W  Range 1..31
#define RTC_ADDRESS_MONTH             8   // R/W  Range 1..12
#define RTC_ADDRESS_YEAR              9   // R/W  Range 0..99
//#define RTC_ADDRESS_CENTURY           50  // R/W  Range 19..20 Bit 8 is R/W

//
// Register B
//
typedef struct {
  UINT8 DSE : 1;  // 0 - Daylight saving disabled  1 - Daylight savings enabled
  UINT8 MIL : 1;  // 0 - 12 hour mode              1 - 24 hour mode
  UINT8 DM : 1;   // 0 - BCD Format                1 - Binary Format
  UINT8 SQWE : 1; // 0 - Disable SQWE output       1 - Enable SQWE output
  UINT8 UIE : 1;  // 0 - Update INT disabled       1 - Update INT enabled
  UINT8 AIE : 1;  // 0 - Alarm INT disabled        1 - Alarm INT Enabled
  UINT8 PIE : 1;  // 0 - Periodic INT disabled     1 - Periodic INT Enabled
  UINT8 SET : 1;  // 0 - Normal operation.         1 - Updates inhibited
} RTC_REGISTER_B_BITS;

typedef union {
  RTC_REGISTER_B_BITS Bits;
  UINT8               Data;
} RTC_REGISTER_B;

UINT8
BcdToDecimal (
  IN  UINT8 BcdValue
  )
/*++

Routine Description:

  Arguments:

  

Returns: 
--*/
// GC_TODO:    BcdValue - add argument and description to function comment
{
  UINTN High;
  UINTN Low;

  High  = BcdValue >> 4;
  Low   = BcdValue - (High << 4);

  return (UINT8) (Low + (High * 10));
}

VOID
RtcWrite (
  IN  UINT8   Address,
  IN  UINT8   Data
  )
/*++

Routine Description:

  GC_TODO: Add function description

Arguments:

  Address - GC_TODO: add argument description
  Data    - GC_TODO: add argument description

Returns:

  GC_TODO: add return values

--*/
{
  IoWrite8 (PCAT_RTC_ADDRESS_REGISTER, (UINT8) Address);
  IoWrite8 (PCAT_RTC_DATA_REGISTER, Data);
}

STATIC
UINT8
RtcRead (
  IN UINT8 Address
  )
{
  UINT8 Data8;

  IoWrite8 (PCAT_RTC_ADDRESS_REGISTER, (UINT8) Address);
  Data8 = IoRead8 (PCAT_RTC_DATA_REGISTER);
  return Data8;
}

EFI_STATUS
RtcTestCenturyRegister (
  VOID
  )
/*++

Routine Description:

  Arguments:

  

Returns: 
--*/
// GC_TODO:    EFI_SUCCESS - add return value to function comment
// GC_TODO:    EFI_DEVICE_ERROR - add return value to function comment
{
  UINT8 Century;
  UINT8 Temp;

  Century = RtcRead (RTC_ADDRESS_CENTURY);
  //
  //  RtcWrite (RTC_ADDRESS_CENTURY, 0x00);
  //
  Temp = (UINT8) (RtcRead (RTC_ADDRESS_CENTURY) & 0x7f);
  RtcWrite (RTC_ADDRESS_CENTURY, Century);
  if (Temp == 0x19 || Temp == 0x20) {
    return EFI_SUCCESS;
  }

  return EFI_DEVICE_ERROR;
}

VOID
ConvertRtcTimeToEfiTime (
  IN EFI_TIME       *Time,
  IN RTC_REGISTER_B RegisterB
  )
/*++

Routine Description:

  Arguments:

  

Returns: 
--*/
// GC_TODO:    Time - add argument and description to function comment
// GC_TODO:    RegisterB - add argument and description to function comment
{
  BOOLEAN PM;

  if ((Time->Hour) & 0x80) {
    PM = TRUE;
  } else {
    PM = FALSE;
  }

  Time->Hour = (UINT8) (Time->Hour & 0x7f);

  if (RegisterB.Bits.DM == 0) {
    Time->Year    = BcdToDecimal ((UINT8) Time->Year);
    Time->Month   = BcdToDecimal (Time->Month);
    Time->Day     = BcdToDecimal (Time->Day);
    Time->Hour    = BcdToDecimal (Time->Hour);
    Time->Minute  = BcdToDecimal (Time->Minute);
    Time->Second  = BcdToDecimal (Time->Second);
  }
  //
  // If time is in 12 hour format, convert it to 24 hour format
  //
  if (RegisterB.Bits.MIL == 0) {
    if (PM && Time->Hour < 12) {
      Time->Hour = (UINT8) (Time->Hour + 12);
    }

    if (!PM && Time->Hour == 12) {
      Time->Hour = 0;
    }
  }

  Time->Nanosecond  = 0;
  Time->TimeZone    = EFI_UNSPECIFIED_TIMEZONE;
  Time->Daylight    = 0;
}

EFI_STATUS
EfiSmmGetTime (
  IN OUT EFI_TIME *Time
  )
{
  
  RTC_REGISTER_B  RegisterB;
  EFI_STATUS      Status = EFI_SUCCESS;
  UINT8           Century;
  
   //
  // Read Register B
  //
  RegisterB.Data = RtcRead (RTC_ADDRESS_REGISTER_B);
  
  Time->Year    = RtcRead(RTC_ADDRESS_YEAR);       
  Time->Month   = RtcRead(RTC_ADDRESS_MONTH);     
  Time->Day     = RtcRead(RTC_ADDRESS_DAY_OF_THE_MONTH);        
  Time->Hour    = RtcRead(RTC_ADDRESS_HOURS);       
  Time->Minute  = RtcRead(RTC_ADDRESS_MINUTES);     
  Time->Second  = RtcRead(RTC_ADDRESS_SECONDS); 
  
  ConvertRtcTimeToEfiTime (Time, RegisterB);
  
  if (RtcTestCenturyRegister () == EFI_SUCCESS) {
    Century = BcdToDecimal ((UINT8) (RtcRead (RTC_ADDRESS_CENTURY) & 0x7f));
  } else {
    Century = BcdToDecimal (RtcRead (RTC_ADDRESS_CENTURY));
  }
  
   Time->Year = (UINT16) (Century * 100 + Time->Year);

  return Status;

}
