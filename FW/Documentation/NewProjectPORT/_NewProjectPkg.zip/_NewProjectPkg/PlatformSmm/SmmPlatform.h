//
// This file contains an 'Intel Peripheral Driver' and is
// licensed for Intel CPUs and chipsets under the terms of your
// license agreement with Intel or your vendor.  This file may
// be modified by the user, subject to additional terms of the
// license agreement
//
/*++

  Copyright (c) 2004 - 2014, Intel Corporation. All rights reserved.<BR>
  This software and associated documentation (if any) is furnished
  under a license and may only be used or copied in accordance
  with the terms of the license. Except as permitted by such
  license, no part of this software or documentation may be
  reproduced, stored in a retrieval system, or transmitted in any
  form or by any means without the express written consent of
  Intel Corporation.

Module Name:

  SmmPlatform.h

Abstract:

  Header file for
 
++*/

#ifndef _PLATFORM_H
#define _PLATFORM_H

#include <PiSmm.h>



#include <Protocol/SmmBase.h>
#include <Protocol/FirmwareVolume.h>
#include <Protocol/SmmPowerButtonDispatch.h>
#include <Protocol/SmmSxDispatch.h>
#include <Protocol/SmmSwDispatch.h>
#include <Protocol/SmmSwDispatch2.h>
#include <Protocol/SmmIchnDispatch.h>
#include <Protocol/SmmAccess.h>
#include <Protocol/SmmVariable.h>
#include <Protocol/PciRootBridgeIo.h>
#include <Protocol/LoadedImage.h>
#include "Protocol/GlobalNvsArea.h"
#include <Guid/AcpiVariableCompatibility.h>
#include <Guid/SetupVariable.h>
#include <Guid/EfiVpdData.h>
#include <Guid/PciLanInfo.h>
#include <IndustryStandard/Pci22.h>

#include "PchAccess.h"
#include "CpuRegs.h"
#include "CMOSMap.h"
#include "PlatformBaseAddresses.h"

#include <Library/UefiBootServicesTableLib.h>
#include <Library/S3BootScriptLib.h>
#include <Library/IoLib.h>
#include <Library/DebugLib.h>
#include <Library/HobLib.h>
#include <Library/BaseLib.h>
#include <Library/BaseMemoryLib.h>
#include <Library/DevicePathLib.h>
#include <Library/PcdLib.h>
#include <Library/PchPlatformLib.h>



typedef struct {
  UINT8     Register;
  UINT8     Function;
  UINT8     Device;
  UINT8     Bus;
  UINT32    ExtendedRegister;
} SMM_PCI_IO_ADDRESS;

typedef struct {
  CHAR8     BoardAaNumber[7];
  UINTN     BoardFabNumber;
} BOARD_AA_NUMBER_DECODE;

//
// BugBug -- Need to get these two values from acpi.h, but right now, they are
//           declared in platform-specific variants of this file, so no easy
//           way to pick-up the include file and work across platforms.
//           Need these definitions to go into a file like common\acpi.h.
//
#define ACPI_ENABLE                 0xA0
#define ACPI_DISABLE                0xA1

#define APM_12_FUNCS                  0x50
#define SMI_SET_SMMVARIABLE_PROTOCOL  0x51  // this is used in Cpu\Pentium\Smm\Base\SmmBase.c

#define SMI_CMD_GET_MSEG_STATUS     0x70
#define SMI_CMD_UPDATE_MSEG_SIZE    0x71
#define SMI_CMD_LOAD_STM            0x72
#define SMI_CMD_UNLOAD_STM          0x73
#define SMI_CMD_GET_SMRAM_RANGES    0x74


#define PCAT_RTC_ADDRESS_REGISTER   0x74
#define PCAT_RTC_DATA_REGISTER      0x75

#define RTC_ADDRESS_SECOND          0x00
#define RTC_ADDRESS_SECOND_ALARM    0x01
#define RTC_ADDRESS_MINUTE          0x02
#define RTC_ADDRESS_MINUTE_ALARM    0x03
#define RTC_ADDRESS_HOUR            0x04
#define RTC_ADDRESS_HOUR_ALARM      0x05

#define RTC_ADDRESS_REGISTER_A      0x0A
#define RTC_ADDRESS_REGISTER_B      0x0B
#define RTC_ADDRESS_REGISTER_C      0x0C
#define RTC_ADDRESS_REGISTER_D      0x0D

#define B_RTC_ALARM_INT_ENABLE      0x20
#define B_RTC_ALARM_INT_STATUS      0x20

#define B_RTC_DATE_ALARM_MASK       0x3F

#define PCAT_CMOS_2_ADDRESS_REGISTER  0x72
#define PCAT_CMOS_2_DATA_REGISTER     0x73

#define EC_C_PORT                     0x66
#define SMC_SMI_DISABLE               0xBC
#define SMC_ENABLE_ACPI_MODE          0xAA  // Enable ACPI mode


//
// #defines for APM 1.2 functions
//
#define APM_INSTALLATION_CHECK                         0x00
#define APM_REAL_MODE_INTERFACE_CONNECT                0x01
#define APM_16_BIT_PROTECTED_MODE_INTERFACE_CONNECT    0x02
#define APM_32_BIT_PROTECTED_MODE_INTERFACE_CONNECT    0x03
#define APM_INTERFACE_DISCONNECT                       0x04
#define APM_CPU_IDLE                                   0x05
#define APM_CPU_BUSY                                   0x06
#define APM_SET_POWER_STATE                            0x07
#define APM_ENABLE_DISABLE_POWER_MANAGEMENT            0x08
#define APM_RESTORE_APM_BIOS_POWER_ON_DEFAULTS         0x09
#define APM_GET_POWER_STATUS                           0x0A
#define APM_GET_PM_EVENT                               0x0B
#define APM_GET_POWER_STATE                            0x0C
#define APM_ENABLE_DISABLE_DEVICE_POWER_MANAGEMENT     0x0D
#define APM_DRIVER_VERSION                             0x0E
#define APM_ENGAGE_DISENGAGE_POWER_MANAGEMENT          0x0F
#define APM_GET_CAPABILITIES                           0x10
#define APM_GET_SET_DISABLE_RESUME_TIMER               0x11
#define APM_ENABLE_DISABLE_RESUME_ON_RING_INDICATOR    0x12
#define APM_ENABLE_DISABLE_TIMER_BASED_REQUESTS        0x13
#define APM_OEM_DEFINED_FUNCTIONS                      0x80

//
// #defines for APM 1.2 variable mAPMInterfaceConnectState (also double as error codes)
//
#define APM_REAL_MODE                        0x02
#define APM_NOT_CONNECTED                    0x03
#define APM_16BIT_PROTECTED                  0x05
#define APM_32BIT_PROTECTED                  0x07
//
// #defines for additional APM 1.2 error codes
//
#define APM_FUNCTIONALITY_DISABLED                0x01
#define APM_UNRECOGNIZED_DEVICE_ID                0x09
#define APM_INTERFACE_NOT_ENGAGED                 0x0B
#define APM_FUNCTION_NOT_SUPPORTED                0x0C
#define APM_NO_POWER_MANAGEMENT_EVENTS_PENDING    0x80
//
// #defines for APM 1.2 miscellaneous support
//
#define APM_FLAG_16BIT_PROTECTED_SUPPORT     0x01
#define APM_FLAG_32BIT_PROTECTED_SUPPORT     0x02
#define APM_FLAG_DISABLED                    0x04
#define APM_FLAG_DISENGAGED                  0x08
#define APM_SET_POWER_STATE_OFF              0x03
#define APM_AC_LINE_STATUS_UNKNOWN           0xFF00
#define APM_BATTERY_STATUS_UNKNOWN           0x00FF
#define APM_BATTERY_FLAG_UNKNOWN             0xFF00
#define APM_BATTERY_LIFE_PERCENTAGE_UNKNOWN  0x00 ,  0x00,  0x00,  0x00,  0x30,  0x00,  0x00,  0x00,0x00FF
#define APM_BATTERY_LIFE_TIME_UNITS_UNKNOWN  0xFFFF


#define MAXIMUM_NUMBER_OF_PSTATES           12
#define  ICH_SMM_DATA_PORT                  0xB3

#define EFI_IA32_PMG_CST_CONFIG               0x000000E2
#define   B_EFI_CST_CONTROL_LOCK                BIT15
#define   B_EFI_IO_MWAIT_REDIRECTION_ENABLE     BIT10
#define EFI_IA32_PMG_IO_CAPTURE_ADDR          0x000000E4

extern EFI_PCI_ROOT_BRIDGE_IO_PROTOCOL *mPciRootBridgeIo;

//
// Callback function prototypes
//
VOID
PowerButtonCallback (
  IN  EFI_HANDLE                              DispatchHandle,
  IN  EFI_SMM_POWER_BUTTON_DISPATCH_CONTEXT   *DispatchContext
  );

VOID
S5SleepWakeOnLanCallBack (
  IN  EFI_HANDLE                    DispatchHandle,
  IN  EFI_SMM_SX_DISPATCH_CONTEXT   *DispatchContext
  );

VOID
S5SleepAcLossCallBack (
  IN  EFI_HANDLE                    DispatchHandle,
  IN  EFI_SMM_SX_DISPATCH_CONTEXT   *DispatchContext
  );

VOID
S5SleepCapsuleCallBack (
  IN  EFI_HANDLE                    DispatchHandle,
  IN  EFI_SMM_SX_DISPATCH_CONTEXT   *DispatchContext
  );

VOID
S4S5CallBack (
  IN  EFI_HANDLE                    DispatchHandle,
  IN  EFI_SMM_SX_DISPATCH_CONTEXT   *DispatchContext
  );

VOID
EnableAcpiCallback (
  IN  EFI_HANDLE                    DispatchHandle,
  IN  EFI_SMM_SW_DISPATCH_CONTEXT   *DispatchContext
  );

VOID
DisableAcpiCallback (
  IN  EFI_HANDLE                    DispatchHandle,
  IN  EFI_SMM_SW_DISPATCH_CONTEXT   *DispatchContext
  );

VOID
Apm12Callback (
  IN  EFI_HANDLE                    DispatchHandle,
  IN  EFI_SMM_SW_DISPATCH_CONTEXT   *DispatchContext
  );

VOID
SmmReadyToBootCallback (
  IN  EFI_HANDLE                    DispatchHandle,
  IN  EFI_SMM_SW_DISPATCH_CONTEXT   *DispatchContext
  );

VOID
DummyTco1Callback (
  IN  EFI_HANDLE                              DispatchHandle,
  IN  EFI_SMM_ICHN_DISPATCH_CONTEXT           *DispatchContext
  );

VOID
PmeCallback (
  IN  EFI_HANDLE                              DispatchHandle,
  IN  EFI_SMM_ICHN_DISPATCH_CONTEXT           *DispatchContext
  );

VOID
EccCallback (
  IN  EFI_HANDLE                              DispatchHandle,
  IN  EFI_SMM_ICHN_DISPATCH_CONTEXT           *DispatchContext
  );

VOID
PerrSerrCallback (
  IN  EFI_HANDLE                              DispatchHandle,
  IN  EFI_SMM_ICHN_DISPATCH_CONTEXT           *DispatchContext
  );

VOID
RiCallback (
  IN  EFI_HANDLE                              DispatchHandle,
  IN  EFI_SMM_ICHN_DISPATCH_CONTEXT           *DispatchContext
  );

VOID
WatchdogCallback (
  IN  EFI_HANDLE                              DispatchHandle,
  IN  EFI_SMM_ICHN_DISPATCH_CONTEXT           *DispatchContext
  );


VOID
SetAfterG3On (
  BOOLEAN Enable
  );

VOID
TurnOffVregUsb (
  );

VOID
PStateSupportCallback (
  IN  EFI_HANDLE                              DispatchHandle,
  IN  EFI_SMM_SW_DISPATCH_CONTEXT             *DispatchContext
  );

VOID
PStateTransitionCallback (
  IN  EFI_HANDLE                              DispatchHandle,
  IN  EFI_SMM_SW_DISPATCH_CONTEXT             *DispatchContext
  );

EFI_STATUS
SxSleepEntryCallBack (
  IN  EFI_HANDLE                    DispatchHandle,
  IN  EFI_SMM_SX_DISPATCH_CONTEXT   *DispatchContext
  );

EFI_STATUS
SaveRuntimeScriptTable (
  IN EFI_SMM_SYSTEM_TABLE       *Smst
  );

/*+
VOID
WaitForMdiTransactionComplete(
  IN       UINT32   Data32,
  IN OUT   BOOLEAN  *ReadyBitSet
  );
-*/

VOID
TpmPtsSmbsCallback (
  IN  EFI_HANDLE                    DispatchHandle,
  IN  EFI_SMM_SW_DISPATCH_CONTEXT   *DispatchContext
  );

#endif

