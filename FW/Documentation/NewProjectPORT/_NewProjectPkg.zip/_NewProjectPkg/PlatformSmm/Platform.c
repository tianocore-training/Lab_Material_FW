/*++
  This file contains an 'Intel Peripheral Driver' and is        
  licensed for Intel CPUs and chipsets under the terms of your  
  license agreement with Intel or your vendor.  This file may   
  be modified by the user, subject to additional terms of the   
  license agreement                                             
--*/
/** @file

  Copyright (c) 2004 - 2014, Intel Corporation. All rights reserved.<BR>
  This software and associated documentation (if any) is furnished
  under a license and may only be used or copied in accordance
  with the terms of the license. Except as permitted by such
  license, no part of this software or documentation may be
  reproduced, stored in a retrieval system, or transmitted in any
  form or by any means without the express written consent of
  Intel Corporation.

Module Name:

    Platform.c

Abstract:

    This is a generic template for a child of the IchSmm driver.

 
--*/

#include "SmmPlatform.h"
#include <Protocol/CpuIo2.h>

#define IO_MISC 156

#if defined(LT_SUPPORT) && (LT_SUPPORT)
//VOID
//InitSmmStm (
//  EFI_SMM_SW_DISPATCH_PROTOCOL              *SwDispatch
//);
#endif
//
//
// Local variables
//
typedef struct {
  UINT8     Device;
  UINT8     Function;
} EFI_PCI_BUS_MASTER;

EFI_PCI_BUS_MASTER  mPciBm[] = {
  { PCI_DEVICE_NUMBER_PCH_PCIE_ROOT_PORTS, PCI_FUNCTION_NUMBER_PCH_PCIE_ROOT_PORT_1 },
  { PCI_DEVICE_NUMBER_PCH_PCIE_ROOT_PORTS, PCI_FUNCTION_NUMBER_PCH_PCIE_ROOT_PORT_2 },
  { PCI_DEVICE_NUMBER_PCH_PCIE_ROOT_PORTS, PCI_FUNCTION_NUMBER_PCH_PCIE_ROOT_PORT_3 },
  { PCI_DEVICE_NUMBER_PCH_PCIE_ROOT_PORTS, PCI_FUNCTION_NUMBER_PCH_PCIE_ROOT_PORT_4 },
  { PCI_DEVICE_NUMBER_PCH_USB, PCI_FUNCTION_NUMBER_PCH_EHCI }
};

//
// If need to support more than 1 key sequence, use below register range for programming.
//   Key set 1 index range: 0x00 - 0x0E
//   Key set 2 index range: 0x30 - 0x3E
//   Key set 3 index range: 0x40 - 0x4E
//
#if (defined KEYBOARD_WAKE_FROM_S5_SETUP_SUPPORT) && KEYBOARD_WAKE_FROM_S5_SETUP_SUPPORT
EFI_KEY_SEQUENCE S5WakePowerKeySequence[] = {
   {0x00, 0x37},
   {0x01, 0xF0},
   {0x02, 0xE0},
   {0x03, 0x37},
   {0x04, 0xE0},
   {0x05, 0x00},
   {0x06, 0x00},
   {0x07, 0x00},
   {0x08, 0x00},
   {0x09, 0x00},
   {0x0A, 0x00},
   {0x0B, 0x00},
   {0x0C, 0x00},
   {0x0D, 0x00},
   {0x0E, 0x00},
  };
UINTN S5WakePowerKeySequenceCount = sizeof (S5WakePowerKeySequence) / sizeof(EFI_KEY_SEQUENCE);

EFI_KEY_SEQUENCE S5WakeAltPrintScreenSequence[] = {
   {0x00, 0x84},
   {0x01, 0xF0},
   {0x02, 0x84},
   {0x03, 0x00},
   {0x04, 0x00},
   {0x05, 0x00},
   {0x06, 0x00},
   {0x07, 0x00},
   {0x08, 0x00},
   {0x09, 0x00},
   {0x0A, 0x00},
   {0x0B, 0x00},
   {0x0C, 0x00},
   {0x0D, 0x00},
   {0x0E, 0x00},
  };
UINTN S5WakeAltPrintScreenSequenceCount = sizeof (S5WakeAltPrintScreenSequence) / sizeof(EFI_KEY_SEQUENCE);
#endif

BOARD_AA_NUMBER_DECODE DefectiveBoardIdTable [] = {
  {"E76523", 302},  //BLKD510MO
//  {"E76523", 302},  //BOXD510MO
  {"E76525", 301},  //LAD510MO
  {"E67982", 303}   //LAD510MOV
};
UINTN DefectiveBoardIdTableSize = sizeof (DefectiveBoardIdTable) / sizeof (BOARD_AA_NUMBER_DECODE);

EFI_SMM_BASE_PROTOCOL                   *mSmmBase;
EFI_SMM_SYSTEM_TABLE                    *mSmst;
UINT16                                  mAcpiBaseAddr;
SYSTEM_CONFIGURATION                    mSystemConfiguration;
EFI_SMM_VARIABLE_PROTOCOL               *mSmmVariable;
//EFI_BOARD_FEATURES                      mBoardFeatures;
EFI_GLOBAL_NVS_AREA_PROTOCOL            *mGlobalNvsAreaPtr;

UINT16									mPM1_SaveState16;
UINT32									mGPE_SaveState32;

BOOLEAN                                 mSetSmmVariableProtocolSmiAllowed = TRUE;

#if (defined KEYBOARD_WAKE_FROM_S5_SETUP_SUPPORT) && KEYBOARD_WAKE_FROM_S5_SETUP_SUPPORT
EFI_WPC83627_POLICY_PROTOCOL            *LpcWpc83627Policy;
UINT16                                  Ps2KeyboardPresence;
UINT8                                   mWakeOnS5KeyboardVariable;
#endif

//
// Variables. Need to initialize this from Setup
//
BOOLEAN                                 mWakeOnLanS5Variable;
BOOLEAN                                 mWakeOnRtcVariable;
UINT8                                   mWakeupDay;
UINT8                                   mWakeupHour;
UINT8                                   mWakeupMinute;
UINT8                                   mWakeupSecond;
UINT8                                   mDeepStandby=0;

//
// Use an enum. 0 is Stay Off, 1 is Last State, 2 is Stay On
//
UINT8                                   mAcLossVariable;

//
// APM 1.2 State variables
//
UINT8                                   mAPMInterfaceConnectState;
BOOLEAN                                 mAPMEnabledState;
BOOLEAN                                 mAPMEngagedState;

static
UINT8 mTco1Sources[] = {
  IchnNmi
};

UINTN
DevicePathSize (
  IN EFI_DEVICE_PATH_PROTOCOL  *DevicePath
  );

VOID
S4S5ProgClock();

//VOID
//EnableS5WakeOnLan();

/*R01 -s
VOID
EnableWakeOnRi();
R01 -e*/
EFI_STATUS
InitRuntimeScriptTable (
  IN EFI_SYSTEM_TABLE  *SystemTable
  );

VOID
S5SleepWakeOnRtcCallBack (
  IN  EFI_HANDLE                    DispatchHandle,
  IN  EFI_SMM_SX_DISPATCH_CONTEXT   *DispatchContext
  );


#if (defined KEYBOARD_WAKE_FROM_S5_SETUP_SUPPORT) && KEYBOARD_WAKE_FROM_S5_SETUP_SUPPORT
VOID
S5Ps2WakeFromKbcSxCallBack(
  IN  EFI_HANDLE                    DispatchHandle,
  IN  EFI_SMM_SX_DISPATCH_CONTEXT   *DispatchContext
  );
#endif

#if (defined KEYBOARD_WAKE_FROM_S5_SETUP_SUPPORT) && KEYBOARD_WAKE_FROM_S5_SETUP_SUPPORT
VOID
EnableS5WakeFromKBC();
#endif

VOID
EnableS5WakeOnRtc();

EFI_STATUS
Stall (
  IN UINTN              Microseconds
  );

UINT8
HexToBcd(
  UINT8 HexValue
  );

UINT8
BcdToHex(
  IN UINT8 BcdValue
  );

EFI_STATUS
EfiSmmGetTime (
  IN OUT EFI_TIME *Time
  );


VOID
CpuSmmSxWorkAround(
  );

EFI_STATUS
InitializePlatformSmm (
  IN EFI_HANDLE        ImageHandle,
  IN EFI_SYSTEM_TABLE  *SystemTable
  )
/*++

Routine Description:

  Initializes the SMM Handler Driver

Arguments:

  ImageHandle -

  SystemTable -

Returns:

  None

--*/
{
  EFI_STATUS                                Status;
  BOOLEAN                                   InSmm;
  UINT8                                     Index;
  EFI_HANDLE                                Handle;
  EFI_SMM_POWER_BUTTON_DISPATCH_CONTEXT     PowerButtonContext;
  EFI_SMM_POWER_BUTTON_DISPATCH_PROTOCOL    *PowerButtonDispatch;
  EFI_SMM_ICHN_DISPATCH_CONTEXT             IchnContext;
  EFI_SMM_ICHN_DISPATCH_PROTOCOL            *IchnDispatch;
  EFI_SMM_SX_DISPATCH_PROTOCOL              *SxDispatch;
  EFI_SMM_SX_DISPATCH_CONTEXT               EntryDispatchContext;
  EFI_SMM_SW_DISPATCH_PROTOCOL              *SwDispatch;
  EFI_SMM_SW_DISPATCH_CONTEXT               SwContext;
  UINTN                                     VarSize;
  EFI_BOOT_MODE                             BootMode;
//  VOID                                      *HobList;
  EFI_LOADED_IMAGE_PROTOCOL                 *LoadedImage;
  EFI_DEVICE_PATH_PROTOCOL                  *CompleteFilePath;
  EFI_DEVICE_PATH_PROTOCOL                  *ImageDevicePath;
//  UINTN                                     BoardIdBufferSize;

  Handle = NULL;

  // Set default values for APM 1.2 states
  mAPMInterfaceConnectState = APM_NOT_CONNECTED;
  mAPMEnabledState = TRUE;
  mAPMEngagedState = TRUE;

  //
  // Initialize the EFI Runtime Library
  //

  Status = gBS->LocateProtocol (&gEfiSmmBaseProtocolGuid, NULL, &mSmmBase);
  ASSERT_EFI_ERROR(Status);

  //
  //  Locate the Global NVS Protocol.
  //
  Status = gBS->LocateProtocol (
                  &gEfiGlobalNvsAreaProtocolGuid,
                  NULL,
                  &mGlobalNvsAreaPtr
                  );
  ASSERT_EFI_ERROR (Status);

  mSmmBase->InSmm (mSmmBase, &InSmm);

  if (!InSmm) {
    //
    // This driver is dispatched by DXE, so first call to this driver will not
    // be in SMM.  We need to load this driver into SMRAM and then generate
    // an SMI to initialize data structures in SMRAM.
    //

    //
    // Get this driver's image's FilePath
    //
    Status = gBS->HandleProtocol (ImageHandle,
                                  &gEfiLoadedImageProtocolGuid,
                                  &LoadedImage
                                  );
    ASSERT_EFI_ERROR(Status);

    Status = gBS->HandleProtocol (LoadedImage->DeviceHandle,
                                  &gEfiDevicePathProtocolGuid,
                                  (VOID *)&ImageDevicePath
                                  );
    ASSERT_EFI_ERROR(Status);

    CompleteFilePath = AppendDevicePath (ImageDevicePath,
                                            LoadedImage->FilePath
                                            );
    //
    // Load the image in memory to SMRAM; it will generate the SMI.
    //
    mSmmBase->Register(mSmmBase, CompleteFilePath, NULL, 0, &Handle, FALSE);
  } else {
    //
    // Great!  We're now in SMM!
    //

    //
    // Initialize global variables
    //
    mSmmBase->GetSmstLocation(mSmmBase, &mSmst);

    //
    // Get the ACPI Base Address
    //

    mAcpiBaseAddr = PchLpcPciCfg16( R_PCH_LPC_ACPI_BASE ) & B_PCH_LPC_ACPI_BASE_BAR;

    VarSize = sizeof(SYSTEM_CONFIGURATION);
    Status = SystemTable->RuntimeServices->GetVariable(L"Setup",
                              &gEfiSetupVariableGuid,
                              NULL,
                              &VarSize,
                              &mSystemConfiguration);
    if (!EFI_ERROR(Status)) {
      mAcLossVariable = mSystemConfiguration.StateAfterG3;
      mDeepStandby=mSystemConfiguration.DeepStandby;

      //
      // If LAN is disabled, WOL function should be disabled too.
      //
      if (mSystemConfiguration.Lan == 0x01){
        mWakeOnLanS5Variable = mSystemConfiguration.WakeOnLanS5;
      } else {
        mWakeOnLanS5Variable = FALSE;
      }

      mWakeOnRtcVariable = mSystemConfiguration.WakeOnRtcS5;
//      if(mWakeOnRtcVariable){
//        mWakeupDay = HexToBcd((UINT8)mSystemConfiguration.RTCWakeupDate);
//        mWakeupHour = HexToBcd((UINT8)mSystemConfiguration.RTCWakeupTimeHour);
//        mWakeupMinute = HexToBcd((UINT8)mSystemConfiguration.RTCWakeupTimeMinute);
//        mWakeupSecond = HexToBcd((UINT8)mSystemConfiguration.RTCWakeupTimeSecond);
//      }

//#if (defined KEYBOARD_WAKE_FROM_S5_SETUP_SUPPORT) && KEYBOARD_WAKE_FROM_S5_SETUP_SUPPORT
//      mWakeOnS5KeyboardVariable = mSystemConfiguration.WakeOnS5Keyboard;
//#endif

    }

    BootMode = GetBootModeHob ();
    //
    // Get the Power Button protocol
    //
    Status = gBS->LocateProtocol(&gEfiSmmPowerButtonDispatchProtocolGuid,
                                 NULL,
                                 &PowerButtonDispatch);
    ASSERT_EFI_ERROR(Status);

    if (BootMode != BOOT_ON_FLASH_UPDATE) {
      //
      // Register for the power button event
      //
      PowerButtonContext.Phase = PowerButtonEntry;
      Status = PowerButtonDispatch->Register(
                                       PowerButtonDispatch,
                                       PowerButtonCallback,
                                       &PowerButtonContext,
                                       &Handle
                                       );
      ASSERT_EFI_ERROR(Status);
    }
    //
    // Get the Sx dispatch protocol
    //
    Status = gBS->LocateProtocol (&gEfiSmmSxDispatchProtocolGuid,
                                  NULL,
                                  &SxDispatch
                                  );
    ASSERT_EFI_ERROR(Status);

    //
    // Register entry phase call back function
    //
    EntryDispatchContext.Type  = SxS3;
    EntryDispatchContext.Phase = SxEntry;

    Status = SxDispatch->Register (
                           SxDispatch,
                           SxSleepEntryCallBack,
                           &EntryDispatchContext,
                           &Handle
                           );


    EntryDispatchContext.Type  = SxS4;

    Status = SxDispatch->Register (
                           SxDispatch,
                           S4S5CallBack,
                           &EntryDispatchContext,
                           &Handle
                           );
    ASSERT_EFI_ERROR(Status);

    //
    // Register entry phase call back function.
    //
//    if (mWakeOnLanS5Variable) {
//      Status = SxDispatch->Register (
//                             SxDispatch,
//                             S5SleepWakeOnLanCallBack,
//                             &EntryDispatchContext,
//                             &Handle
//                             );
//      ASSERT_EFI_ERROR(Status);
//    }

//    if (mWakeOnRtcVariable) {
//      Status = SxDispatch->Register (
//                             SxDispatch,
//                             S5SleepWakeOnRtcCallBack,
//                             &EntryDispatchContext,
//                             &Handle
//                             );
//      ASSERT_EFI_ERROR(Status);
//    }

//#if (defined KEYBOARD_WAKE_FROM_S5_SETUP_SUPPORT) && KEYBOARD_WAKE_FROM_S5_SETUP_SUPPORT
//      Status = SxDispatch->Register (
//                             SxDispatch,
//                             S5Ps2WakeFromKbcSxCallBack,
//                             &EntryDispatchContext,
//                             &Handle
//                             );
//#endif

    EntryDispatchContext.Type  = SxS5;

    Status = SxDispatch->Register (
                           SxDispatch,
                           S4S5CallBack,
                           &EntryDispatchContext,
                           &Handle
                           );
    ASSERT_EFI_ERROR(Status);

    Status = SxDispatch->Register (
                           SxDispatch,
                           S5SleepAcLossCallBack,
                           &EntryDispatchContext,
                           &Handle
                           );
    ASSERT_EFI_ERROR(Status);
//#ifndef NOCS_S3_SUPPORT
//    Status = SxDispatch->Register (
//                           SxDispatch,
//                           S5SleepCapsuleCallBack,
//                           &EntryDispatchContext,
//                           &Handle
//                           );
//    ASSERT_EFI_ERROR(Status);
//#endif
    //
    // Register entry phase call back function.
    //
//    if (mWakeOnLanS5Variable) {
//      Status = SxDispatch->Register (
//                             SxDispatch,
//                             S5SleepWakeOnLanCallBack,
//                             &EntryDispatchContext,
//                             &Handle
//                             );
//      ASSERT_EFI_ERROR(Status);
//    }

//    if (mWakeOnRtcVariable) {
//      Status = SxDispatch->Register (
//                             SxDispatch,
//                             S5SleepWakeOnRtcCallBack,
//                             &EntryDispatchContext,
//                             &Handle
//                             );
//      ASSERT_EFI_ERROR(Status);
//    }

//#if (defined KEYBOARD_WAKE_FROM_S5_SETUP_SUPPORT) && KEYBOARD_WAKE_FROM_S5_SETUP_SUPPORT
//      Status = SxDispatch->Register (
//                             SxDispatch,
//                             S5Ps2WakeFromKbcSxCallBack,
//                             &EntryDispatchContext,
//                             &Handle
//                             );
//#endif

    //
    //  Get the Sw dispatch protocol
    //
    Status = gBS->LocateProtocol (&gEfiSmmSwDispatchProtocolGuid,
                                  NULL,
                                  &SwDispatch
                                  );
    ASSERT_EFI_ERROR(Status);

    //
    // Register ACPI enable handler
    //
    SwContext.SwSmiInputValue = ACPI_ENABLE;
    Status = SwDispatch->Register (
                            SwDispatch,
                            EnableAcpiCallback,
                            &SwContext,
                            &Handle
                            );
    ASSERT_EFI_ERROR(Status);

    //
    // Register ACPI disable handler
    //
    SwContext.SwSmiInputValue = ACPI_DISABLE;
    Status = SwDispatch->Register (
                            SwDispatch,
                            DisableAcpiCallback,
                            &SwContext,
                            &Handle
                            );
    ASSERT_EFI_ERROR(Status);

    //
    // Register for the Apm 1.2 functions
    //
    SwContext.SwSmiInputValue = APM_12_FUNCS;
    Status = SwDispatch->Register(
                               SwDispatch,
                               Apm12Callback,
                               &SwContext,
                               &Handle
                               );
    ASSERT_EFI_ERROR(Status);

    //
    // Register for SmmReadyToBootCallback
    //
    SwContext.SwSmiInputValue = SMI_SET_SMMVARIABLE_PROTOCOL;
    Status = SwDispatch->Register(
                               SwDispatch,
                               SmmReadyToBootCallback,
                               &SwContext,
                               &Handle
                               );
    ASSERT_EFI_ERROR(Status);


    //
    // Register the TPM PTS & SMBS Handler
    //
    SwContext.SwSmiInputValue = 0x5A;

    Status = SwDispatch->Register (
      SwDispatch,
      TpmPtsSmbsCallback,
      &SwContext,
      &Handle
      );

    ASSERT_EFI_ERROR (Status);

    // Get the ICHn protocol
    //
    Status = gBS->LocateProtocol(&gEfiSmmIchnDispatchProtocolGuid,
                                 NULL,
                                 &IchnDispatch);
    ASSERT_EFI_ERROR(Status);

    //
    // Register for the ECC event.
    //
#if defined( ECC_SUPPORT ) && ( ECC_SUPPORT != 0 )
    IchnContext.Type = IchnMch;
    Status = IchnDispatch->Register(
                              IchnDispatch,
                              EccCallback,
                              &IchnContext,
                              &Handle
                              );
    ASSERT_EFI_ERROR( Status );
#endif

    //
    // Register for the Watchdog timer (TCO Timeout).
    //
    IchnContext.Type = IchnTcoTimeout;
    Status = IchnDispatch->Register(
                              IchnDispatch,
                              WatchdogCallback,
                              &IchnContext,
                              &Handle
                              );
    ASSERT_EFI_ERROR( Status );

    //
    // Register for the events that may happen that we do not care.
    // This is true for SMI related to TCO since TCO is enabled by BIOS WP
    //
    for (Index = 0; Index < sizeof(mTco1Sources)/sizeof(UINT8); Index++) {
      IchnContext.Type = mTco1Sources[Index];
      Status = IchnDispatch->Register(
                                IchnDispatch,
                                DummyTco1Callback,
                                &IchnContext,
                                &Handle
                                );
      ASSERT_EFI_ERROR( Status );
    }

    //
    // Lock TCO_EN bit.
    //
    IoWrite16( mAcpiBaseAddr + R_PCH_TCO_CNT, IoRead16( mAcpiBaseAddr + R_PCH_TCO_CNT ) | B_PCH_TCO_CNT_LOCK );

    //
    // Set to power on from G3 dependent on WOL instead of AC Loss variable in order to support WOL from G3 feature.
    //
    //
    // Set wake from G3 dependent on AC Loss variable and Wake On LAN variable.
    // This is because no matter how, if WOL enabled or AC Loss variable not disabled, the board needs to wake from G3 to program the LAN WOL settings.
    // This needs to be done after LAN enable/disable so that the PWR_FLR state clear not impacted the WOL from G3 feature.
    //
    if (mAcLossVariable != 0x00) {
      SetAfterG3On (TRUE);
    } else {
      SetAfterG3On (FALSE);
    }

  /*
    //
    // Get Board ID to determine the correct GPIO
    //
    BoardIdBufferSize = sizeof(EFI_BOARD_FEATURES);
    Status = SystemTable->RuntimeServices->GetVariable (gEfiBoardFeaturesName,
                               &gEfiBoardFeaturesGuid,
                               NULL,
                               &BoardIdBufferSize,
                               &mBoardFeatures
                               );

    Status = InitRuntimeScriptTable(SystemTable);
  */

  }

  return EFI_SUCCESS;
}

VOID
SmmReadyToBootCallback (
  IN  EFI_HANDLE                    DispatchHandle,
  IN  EFI_SMM_SW_DISPATCH_CONTEXT   *DispatchContext
  )
{
  EFI_STATUS Status;

  if (mSetSmmVariableProtocolSmiAllowed)
  {
    // It is okay to use gBS->LocateProtocol here because
    // we are still in trusted execution.
  Status = gBS->LocateProtocol(&gEfiSmmVariableProtocolGuid,
                               NULL,
                               &mSmmVariable);

    ASSERT_EFI_ERROR(Status);

    // mSetSmmVariableProtocolSmiAllowed will prevent this function from
    // being executed more than 1 time.
    mSetSmmVariableProtocolSmiAllowed = FALSE;
  }

}

EFI_STATUS
SxSleepEntryCallBack (
  IN  EFI_HANDLE                    DispatchHandle,
  IN  EFI_SMM_SX_DISPATCH_CONTEXT   *DispatchContext
  )
/*++

Routine Description:

Arguments:

  DispatchHandle  - The handle of this callback, obtained when registering

  DispatchContext - The predefined context which contained sleep type and phase

Returns:

  EFI_SUCCESS           - Operation successfully performed

--*/
{
  EFI_STATUS              Status;

  Status = SaveRuntimeScriptTable (mSmst);
  if (EFI_ERROR(Status)) {
    return Status;
  }

  //
  // Workaround for S3 wake hang if C State is enabled
  //
  CpuSmmSxWorkAround();

  return EFI_SUCCESS;
}

VOID
CpuSmmSxWorkAround(
  )
{
  UINT64           MsrValue;

  MsrValue = AsmReadMsr64 (EFI_MSR_PMG_CST_CONFIG);

  if (MsrValue & B_EFI_MSR_PMG_CST_CONFIG_CST_CONTROL_LOCK) {
    //
    // Cannot do anything if the register is locked.
    //
    return;
  }

  if (MsrValue & B_EFI_MSR_PMG_CST_CONFIG_IO_MWAIT_REDIRECTION_ENABLE) {
    //
    // If C State enabled, disable it before going into S3
    // The MSR will be restored back during S3 wake
    //
    MsrValue &= ~B_EFI_MSR_PMG_CST_CONFIG_IO_MWAIT_REDIRECTION_ENABLE;
    AsmWriteMsr64 (EFI_MSR_PMG_CST_CONFIG, MsrValue);
  }
}

VOID
ClearP2PBusMaster(
  )
{
  UINT8             Command;
  UINT8             Index;

  for (Index = 0; Index < sizeof(mPciBm)/sizeof(EFI_PCI_BUS_MASTER); Index++) {
    Command = MmioRead8 (
                MmPciAddress (0,
                  DEFAULT_PCI_BUS_NUMBER_PCH,
                  mPciBm[Index].Device,
                  mPciBm[Index].Function,
                  PCI_COMMAND_OFFSET
                )
              );
    Command &= ~EFI_PCI_COMMAND_BUS_MASTER;
    MmioWrite8 (
      MmPciAddress (0,
        DEFAULT_PCI_BUS_NUMBER_PCH,
        mPciBm[Index].Device,
        mPciBm[Index].Function,
        PCI_COMMAND_OFFSET
      ),
      Command
    );
  }
}

VOID
SetAfterG3On (
  BOOLEAN Enable
  )
/*++

Routine Description:

  Set the AC Loss to turn on or off.

Arguments:

Returns:

  None

--*/
{
  UINT8             PmCon1;

  //
  // ICH handling portion
  //
  PmCon1 = MmioRead8 ( PMC_BASE_ADDRESS + R_PCH_PMC_GEN_PMCON_1 );
  PmCon1 &= ~B_PCH_PMC_GEN_PMCON_AFTERG3_EN;
  if (Enable) {
    PmCon1 |= B_PCH_PMC_GEN_PMCON_AFTERG3_EN;
  }
  MmioWrite8 (PMC_BASE_ADDRESS + R_PCH_PMC_GEN_PMCON_1, PmCon1);

}

VOID
PowerButtonCallback (
  IN  EFI_HANDLE                              DispatchHandle,
  IN  EFI_SMM_POWER_BUTTON_DISPATCH_CONTEXT   *DispatchContext
  )
/*++

Routine Description:

  When a power button event happens, it shuts off the machine

Arguments:

Returns:

  None

--*/
{
  //
  // Check what the state to return to after AC Loss. If Last State, then
  // set it to Off.
  //
  UINT16  data16;   

  if (mWakeOnRtcVariable) {
    EnableS5WakeOnRtc();
  }

  if (mAcLossVariable == 1) {
    SetAfterG3On (TRUE);
  }

  ClearP2PBusMaster();

  //
  // Program clock chip
  //
  S4S5ProgClock();

  
  data16 = (UINT16)(IoRead16(mAcpiBaseAddr + R_PCH_ACPI_GPE0a_EN));
  data16 &= B_PCH_ACPI_GPE0a_EN_PCI_EXP;
   
//  if ((mWakeOnLanS5Variable) && (data16 != 0)) { 
//    EnableS5WakeOnLan();
//  }
//
//#if (defined KEYBOARD_WAKE_FROM_S5_SETUP_SUPPORT) && KEYBOARD_WAKE_FROM_S5_SETUP_SUPPORT
//    EnableS5WakeFromKBC();
//#endif

  //
  // Clear Sleep SMI Status
  //
  IoWrite16 (mAcpiBaseAddr + R_PCH_SMI_STS,
                (UINT16)(IoRead16 (mAcpiBaseAddr + R_PCH_SMI_STS) | B_PCH_SMI_STS_ON_SLP_EN));
  //
  // Clear Sleep Type Enable
  //
  IoWrite16 (mAcpiBaseAddr + R_PCH_SMI_EN,
                (UINT16)(IoRead16 (mAcpiBaseAddr + R_PCH_SMI_EN) & (~B_PCH_SMI_EN_ON_SLP_EN)));

  //
  // Clear Power Button Status
  //
  IoWrite16(mAcpiBaseAddr + R_PCH_ACPI_PM1_STS, B_PCH_ACPI_PM1_STS_PWRBTN);

  //
  // Shut it off now!
  //
  IoWrite16(mAcpiBaseAddr + R_PCH_ACPI_PM1_CNT, V_PCH_ACPI_PM1_CNT_S5);
  IoWrite16(mAcpiBaseAddr + R_PCH_ACPI_PM1_CNT, B_PCH_ACPI_PM1_CNT_SLP_EN | V_PCH_ACPI_PM1_CNT_S5);

  //
  // Should not return
  //
  CpuDeadLoop();
}

VOID
PmeCallback (
  IN  EFI_HANDLE                              DispatchHandle,
  IN  EFI_SMM_ICHN_DISPATCH_CONTEXT           *DispatchContext
  )
/*++

Routine Description:

Arguments:

Returns:

  None

--*/
{
}

#if defined( ECC_SUPPORT ) && ( ECC_SUPPORT != 0 )
VOID
EccCallback (
  IN  EFI_HANDLE                              DispatchHandle,
  IN  EFI_SMM_ICHN_DISPATCH_CONTEXT           *DispatchContext
  )
/*++

Routine Description:

Arguments:

Returns:

  None

--*/
{
  EFI_STATUS            Status;
  UINT8                 Index;
  EFI_TIME              CurrentTime;
  UINTN                 Size;
  SYSTEM_CONFIGURATION  SystemConfiguration;
  UINT16                EccSmiCmd;
  UINT16                EccErrSts;
  EFI_EVENT_TYPE        EventType;
  UINT32                MemoryChannel;
  EFI_EVENT_LOG_STORE   mCurrentEventLogStore[] = {
  { (UINT8) EfiProcessorThermalTrip,  0xFFFFFFFF,  0x3F, 0xF, 0x1F, 0x1F, 0x3F, 0x3F },
  { (UINT8) EfiMultiBitECCErrorChA,   0xFFFFFFFF,  0x3F, 0xF, 0x1F, 0x1F, 0x3F, 0x3F },
  { (UINT8) EfiSingleBitECCErrorChA,  0xFFFFFFFF,  0x3F, 0xF, 0x1F, 0x1F, 0x3F, 0x3F },
  { (UINT8) EfiCmosBatteryFailure,    0xFFFFFFFF,  0x3F, 0xF, 0x1F, 0x1F, 0x3F, 0x3F },
  { (UINT8) EfiCmosChecksumError,     0xFFFFFFFF,  0x3F, 0xF, 0x1F, 0x1F, 0x3F, 0x3F },
  { (UINT8) EfiCmosTimerNotSet,       0xFFFFFFFF,  0x3F, 0xF, 0x1F, 0x1F, 0x3F, 0x3F },
  { (UINT8) EfiKeyboardNotFound,      0xFFFFFFFF,  0x3F, 0xF, 0x1F, 0x1F, 0x3F, 0x3F },
  { (UINT8) EfiMemorySizeDecrease,    0xFFFFFFFF,  0x3F, 0xF, 0x1F, 0x1F, 0x3F, 0x3F },
  { (UINT8) EfiIntruderDetection,     0xFFFFFFFF,  0x3F, 0xF, 0x1F, 0x1F, 0x3F, 0x3F },
  { (UINT8) EfiSpdTolerant,           0xFFFFFFFF,  0x3F, 0xF, 0x1F, 0x1F, 0x3F, 0x3F },
  { (UINT8) EfiMemOptiDual,           0xFFFFFFFF,  0x3F, 0xF, 0x1F, 0x1F, 0x3F, 0x3F },
  { (UINT8) EfiMemOptiSingle,         0xFFFFFFFF,  0x3F, 0xF, 0x1F, 0x1F, 0x3F, 0x3F },
  { (UINT8) EfiMultiBitECCErrorChB,   0xFFFFFFFF,  0x3F, 0xF, 0x1F, 0x1F, 0x3F, 0x3F },
  { (UINT8) EfiSingleBitECCErrorChB,  0xFFFFFFFF,  0x3F, 0xF, 0x1F, 0x1F, 0x3F, 0x3F },
  { (UINT8) EfiMeCh0Err,              0xFFFFFFFF,  0x3F, 0xF, 0x1F, 0x1F, 0x3F, 0x3F },
  { (UINT8) EfiMeInitFailure,         0xFFFFFFFF,  0x3F, 0xF, 0x1F, 0x1F, 0x3F, 0x3F },
  { (UINT8) EfiMeHeciCommError,       0xFFFFFFFF,  0x3F, 0xF, 0x1F, 0x1F, 0x3F, 0x3F },
  { (UINT8) EfiHeciInitError,         0xFFFFFFFF,  0x3F, 0xF, 0x1F, 0x1F, 0x3F, 0x3F },
  { (UINT8) EfiAtaSmartError,         0xFFFFFFFF,  0x3F, 0xF, 0x1F, 0x1F, 0x3F, 0x3F },
  { (UINT8) EfiAaNumberError,         0xFFFFFFFF,  0x3F, 0xF, 0x1F, 0x1F, 0x3F, 0x3F },
  { (UINT8) EfiMeEOPMsgError,         0xFFFFFFFF,  0x3F, 0xF, 0x1F, 0x1F, 0x3F, 0x3F }
 };

  EccSmiCmd = McD0PciCfg16( MC_REG_SMICMD );
  //
  // Check if SMI generation for ECC errors enabled
  //
  if(!((EccSmiCmd & BIT0) || (EccSmiCmd & BIT1))) {
    return;
  }

  EccErrSts = McD0PciCfg16( MC_REG_ERRSTS );
  //
  // Check if ECC errors generated
  //
  if(!((EccErrSts & BIT0) || (EccErrSts & BIT1))) {
    return;
  }

  //
  // Get memory channel where ECC error being generated
  //
  MemoryChannel = McD0PciCfg32 ( MC_REG_DEAP );

  //
  // If both single- and multi-bit ECC errors generated at the same time,
  // then handle multi-bit ECC error first
  //
  if (EccErrSts & BIT1) {
    //
    // Multi-bit ECC error
    //
    EventType = (MemoryChannel & BIT0) ? EfiMultiBitECCErrorChB : EfiMultiBitECCErrorChA;
  }
  else {
    //
    // Single-bit ECC error
    //
    EventType = (MemoryChannel & BIT0) ? EfiSingleBitECCErrorChB : EfiSingleBitECCErrorChA;
  }

  //
  // Make sure EFI_SMM_VARIABLE_PROTOCOL is available
  //
  if (!mSmmVariable) {
    //
    // Clear ECC error status
    //
    ClearEccErrSts(EventType);
    return;
  }

  Size = sizeof(SYSTEM_CONFIGURATION);
  //
  // Retrieve the Setup Configuration Variable from NVRAM
  //
  Status = mSmmVariable->SmmGetVariable (gEfiNormalSetupName,
                             &gEfiNormalSetupGuid,
                             NULL,
                             &Size,
                             &SystemConfiguration
                             );

  if (EFI_ERROR(Status) || SystemConfiguration.EventLogging == 0 ||
      SystemConfiguration.EccEventLogging == 0) {
    //
    // Clear ECC error status
    //
    ClearEccErrSts(EventType);
    return;
  }

  //
  // Get the current state of Events variable
  //
  Size = sizeof(mCurrentEventLogStore);
  Status = mSmmVariable->SmmGetVariable ((CHAR16 *)&gEventName,
                             &gEventNameGuid,
                             NULL,
                             &Size,
                             &mCurrentEventLogStore
                             );
  //
  // Continue even if the Events variable does not exist; we will
  // still use the default state of Events variable
  //

  for (Index = 0; Index < EfiMaximumEventType; Index++) {
    //
    // Find the event type entry in the local buffer
    //
    if (mCurrentEventLogStore[Index].Type == (UINT8) EventType) {
      //
      // Check if full
      //
      if (mCurrentEventLogStore[Index].Count == 0) {
        break;
      }

      //
      // Increment the Count by 1
      //
      mCurrentEventLogStore[Index].Count <<= 1;

      //
      // Create a time if this is the first time
      //
      if (mCurrentEventLogStore[Index].Time.Month == 0xF) {
        EfiSmmGetTime(&CurrentTime);
        if (CurrentTime.Year >= 2005) {
          mCurrentEventLogStore[Index].Time.Year    = (CurrentTime.Year - 2005);
          mCurrentEventLogStore[Index].Time.Month   = CurrentTime.Month;
          mCurrentEventLogStore[Index].Time.Day     = CurrentTime.Day;
          mCurrentEventLogStore[Index].Time.Hour    = CurrentTime.Hour;
          mCurrentEventLogStore[Index].Time.Minute  = CurrentTime.Minute;
          mCurrentEventLogStore[Index].Time.Second  = CurrentTime.Second;
        }
      }

      //
      // Set the event in the storage
      //
      Size = sizeof(mCurrentEventLogStore);
      Status = mSmmVariable->SetVariable ((CHAR16 *)&gEventName,
                                 &gEventNameGuid,
                                 EFI_VARIABLE_NON_VOLATILE | EFI_VARIABLE_BOOTSERVICE_ACCESS | EFI_VARIABLE_RUNTIME_ACCESS,
                                 Size,
                                 &mCurrentEventLogStore
                                 );
      break;
    }
  }

  //
  // Clear ECC error status
  //
  ClearEccErrSts(EventType);
}

VOID
ClearEccErrSts (
  IN  EFI_EVENT_TYPE  EventType
  )
/*++

Routine Description:

Arguments:

Returns:

  None

--*/
{
  if (EventType == EfiMultiBitECCErrorChA || EventType == EfiMultiBitECCErrorChB) {
    McD0PciCfg16And( MC_REG_ERRSTS, BIT1);

    //
    // For multi-bit ECC error, clear Port 70h bit 7 to enable all NMI sources
    //
    IoWrite8( 0x70, IoRead8( 0x74 ) & ~BIT7 );     // Port 70h is aliased to port 74h

    //
    // Now, generate an NMI (clear NMI2SMI_EN bit and then set NMI_NOW bit)
    //
    IoWrite16( mAcpiBaseAddr + R_PCH_TCO_CNT, IoRead16( mAcpiBaseAddr + R_PCH_TCO_CNT ) & ~B_NMI2SMI_EN );
    IoWrite16( mAcpiBaseAddr + R_PCH_TCO_CNT, IoRead16( mAcpiBaseAddr + R_PCH_TCO_CNT ) | B_NMI_NOW );
  }
  else {
    McD0PciCfg16And( MC_REG_ERRSTS, BIT0);
  }
}
#endif
/*R01 -s
VOID
RiCallback (
  IN  EFI_HANDLE                              DispatchHandle,
  IN  EFI_SMM_ICHN_DISPATCH_CONTEXT           *DispatchContext
  )
R01 -e*/
/*++

Routine Description:

Arguments:

Returns:

  None

--*/
/*R01 -s
{
  EnableWakeOnRi();

  return;
}
R01 -e*/

VOID
S5SleepAcLossCallBack (
  IN  EFI_HANDLE                    DispatchHandle,
  IN  EFI_SMM_SX_DISPATCH_CONTEXT   *DispatchContext
  )
/*++

Routine Description:

Arguments:

  DispatchHandle  - The handle of this callback, obtained when registering

  DispatchContext - The predefined context which contained sleep type and phase

Returns:

/*++

Routine Description:

Arguments:

Returns:

--*/
{
  //
  // Check what the state to return to after AC Loss. If Last State, then
  // set it to Off.
  //
  if (mAcLossVariable == 1) {
    SetAfterG3On (TRUE);
  }
}

VOID
S5SleepCapsuleCallBack (
  IN  EFI_HANDLE                    DispatchHandle,
  IN  EFI_SMM_SX_DISPATCH_CONTEXT   *DispatchContext
  )
/*++

Routine Description:

Arguments:

  DispatchHandle  - The handle of this callback, obtained when registering

  DispatchContext - The predefined context which contained sleep type and phase

Returns:

/*++

Routine Description:

Arguments:

Returns:

--*/
{
  EFI_STATUS            Status;
  UINTN                 CapsuleDataPtr;
  UINT8                 CmosData;
  UINT8                 CmosAddress;
  UINT32                Pm1Cnt;
  UINT32                TempData32;
  UINT8                 i;
  UINT8                 WakeupHour;
  UINT8                 WakeupMinute;
  UINT8                 WakeupSecond;
  BOOLEAN               MinuteIncrement;
  BOOLEAN               HourIncrement;
  BOOLEAN               UseRtcWorkaround;
  DMI_DATA              DmiDataVariable;
  UINTN                 Size;
  CHAR8                 BoardAaNumber[6];
  CHAR8                 BoardFabNumber[3];
  UINT8                 CurrentBoardFabNumber;
  BOOLEAN               FoundAANum;
  UINTN                 BoardIdIndex;

  CapsuleDataPtr = 0;
  MinuteIncrement = FALSE;
  HourIncrement = FALSE;
  UseRtcWorkaround = FALSE;
  FoundAANum = FALSE;

  ClearP2PBusMaster();

  //
  // Check if it is due to a capsule update
  //
  for (CmosAddress=EFI_CMOS_CAPSULE_ADDRESS_4; CmosAddress>=EFI_CMOS_CAPSULE_ADDRESS_1;CmosAddress--) {
    CapsuleDataPtr <<= 8;
    IoWrite8(PCAT_CMOS_2_ADDRESS_REGISTER, CmosAddress);
    CmosData = IoRead8(PCAT_CMOS_2_DATA_REGISTER);
    CapsuleDataPtr += (UINTN)CmosData;
  }

  if (CapsuleDataPtr) {
    //
    // Get board AA# and FAB# to determine if we need to use RTC alarm workaround or GPIO bounce back method.
    //
    Size = sizeof (DMI_DATA);
    SetMem(&DmiDataVariable, Size, 0xFF);
    Status = mSmmVariable->SmmGetVariable (
               DMI_DATA_NAME,
               &gDmiDataGuid,
               NULL,
               &Size,
               &DmiDataVariable
               );
    if (!EFI_ERROR (Status)) {
      CopyMem(&BoardAaNumber, ((((UINT8*)&DmiDataVariable.BaseBoardVersion)+2)), 6);
      for (BoardIdIndex = 0; BoardIdIndex < DefectiveBoardIdTableSize; BoardIdIndex++) {
        if (AsciiStrnCmp(DefectiveBoardIdTable[BoardIdIndex].BoardAaNumber, BoardAaNumber, 6) == 0) {
          //
          // Check if it's older FAB. Do workaround for older FAB.
          //
          CopyMem(&BoardFabNumber, ((((UINT8*)&DmiDataVariable.BaseBoardVersion)+2+7)), 3);
          CurrentBoardFabNumber = ((BoardFabNumber[0]&0x0F)*100) + ((BoardFabNumber[1]&0x0F)*10) + ((BoardFabNumber[2]&0x0F)*1);
          if (CurrentBoardFabNumber <= DefectiveBoardIdTable[BoardIdIndex].BoardFabNumber) {
            UseRtcWorkaround = TRUE;
          }
          FoundAANum = TRUE;
          break;
        }
      }

      if(!FoundAANum) {
        //
        // Add check for AA#'s that is programmed without the AA as leading chars.
        //
        CopyMem(&BoardAaNumber, (((UINT8*)&DmiDataVariable.BaseBoardVersion)), 6);
        for (BoardIdIndex = 0; BoardIdIndex < DefectiveBoardIdTableSize; BoardIdIndex++) {
          if (AsciiStrnCmp(DefectiveBoardIdTable[BoardIdIndex].BoardAaNumber, BoardAaNumber, 6) == 0) {
            //
            // Check if it's older FAB. Do workaround for older FAB.
            //
            CopyMem(&BoardFabNumber, ((((UINT8*)&DmiDataVariable.BaseBoardVersion)+7)), 3);
            CurrentBoardFabNumber = ((BoardFabNumber[0]&0x0F)*100) + ((BoardFabNumber[1]&0x0F)*10) + ((BoardFabNumber[2]&0x0F)*1);
            if (CurrentBoardFabNumber <= DefectiveBoardIdTable[BoardIdIndex].BoardFabNumber) {
              UseRtcWorkaround = TRUE;
            }
            FoundAANum = TRUE;
            break;
          }
        }
      }

      if (FoundAANum != TRUE) {
        UseRtcWorkaround = TRUE;
      }
    }

    if (!UseRtcWorkaround) {
      //
      // Generate automatic wake up. by toggling a GPIO to generate SMI wake up event
      // Enable GPIO14 to generate wake event
      //
      TempData32 = IoRead32(mAcpiBaseAddr + R_PCH_ACPI_GPE0a_EN);
      TempData32 |= 0x40000000;
      IoWrite32(mAcpiBaseAddr + R_PCH_ACPI_GPE0a_EN, TempData32);

    } else {
      //
      // WORKAROUND: This is a workaround to hardware issue where board circuit is not designed to take care
      //             of the S3-Hot condition that chipset not supported.
      //

      //
      // Iflash will have priority on RTC so override it!!
      //
      IoWrite8(PCAT_RTC_ADDRESS_REGISTER, RTC_ADDRESS_REGISTER_B);
      IoWrite8(PCAT_RTC_DATA_REGISTER, (IoRead8(PCAT_RTC_DATA_REGISTER) & ~B_RTC_ALARM_INT_ENABLE));

      //
      // Set Date for everyday
      //
      IoWrite8(PCAT_RTC_ADDRESS_REGISTER, RTC_ADDRESS_REGISTER_D);
      CmosData = IoRead8(PCAT_RTC_DATA_REGISTER);
      CmosData &= ~(B_RTC_DATE_ALARM_MASK);
      for(i = 0 ; i < 0xffff ; i++){
        IoWrite8(PCAT_RTC_DATA_REGISTER, CmosData);
        Stall(1);
        if((IoRead8(PCAT_RTC_DATA_REGISTER) & B_RTC_DATE_ALARM_MASK) == 0){
          break;
        }
      }

      //
      // Set Second for current + 2s
      //
      IoWrite8(PCAT_RTC_ADDRESS_REGISTER, RTC_ADDRESS_SECOND);
      WakeupSecond = IoRead8(PCAT_RTC_DATA_REGISTER);
      WakeupSecond = BcdToHex(WakeupSecond);
      if(!mSystemConfiguration.FlashSleepDelay)
        WakeupSecond += 2;
      else
        WakeupSecond += 20;
      if (WakeupSecond >= 60) {
        WakeupSecond -= 60;
        MinuteIncrement = TRUE;
      }
      WakeupSecond = HexToBcd(WakeupSecond);
      IoWrite8(PCAT_RTC_ADDRESS_REGISTER, RTC_ADDRESS_SECOND_ALARM);
      for(i = 0 ; i < 0xffff ; i++){
        IoWrite8(PCAT_RTC_DATA_REGISTER, WakeupSecond);
        Stall(1);
        if(IoRead8(PCAT_RTC_DATA_REGISTER) == WakeupSecond){
          break;
        }
      }

      //
      // Set Minute
      //
      IoWrite8(PCAT_RTC_ADDRESS_REGISTER, RTC_ADDRESS_MINUTE);
      WakeupMinute = IoRead8(PCAT_RTC_DATA_REGISTER);
      if (MinuteIncrement) {
        WakeupMinute = BcdToHex(WakeupMinute);
        WakeupMinute++;
        if (WakeupMinute >= 60) {
          WakeupMinute -= 60;
          HourIncrement = TRUE;
        }
        WakeupMinute = HexToBcd(WakeupMinute);
      }
      IoWrite8(PCAT_RTC_ADDRESS_REGISTER, RTC_ADDRESS_MINUTE_ALARM);
      for(i = 0 ; i < 0xffff ; i++){
        IoWrite8(PCAT_RTC_DATA_REGISTER, WakeupMinute);
        Stall(1);
        if(IoRead8(PCAT_RTC_DATA_REGISTER) == WakeupMinute){
          break;
        }
      }

      //
      // Set Hour
      //
      IoWrite8(PCAT_RTC_ADDRESS_REGISTER, RTC_ADDRESS_HOUR);
      WakeupHour = IoRead8(PCAT_RTC_DATA_REGISTER);
      if (HourIncrement) {
        WakeupHour = BcdToHex(WakeupHour);
        WakeupHour++;
        if (WakeupHour >= 24) {
          WakeupHour -= 24;
        }
        WakeupHour = HexToBcd(WakeupHour);
      }
      IoWrite8(PCAT_RTC_ADDRESS_REGISTER, RTC_ADDRESS_HOUR_ALARM);
      for(i = 0 ; i < 0xffff ; i++){
        IoWrite8(PCAT_RTC_DATA_REGISTER, WakeupHour);
        Stall(1);
        if(IoRead8(PCAT_RTC_DATA_REGISTER) == WakeupHour){
          break;
        }
      }

      //
      // Wait for UIP to arm RTC alarm
      //
      IoWrite8(PCAT_RTC_ADDRESS_REGISTER, RTC_ADDRESS_REGISTER_A);
      while (IoRead8(PCAT_RTC_DATA_REGISTER) & 0x80);

      //
      // Read RTC register 0C to clear pending RTC interrupts
      //
      IoWrite8(PCAT_RTC_ADDRESS_REGISTER, RTC_ADDRESS_REGISTER_C);
      IoRead8(PCAT_RTC_DATA_REGISTER);

      //
      // Enable RTC Alarm Interrupt
      //
      IoWrite8(PCAT_RTC_ADDRESS_REGISTER, RTC_ADDRESS_REGISTER_B);
      IoWrite8(PCAT_RTC_DATA_REGISTER, IoRead8(PCAT_RTC_DATA_REGISTER) | B_RTC_ALARM_INT_ENABLE);

      //
      // Clear ICH RTC Status
      //
      IoWrite16(mAcpiBaseAddr + R_PCH_ACPI_PM1_STS, B_PCH_ACPI_PM1_STS_RTC);

      //
      // Enable ICH RTC event
      //
      IoWrite16(mAcpiBaseAddr + R_PCH_ACPI_PM1_EN,
                  (UINT16)(IoRead16(mAcpiBaseAddr + R_PCH_ACPI_PM1_EN) | B_PCH_ACPI_PM1_EN_RTC));

      //
      // Note: No need to disarm the RTC alarm interrupt after RTC event fired as this will be done at Platform DXE driver.
      //
    }

    //
    // Change the S5 to an S3
    //
    Pm1Cnt = IoRead32(mAcpiBaseAddr + R_PCH_ACPI_PM1_CNT);
    Pm1Cnt &= (~0x1c00);
    Pm1Cnt |= 0x1400;
    IoWrite32(mAcpiBaseAddr + R_PCH_ACPI_PM1_CNT, Pm1Cnt);
  }
}

//VOID
//S5SleepWakeOnLanCallBack (
//  IN  EFI_HANDLE                    DispatchHandle,
//  IN  EFI_SMM_SX_DISPATCH_CONTEXT   *DispatchContext
//  )
///*++
//
//Routine Description:
//
//Arguments:
//
//  DispatchHandle  - The handle of this callback, obtained when registering
//
//  DispatchContext - The predefined context which contained sleep type and phase
//
//Returns:
//
//--*/
//{
 
//  UINT16    data16;
//
 
//  PchMmPci32And( 0, DEFAULT_PCI_BUS_NUMBER_PCH, PCI_DEVICE_NUMBER_PCH_PCIE_ROOT_PORTS, PCI_FUNCTION_NUMBER_PCH_PCIE_ROOT_PORT_1, R_PCH_PCIE_MPC, ~B_PCH_PCIE_MPC_PMCE);
//  PchMmPci32Or( 0, DEFAULT_PCI_BUS_NUMBER_PCH, PCI_DEVICE_NUMBER_PCH_PCIE_ROOT_PORTS, PCI_FUNCTION_NUMBER_PCH_PCIE_ROOT_PORT_1, R_PCH_PCIE_SMSCS, B_PCH_PCIE_SMSCS_PMCS);
 
//  data16 = (UINT16)(IoRead16(mAcpiBaseAddr + R_PCH_ACPI_GPE0a_EN));
//  data16 &= B_PCH_ACPI_GPE0a_EN_PCI_EXP;
 
//
//  if (data16 !=0) { 
//    EnableS5WakeOnLan();
//  }                 
//}

//VOID
//EnableS5WakeOnLan()
///*++
//
//Routine Description:
//
//Arguments:
//
//Returns:
//
//  1. For each LAN present,
//     clear LAN PCI PME Status (if set) & Enable LAN PCI PME Register
//  2. Clear ICH Status
//  3. Enable ICH/PmBase
//
//--*/
//{
//  UINT16            PmCsr;
//  UINT8             SecondBus;
//  UINT8             PmCap;
////  UINT32            Data32;
//  UINT32            Data32;  
//  UINT8             Device;
//  UINT8             Function;
//  UINTN             PciLanInfoSize;
//  EFI_STATUS        Status;
//  PCI_LAN_INFO      PciLanInfo[6],
//                    *x;
//  UINT8             Data;
//  UINT8             PcieCmd;
//  UINT8             PciePmcs;
//  UINT8             LanPmcs;
//  UINT16            BaseAdd;
//
//  //
//  // Temporary enable Realtek LAN pci config space.
//  // Enable Bus Master, Memory Space, and I/O Space of PCIe.
//  //
//  Data = PchMmPci8( 0, DEFAULT_PCI_BUS_NUMBER_PCH, PCI_DEVICE_NUMBER_PCH_PCIE_ROOT_PORTS, PCI_FUNCTION_NUMBER_PCH_PCIE_ROOT_PORT_1, R_PCH_PCIE_CMD_PSTS );
//
//  PcieCmd = Data;
//  Data |= (B_PCH_PCIE_CMD_PSTS_BME | B_PCH_PCIE_CMD_PSTS_MSE | B_PCH_PCIE_CMD_PSTS_IOSE);
//  PchMmPci8( 0, DEFAULT_PCI_BUS_NUMBER_PCH, PCI_DEVICE_NUMBER_PCH_PCIE_ROOT_PORTS, PCI_FUNCTION_NUMBER_PCH_PCIE_ROOT_PORT_1, R_PCH_PCIE_CMD_PSTS ) = Data;
//
//  //
//  // Set PCIe power state to D0.
//  //
//  Data = PchMmPci8( 0, DEFAULT_PCI_BUS_NUMBER_PCH, PCI_DEVICE_NUMBER_PCH_PCIE_ROOT_PORTS, PCI_FUNCTION_NUMBER_PCH_PCIE_ROOT_PORT_1, R_PCH_PCIE_PMCS );
//  PciePmcs = Data;
//  Data &= ~(B_PCH_PCIE_PMCS_PS);
//  PchMmPci8( 0, DEFAULT_PCI_BUS_NUMBER_PCH, PCI_DEVICE_NUMBER_PCH_PCIE_ROOT_PORTS, PCI_FUNCTION_NUMBER_PCH_PCIE_ROOT_PORT_1, R_PCH_PCIE_PMCS ) = Data;
//
//
//  // make sure EFI_SMM_VARIABLE_PROTOCOL is available
//  if (!mSmmVariable) {
//    return;
//  }
//
//  // determine the size of the variable's data
//  PciLanInfoSize = 0;
//  mSmmVariable->SmmGetVariable(L"PciLanInfo",
//                            &gEfiPciLanInfoGuid,
//                            NULL,
//                            &PciLanInfoSize,
//                            NULL
//                            );
//
//  // read the variable into the buffer
//  Status = mSmmVariable->SmmGetVariable(L"PciLanInfo",
//                                     &gEfiPciLanInfoGuid,
//                                     NULL,
//                                     &PciLanInfoSize,
//                                     PciLanInfo
//                                     );
//  if (EFI_ERROR(Status)) {
//    return;
//  }
//
//  if ( PciLanInfoSize != 0 ) {
//    for (x = PciLanInfo; x < (PciLanInfo + (PciLanInfoSize / sizeof(PCI_LAN_INFO))); x++) {
//
//      SecondBus = x->PciBus;
//      Device = x->PciDevice;
//      Function = x->PciFunction;
//
//      //
//      // Read PCI Capabilities
//      //
//      PmCap = PchMmPci8( 0, SecondBus, Device, Function, R_PCH_LAN_CAP_PTR);
//
//      //
//      // Check  INTEL Gbe LAN vendor ID and device ID.
//      //
 
//      if ( PchMmPci16( 0, SecondBus, Device, Function, R_PCH_LAN_VENDOR_ID) == V_PCH_LAN_VENDOR_ID &&
//                  (PchMmPci16( 0, SecondBus, Device, Function, R_PCH_LAN_DEVICE_ID) == V_PCH_LAN_DEVICE_ID_0 )) {
//      
//      BaseAdd = PchMmPci16( 0, SecondBus, Device, Function, 0x10);
//        BaseAdd &= 0xFFFE;
//
//        //
//        // Set INTEL Gbe LAN power state to D0.
//        //
//        Data = PchMmPci8( 0, SecondBus, Device, Function, PmCap + 0x04);
//        LanPmcs = Data;
//        Data &= 0xFC;
//        PchMmPci8( 0, SecondBus, Device, Function, PmCap + 0x04) = Data;
//
//        //
//        // Enable INTEL Gbe LAN Wake signal offset 56h bit1 .
//        //
//        IoWrite8((BaseAdd + 0x56), (IoRead8(BaseAdd + 0x56) | 0x02));
//
//        //
//        // Restore INTEL Gbe LAN power state.
//        //
//        PchMmPci8( 0, SecondBus, Device, Function, PmCap + 0x04) = LanPmcs;
   
//
//        //
//        // Clear LAN PME Status & enable LAN PME
//        //
//        PmCsr = PchMmPci16Or( 0, SecondBus, Device, Function, PmCap + 0x04,
//                           (B_PCH_LAN_PMCS_PMES + B_PCH_LAN_PMCS_PMEE));
//      }  
//    }
//  }
//
//  //
//  // Restore PCIe power state.
//  //
//  PchMmPci8( 0, DEFAULT_PCI_BUS_NUMBER_PCH, PCI_DEVICE_NUMBER_PCH_PCIE_ROOT_PORTS, PCI_FUNCTION_NUMBER_PCH_PCIE_ROOT_PORT_1, R_PCH_PCIE_PMCS ) = PciePmcs;
//
//  //
//  // Restore Bus Master, Memory Space, and I/O Space of PCIe.
//  //
//  PchMmPci8( 0, DEFAULT_PCI_BUS_NUMBER_PCH, PCI_DEVICE_NUMBER_PCH_PCIE_ROOT_PORTS, PCI_FUNCTION_NUMBER_PCH_PCIE_ROOT_PORT_1, R_PCH_PCIE_CMD_PSTS ) = PcieCmd;
//
//  //
//  // Read ICH GPIO level register
//  //
//  //Data32 = IoRead32 (GPIO_BASE_ADDRESS + R_ICH_GPIO_LVL);
//  Data32 = IoRead32 (GPIO_BASE_ADDRESS + R_PCH_GPIO_SC_LVL);  
//
//  //
//  // Disable Realtek LAN
//  //
//  //Data32 &= ~BIT6;
 
//  Data32 &= ~BIT9;
//  Data32 &= ~BIT10;
 
//
//  //
//  // Write ICH GPIO level register
//  //
//  //HfIoWrite32(GPIO_BASE_ADDRESS + R_ICH_GPIO_LVL, Data32);
//  IoWrite32(GPIO_BASE_ADDRESS + R_PCH_GPIO_SC_LVL, Data32);  
//
//  //
//  // Clear ICH PME Status
//  //
//  IoWrite16(mAcpiBaseAddr + R_PCH_ACPI_GPE0a_STS, B_PCH_ACPI_GPE0a_STS_PME_B0);
//
//  //
//  // Enable ICH PME
//  //
//  IoWrite16(mAcpiBaseAddr + R_PCH_ACPI_GPE0a_EN,
//              (UINT16)(IoRead16(mAcpiBaseAddr + R_PCH_ACPI_GPE0a_EN) | B_PCH_ACPI_GPE0a_EN_PME_B0));
//
//  //
//  // BUGBUG assuming SLP_LAN has replaced WOL_EN signal.
//  // BUGBUG need more investigation. SLP_LAN is gpio29 so changed the gpio9 to gpio29 below.
//  //
//  // BUGBUG OLD comments:Set GPIO (WOL_ONLY pin) to 1 to enable Wake On LAN
//  // BUGBUG OLD comments: This is only apply for non-ME sku
//  //
////  Data32 = IoRead32 (GPIO_BASE_ADDRESS + R_ICH_GPIO_LVL);
////  Data32 |= BIT29;
////  IoWrite32(GPIO_BASE_ADDRESS + R_ICH_GPIO_LVL, Data32);
//
//   
//  Data32 = IoRead32 (GPIO_BASE_ADDRESS + R_PCH_GPIO_SC_LVL);
//  Data32 |= BIT9 + BIT10;
//  IoWrite32(GPIO_BASE_ADDRESS + R_PCH_GPIO_SC_LVL, Data32);
//   
//}

VOID
S4S5CallBack (
  IN  EFI_HANDLE                    DispatchHandle,
  IN  EFI_SMM_SX_DISPATCH_CONTEXT   *DispatchContext
  )
/*++

Routine Description:

Arguments:

  DispatchHandle  - The handle of this callback, obtained when registering

  DispatchContext - The predefined context which contained sleep type and phase

Returns:

  Clears the Save State bit in the clock.

--*/
{
 
  UINT32        Data32;

  //
  // Enable/Disable USB Charging
  //
  if (mSystemConfiguration.UsbCharging == 0x01) {
    Data32 = IoRead32 (GPIO_BASE_ADDRESS + R_PCH_GPIO_SC_LVL);
    Data32 |= BIT8;
    IoWrite32(GPIO_BASE_ADDRESS + R_PCH_GPIO_SC_LVL, Data32);
  }
  
}


VOID
S4S5ProgClock()
{
}

VOID
EnableAcpiCallback (
  IN  EFI_HANDLE                    DispatchHandle,
  IN  EFI_SMM_SW_DISPATCH_CONTEXT   *DispatchContext
  )
/*++

Routine Description:
  SMI handler to enable ACPI mode

  Dispatched on reads from APM port with value 0xA0

  Disables the SW SMI Timer.
  ACPI events are disabled and ACPI event status is cleared.
  SCI mode is then enabled.

   Disable SW SMI Timer

   Clear all ACPI event status and disable all ACPI events
   Disable PM sources except power button
   Clear status bits

   Disable GPE0 sources
   Clear status bits

   Disable GPE1 sources
   Clear status bits

   Guarantee day-of-month alarm is invalid (ACPI 5.0 Section 4.8.2.4 "Real Time Clock Alarm")

   Enable SCI

Arguments:
  DispatchHandle  - EFI Handle
  DispatchContext - Pointer to the EFI_SMM_SW_DISPATCH_CONTEXT

Returns:
  Nothing

--*/
{
  UINT32 SmiEn;
  UINT16 Pm1Cnt;
  UINT16 wordValue;
  UINT32 RegData32;

  //
  // Disable SW SMI Timer
  //
  SmiEn = IoRead32(mAcpiBaseAddr + R_PCH_SMI_EN);
  SmiEn &= ~B_PCH_SMI_STS_SWSMI_TMR;
  IoWrite32(mAcpiBaseAddr + R_PCH_SMI_EN, SmiEn);

  wordValue = IoRead16(mAcpiBaseAddr + R_PCH_ACPI_PM1_STS);
  if(wordValue & B_PCH_ACPI_PM1_STS_WAK) {
	  IoWrite32((mAcpiBaseAddr + R_PCH_ACPI_GPE0a_EN), 0x0000);
	  IoWrite32((mAcpiBaseAddr + R_PCH_ACPI_GPE0a_STS), 0xffffffff);
  }
  else {
		mPM1_SaveState16 = IoRead16(mAcpiBaseAddr + R_PCH_ACPI_PM1_EN);
		//
		// Disable PM sources except power button
		//
  // power button is enabled only for PCAT. Disabled it on Tablet platform
        IoWrite16(mAcpiBaseAddr + R_PCH_ACPI_PM1_EN, B_PCH_ACPI_PM1_EN_PWRBTN);
		IoWrite16(mAcpiBaseAddr + R_PCH_ACPI_PM1_STS, 0xffff);

		mGPE_SaveState32 = IoRead16(mAcpiBaseAddr + R_PCH_ACPI_GPE0a_EN);
		IoWrite32(mAcpiBaseAddr + R_PCH_ACPI_GPE0a_EN, 0x0000);
		IoWrite32(mAcpiBaseAddr + R_PCH_ACPI_GPE0a_STS, 0xffffffff);
		
  }
  
  //
  // Guarantee day-of-month alarm is invalid (ACPI 5.0 Section 4.8.2.4 "Real Time Clock Alarm")
  // Clear Status D reg VM bit, Date of month Alarm to make Data in CMOS RAM is no longer Valid
  //
  IoWrite8 (PCAT_RTC_ADDRESS_REGISTER, RTC_ADDRESS_REGISTER_D);
  IoWrite8 (PCAT_RTC_DATA_REGISTER, 0x0);

  #if 0 //sli19 no EC
  InitializeKscLib ();
  // Disable APM/SMI mode
  SendKscCommand (KSC_C_SMI_NOTIFY_DISABLE);
  #endif

	RegData32 = IoRead32(ACPI_BASE_ADDRESS + R_PCH_ALT_GP_SMI_EN);
	RegData32 &= ~(BIT7);
    IoWrite32((ACPI_BASE_ADDRESS + R_PCH_ALT_GP_SMI_EN), RegData32); 

  #if 0 //sli19 no EC

  // Enable EC ACPI/SCI mode
  SendKscCommand (KSC_C_SMI_DISABLE);
  SendKscCommand (KSC_C_ACPI_ENABLE);  
  #endif

  //
  // Enable SCI
  //
  Pm1Cnt = IoRead16(mAcpiBaseAddr + R_PCH_ACPI_PM1_CNT);
  Pm1Cnt |= B_PCH_ACPI_PM1_CNT_SCI_EN;
  IoWrite16(mAcpiBaseAddr + R_PCH_ACPI_PM1_CNT, Pm1Cnt);


}

VOID
DisableAcpiCallback (
  IN  EFI_HANDLE                    DispatchHandle,
  IN  EFI_SMM_SW_DISPATCH_CONTEXT   *DispatchContext
  )
/*++

Routine Description:
  SMI handler to disable ACPI mode

  Dispatched on reads from APM port with value 0xA1

  ACPI events are disabled and ACPI event status is cleared.
  SCI mode is then disabled.
   Clear all ACPI event status and disable all ACPI events
   Disable PM sources except power button
   Clear status bits
   Disable GPE0 sources
   Clear status bits
   Disable GPE1 sources
   Clear status bits
   Disable SCI

Arguments:
  DispatchHandle  - EFI Handle
  DispatchContext - Pointer to the EFI_SMM_SW_DISPATCH_CONTEXT

Returns:
  Nothing

--*/
{
  UINT16 Pm1Cnt;

  IoWrite16(mAcpiBaseAddr + R_PCH_ACPI_PM1_STS, 0xffff);
  IoWrite16(mAcpiBaseAddr + R_PCH_ACPI_PM1_EN, mPM1_SaveState16);
  
  IoWrite32(mAcpiBaseAddr + R_PCH_ACPI_GPE0a_STS, 0xffffffff);
  IoWrite32(mAcpiBaseAddr + R_PCH_ACPI_GPE0a_EN, mGPE_SaveState32);

#if 0 //sli19 no EC

  InitializeKscLib ();
  // Disable ACPI/SCI mode
  SendKscCommand (KSC_C_ACPI_DISABLE);  
#endif
  //
  // Disable SCI
  //
  Pm1Cnt = IoRead16(mAcpiBaseAddr + R_PCH_ACPI_PM1_CNT);
  Pm1Cnt &= ~B_PCH_ACPI_PM1_CNT_SCI_EN;
  IoWrite16(mAcpiBaseAddr + R_PCH_ACPI_PM1_CNT, Pm1Cnt);

}


VOID
DummyTco1Callback (
  IN  EFI_HANDLE                              DispatchHandle,
  IN  EFI_SMM_ICHN_DISPATCH_CONTEXT           *DispatchContext
  )
/*++

Routine Description:

  When an unknown event happen.

Arguments:

Returns:

  None

--*/
{
}

UINTN
DevicePathSize (
  IN EFI_DEVICE_PATH_PROTOCOL  *DevicePath
  )
{
  EFI_DEVICE_PATH_PROTOCOL     *Start;

  if (DevicePath == NULL) {
    return 0;
  }

  //
  // Search for the end of the device path structure
  //
  Start = DevicePath;
  while (!IsDevicePathEnd (DevicePath)) {
    DevicePath = NextDevicePathNode (DevicePath);
  }

  //
  // Compute the size and add back in the size of the end device path structure
  //
  return ((UINTN)DevicePath - (UINTN)Start) + sizeof(EFI_DEVICE_PATH_PROTOCOL);
}

VOID
S5SleepWakeOnRtcCallBack (
  IN  EFI_HANDLE                    DispatchHandle,
  IN  EFI_SMM_SX_DISPATCH_CONTEXT   *DispatchContext
  )
/*++

Routine Description:

Arguments:

  DispatchHandle  - The handle of this callback, obtained when registering

  DispatchContext - The predefined context which contained sleep type and phase

Returns:

--*/
{
  EnableS5WakeOnRtc();
}

VOID
EnableS5WakeOnRtc()
/*++

Routine Description:

Arguments:

Returns:

  1. Check Alarm interrupt is not set.
  2. Clear Alarm interrupt.
  2. Set RTC wake up date and time.
  2. Enable RTC wake up alarm.
  3. Enable ICH PM1 EN Bit 10(RTC_EN)

--*/
{
  UINT8             CmosData;
  UINTN             i;
  EFI_STATUS        Status;
  UINTN             VarSize;

  // make sure EFI_SMM_VARIABLE_PROTOCOL is available
  if (!mSmmVariable) {
    return;
  }

  VarSize = sizeof(SYSTEM_CONFIGURATION);

  // read the variable into the buffer
  Status = mSmmVariable->SmmGetVariable(L"Setup",
                                     &gEfiSetupVariableGuid,
                                     NULL,
                                     &VarSize,
                                     &mSystemConfiguration
                                     );
  if (EFI_ERROR(Status) || (!mSystemConfiguration.WakeOnRtcS5)) {
    return;
  }
  mWakeupDay = HexToBcd((UINT8)mSystemConfiguration.RTCWakeupDate);
  mWakeupHour = HexToBcd((UINT8)mSystemConfiguration.RTCWakeupTimeHour);
  mWakeupMinute = HexToBcd((UINT8)mSystemConfiguration.RTCWakeupTimeMinute);
  mWakeupSecond = HexToBcd((UINT8)mSystemConfiguration.RTCWakeupTimeSecond);

  //
  // Check RTC alarm interrupt is enabled.  If enabled, someone already
  // grabbed RTC alarm.  Just return.
  //
  IoWrite8(PCAT_RTC_ADDRESS_REGISTER, RTC_ADDRESS_REGISTER_B);
  if(IoRead8(PCAT_RTC_DATA_REGISTER) & B_RTC_ALARM_INT_ENABLE){
    return;
  }

  //
  // Set Date
  //
  IoWrite8(PCAT_RTC_ADDRESS_REGISTER, RTC_ADDRESS_REGISTER_D);
  CmosData = IoRead8(PCAT_RTC_DATA_REGISTER);
  CmosData &= ~(B_RTC_DATE_ALARM_MASK);
  CmosData |= mWakeupDay ;
  for(i = 0 ; i < 0xffff ; i++){
    IoWrite8(PCAT_RTC_DATA_REGISTER, CmosData);
    Stall(1);
    if(((CmosData = IoRead8(PCAT_RTC_DATA_REGISTER)) & B_RTC_DATE_ALARM_MASK)
         == mWakeupDay){
      break;
    }
  }

  //
  // Set Second
  //
  IoWrite8(PCAT_RTC_ADDRESS_REGISTER, RTC_ADDRESS_SECOND_ALARM);
  for(i = 0 ; i < 0xffff ; i++){
    IoWrite8(PCAT_RTC_DATA_REGISTER, mWakeupSecond);
    Stall(1);
    if(IoRead8(PCAT_RTC_DATA_REGISTER) == mWakeupSecond){
      break;
    }
  }

  //
  // Set Minute
  //
  IoWrite8(PCAT_RTC_ADDRESS_REGISTER, RTC_ADDRESS_MINUTE_ALARM);
  for(i = 0 ; i < 0xffff ; i++){
    IoWrite8(PCAT_RTC_DATA_REGISTER, mWakeupMinute);
    Stall(1);
    if(IoRead8(PCAT_RTC_DATA_REGISTER) == mWakeupMinute){
      break;
    }
  }

  //
  // Set Hour
  //
  IoWrite8(PCAT_RTC_ADDRESS_REGISTER, RTC_ADDRESS_HOUR_ALARM);
  for(i = 0 ; i < 0xffff ; i++){
    IoWrite8(PCAT_RTC_DATA_REGISTER, mWakeupHour);
    Stall(1);
    if(IoRead8(PCAT_RTC_DATA_REGISTER) == mWakeupHour){
      break;
    }
  }

  //
  // Wait for UIP to arm RTC alarm
  //
  IoWrite8(PCAT_RTC_ADDRESS_REGISTER, RTC_ADDRESS_REGISTER_A);
  while (IoRead8(PCAT_RTC_DATA_REGISTER) & 0x80);

  //
  // Read RTC register 0C to clear pending RTC interrupts
  //
  IoWrite8(PCAT_RTC_ADDRESS_REGISTER, RTC_ADDRESS_REGISTER_C);
  IoRead8(PCAT_RTC_DATA_REGISTER);

  //
  // Enable RTC Alarm Interrupt
  //
  IoWrite8(PCAT_RTC_ADDRESS_REGISTER, RTC_ADDRESS_REGISTER_B);
  IoWrite8(PCAT_RTC_DATA_REGISTER, IoRead8(PCAT_RTC_DATA_REGISTER) | B_RTC_ALARM_INT_ENABLE);

  //
  // Clear ICH RTC Status
  //
  IoWrite16(mAcpiBaseAddr + R_PCH_ACPI_PM1_STS, B_PCH_ACPI_PM1_STS_RTC);

  //
  // Enable ICH RTC event
  //
  IoWrite16(mAcpiBaseAddr + R_PCH_ACPI_PM1_EN,
              (UINT16)(IoRead16(mAcpiBaseAddr + R_PCH_ACPI_PM1_EN) | B_PCH_ACPI_PM1_EN_RTC));
}

UINT8
HexToBcd(
  IN UINT8 HexValue
  )
{
  UINTN   HighByte;
  UINTN   LowByte;

  HighByte    = (UINTN)HexValue / 10;
  LowByte     = (UINTN)HexValue % 10;

  return ((UINT8)(LowByte + (HighByte << 4)));
}

UINT8
BcdToHex(
  IN UINT8 BcdValue
  )
{
  UINTN   HighByte;
  UINTN   LowByte;

  HighByte    = (UINTN)((BcdValue >> 4) * 10);
  LowByte     = (UINTN)(BcdValue & 0x0F);

  return ((UINT8)(LowByte + HighByte));
}

/*+
VOID
WaitForMdiTransactionComplete(
  IN       UINT32   Data32,
  IN OUT   BOOLEAN  *ReadyBitSet
  )
{
  UINT8    Trial;

  for (Trial=0; Trial<128; Trial++){
    //
    // Check if MDI transaction completed.
    //
    if( ((Mmio32(Data32, R_ICH_LAN_MDIC)) & R_ICH_LAN_MDIC_READY_BIT) == R_ICH_LAN_MDIC_READY_BIT ){
      *ReadyBitSet = TRUE;
      break;
    }
    //
    // Wait for 2ms.
    //
    Stall (2000);
  }
}
-*/
/*R01 -s
VOID
EnableWakeOnRi(
  )
{

  //
  // Clear ICH RI Status
  //
  HfIoWrite16(mAcpiBaseAddr + R_ICH_ACPI_GPE0a_STS, B_ICH_ACPI_GPE0a_STS_RI);

  //
  // Enable ICH RI
  //
  HfIoWrite16(mAcpiBaseAddr + R_ICH_ACPI_GPE0a_EN,
              (UINT16)(HfIoRead16(mAcpiBaseAddr + R_ICH_ACPI_GPE0a_EN) | B_ICH_ACPI_GPE0a_EN_RI));

  return;
}
R01 -e*/
#if (defined KEYBOARD_WAKE_FROM_S5_SETUP_SUPPORT) && KEYBOARD_WAKE_FROM_S5_SETUP_SUPPORT
VOID
S5Ps2WakeFromKbcSxCallBack(
  IN  EFI_HANDLE                    DispatchHandle,
  IN  EFI_SMM_SX_DISPATCH_CONTEXT   *DispatchContext
  )
/*++

Routine Description:
  This routine is called for soft off.

Arguments:

Returns:

--*/
{
  EnableS5WakeFromKBC();
}
#endif

#if (defined KEYBOARD_WAKE_FROM_S5_SETUP_SUPPORT) && KEYBOARD_WAKE_FROM_S5_SETUP_SUPPORT
VOID
EnableS5WakeFromKBC()
/*++

Routine Description:
  This routine enabled keyboard specific key wake from S5 function.
  This routine is triggered when system is shutting down to S5.

Arguments:

Returns:

--*/
{
  UINT8              KBCstatus;
  UINT32             TimeOutkbc;
  UINT8              R_Times;
  UINT32             Temp32;
  UINT8              Temp8;
  UINTN              Index;
  EFI_KEY_SEQUENCE   *ScancodeTable;
  UINTN              ScancodeTableSize;

  //
  // Reset the keyboard device - 10 times for proper reset
  //
  R_Times = 0;
  for ( R_Times=0 ; R_Times <= 10; R_Times ++ ) {
    IoWrite8 (0x60, 0xFF);
    TimeOutkbc=0;
    for ( TimeOutkbc = 0; TimeOutkbc < 65536; TimeOutkbc += 30 ) {
      KBCstatus = IoRead8 (0x60);
      if ( KBCstatus == 0xFA ) {
        break;
      }
    }
  }

  //
  // Enter SIO configuration mode
  //
  IoWrite8(INDEX_PORT, 0x87);
  IoWrite8(INDEX_PORT, 0x87);

  //
  // Check if this is Wpc83627DHG
  //
  IoWrite8(INDEX_PORT, REG_DEVICE_ID);
  if (IoRead8(DATA_PORT) != SIO_W83627DHG) {
    return;
  }

  //
  // Select ACPI logical device
  //
  IoWrite8(INDEX_PORT, REG_LOGICAL_DEVICE);
  IoWrite8(DATA_PORT, SIO_ACPI);

  IoWrite8(INDEX_PORT, ACPI_WAKEUP_EN);
  Temp8 = IoRead8(DATA_PORT);
  Temp8 &= ~(BIT7|BIT5|BIT1|BIT0);
  if(mWakeOnS5KeyboardVariable) {
    Temp8 |= (BIT6);
  } else {
    Temp8 &= ~(BIT6);
  }
  IoWrite8(DATA_PORT, Temp8);

//  //
//  // Disable keyboard wakeup event from S1/S2 and following CRE0 bit 0 setting
//  //
//  IoWrite8(INDEX_PORT, ACPI_POWER_CONTROL);
//  Temp8 = HfIoRead8(DATA_PORT);
//  Temp8 &= ~(BIT3 | BIT2);
//  IoWrite8(DATA_PORT, Temp8);

  //
  // Set specific wake key
  //   Key set 1 index range: 0x00 - 0x0E
  //   Key set 2 index range: 0x30 - 0x3E
  //   Key set 3 index range: 0x40 - 0x4E
  //
  ScancodeTable = NULL;
  ScancodeTableSize = 0;
  if (mWakeOnS5KeyboardVariable == 0x01){
    ScancodeTable = S5WakePowerKeySequence;
    ScancodeTableSize = S5WakePowerKeySequenceCount;
  } else if (mWakeOnS5KeyboardVariable == 0x02){
    ScancodeTable = S5WakeAltPrintScreenSequence;
    ScancodeTableSize = S5WakeAltPrintScreenSequenceCount;
  }
  if (ScancodeTable != NULL) {
    for (Index = 0; Index < ScancodeTableSize; Index++) {
      IoWrite8(INDEX_PORT, ACPI_KBC_WAKE_INDEX);
      IoWrite8(DATA_PORT, ScancodeTable[Index].CRE1Data);
      IoWrite8(INDEX_PORT, ACPI_KBC_WAKE_DATA);
      IoWrite8(DATA_PORT, ScancodeTable[Index].CRE2Data);
    }
  }

  //
  // Clear all status registers
  //
//  IoWrite8(INDEX_PORT, ACPI_WAK_STS);
  IoWrite8(INDEX_PORT, ACPI_WAKE_STS);
  IoWrite8(DATA_PORT, IoRead8(DATA_PORT));
  IoWrite8(INDEX_PORT, ACPI_IRQ_STS);
  IoWrite8(DATA_PORT, IoRead8(DATA_PORT));

  //
  // Exit SIO configuration mode
  //
  IoWrite8(INDEX_PORT, 0xAA);

  //
  // Clear all PM1 status
  //
  IoWrite16(mAcpiBaseAddr + R_PCH_ACPI_PM1_STS, 0xFFFF);

  //
  // Clear all GPE0 status
  //
  Temp32 = IoRead32(mAcpiBaseAddr + R_ICH_ACPI_GPE0a_EN);
  IoWrite32(mAcpiBaseAddr + R_PCH_ACPI_GPE0a_EN, 0);
  IoWrite32(mAcpiBaseAddr + R_PCH_ACPI_GPE0a_STS, 0xFFFFFFFF);

  //
  // Set specific IOPME (GPI13) wake
  //
  IoWrite32(mAcpiBaseAddr + R_PCH_ACPI_GPE0a_EN, (Temp32 | BIT29));

}
#endif

VOID
TpmPtsSmbsCallback (
  IN  EFI_HANDLE                    DispatchHandle,
  IN  EFI_SMM_SW_DISPATCH_CONTEXT   *DispatchContext
  )
/*++

Routine Description:

   TPM Handler

Arguments:

  DispatchHandle  - The handle of this callback, obtained when registering
  DispatchContext - Pointer to the EFI_SMM_SW_DISPATCH_CONTEXT

Returns:

  None.

--*/
{
  UINT8         TpmSetting;

  //
  // Setting MORD
  //
  TpmSetting = EFI_ACPI_TPM_MORD;
  mSmst->SmmIo.Io.Write (&mSmst->SmmIo, SMM_IO_UINT8, 0x72, 1, &TpmSetting);
  TpmSetting = mGlobalNvsAreaPtr->Area->MorData;
  mSmst->SmmIo.Io.Write (&mSmst->SmmIo, SMM_IO_UINT8, 0x73, 1, &TpmSetting);
}
